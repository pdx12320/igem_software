"""Actual loopback HTTP contracts with a fake worker; no model computation."""
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_app.csv_input import CSV_COLUMNS, COORDINATE_SYSTEM
from local_app.server import DOWNLOAD_FILES, JobManager, make_handler


class FakeProcess:
    def __init__(self, argv):
        self.argv = argv
        self.event = threading.Event()
        self.code = None
        self.terminated = False

    def wait(self, timeout=None):
        if not self.event.wait(timeout):
            raise subprocess.TimeoutExpired(self.argv, timeout)
        return self.code

    def poll(self):
        return self.code if self.event.is_set() else None

    def finish(self, code):
        self.code = code
        self.event.set()

    def terminate(self):
        self.terminated = True
        self.finish(-15)

    def kill(self):
        self.finish(-9)


def csv_fixture():
    row = {key: "" for key in CSV_COLUMNS}
    row.update(record_type="target", target_id="synthetic", target_position_1based="51",
               target_sequence="A" * 50 + "C" + "A" * 50, design_id="R12-D2",
               protein_selected="true", protein_sequence="A" * 492,
               recognition_rna="A" * 12, transcript_id="synthetic", binding_rna="A" * 12,
               binding_start_1based="38", binding_end_1based="49", site_position_1based="51",
               site_offset_nt="2", reference_kind="transcript", coordinate_system=COORDINATE_SYSTEM)
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, CSV_COLUMNS, lineterminator="\r\n")
    writer.writeheader()
    writer.writerow(row)
    return ("\ufeff" + stream.getvalue()).encode("utf-8")


class LocalServerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name).resolve()
        (self.root / "local_app").mkdir()
        (self.root / "local_app" / "run_analysis.py").write_text("# Fake worker fixture.\n")
        self.csv = self.root / "website-design.csv"
        self.csv.write_bytes(csv_fixture())
        self.fasta = self.root / "species.fasta"
        self.fasta.write_text(">synthetic\n" + "A" * 50 + "C" + "A" * 50 + "\n")
        self.originals = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in (self.csv, self.fasta)}
        self.workers = []
        self.worker_kwargs = []
        def factory(argv, **kwargs):
            process = FakeProcess(argv)
            self.workers.append(process)
            self.worker_kwargs.append(kwargs)
            return process
        self.manager = JobManager(self.root, process_factory=factory, cancel_grace=0.01)
        self.token = "a" * 64
        ui = Path(__file__).resolve().parents[1] / "ui" / "index.html"
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.manager, self.token, ui))
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
        self.thread.start()
        self.origin = "http://127.0.0.1:" + str(self.server.server_address[1])

    def tearDown(self):
        self.manager.close()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=1)
        for path, digest in self.originals.items():
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest)
        self.temporary.cleanup()

    def request(self, path, payload=None, *, token=True, origin=True, headers=None, raw=None):
        request_headers = {}
        if token:
            request_headers["X-ORCA-Token"] = self.token
        if origin:
            request_headers["Origin"] = self.origin
        body = raw
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
        if body is not None:
            request_headers["Content-Type"] = "application/json"
        request_headers.update(headers or {})
        request = Request(self.origin + path, data=body, headers=request_headers)
        try:
            response = urlopen(request, timeout=2)
        except HTTPError as error:
            response = error
        with response:
            return response.status, dict(response.headers), response.read()

    def start(self):
        status, _, body = self.request("/api/run", {"csvPath": str(self.csv), "fastaPath": str(self.fasta), "species": "Synthetic fixture"})
        self.assertEqual(status, 202, body)
        return json.loads(body)["job"]

    def wait_finished(self):
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            status = self.manager.status()["job"]
            if status["status"] not in ("running", "cancelling"):
                return status
            time.sleep(0.005)
        self.fail("Fake worker status did not finish.")

    def complete(self, job, *, code=0, progress_status="succeeded", all_outputs=True):
        directory = Path(job["outputDirectory"])
        (directory / "progress.json").write_text(json.dumps({"status": progress_status, "message": "Fixture worker result.", "completedSites": 1, "totalSites": 1}))
        for filename in DOWNLOAD_FILES if all_outputs else DOWNLOAD_FILES[:-1]:
            (directory / filename).write_bytes(b"{}\n" if filename.endswith(".json") else b"fixture,value\r\nrow,1\r\n")
        self.workers[-1].finish(code)
        return self.wait_finished()

    def test_page_is_tokenized_and_api_rejects_missing_token_foreign_host_and_origin(self):
        status, headers, body = self.request("/", token=False, origin=False)
        self.assertEqual(status, 200)
        self.assertIn(self.token.encode(), body)
        self.assertNotIn(b"__ORCA_TOKEN__", body)
        self.assertIn(b"Website CSV path", body)
        self.assertEqual(headers["Cache-Control"], "no-store")
        self.assertEqual(self.request("/api/status", token=False)[0], 403)
        self.assertEqual(self.request("/api/status", headers={"Host": "attacker.example"})[0], 403)
        self.assertEqual(self.request("/api/status", headers={"Origin": "https://attacker.example"})[0], 403)
        self.assertEqual(self.request("/api/run", {}, origin=False)[0], 403)
        self.assertEqual(self.request("/api/status", headers={"Sec-Fetch-Site": "cross-site"})[0], 403)

    def test_single_worker_exact_isolated_argv_and_successful_downloads(self):
        job = self.start()
        worker = self.workers[0]
        self.assertEqual(worker.argv[:3], [sys.executable, "-I", "-B"])
        self.assertEqual(worker.argv[3], str(self.root / "local_app/run_analysis.py"))
        self.assertEqual(worker.argv[4:], ["--root", str(self.root), "--csv", str(self.csv), "--fasta", str(self.fasta), "--species", "Synthetic fixture", "--output", job["outputDirectory"]])
        self.assertEqual(self.worker_kwargs[0]["stderr"], subprocess.STDOUT)
        self.assertEqual(self.worker_kwargs[0]["stdin"], subprocess.DEVNULL)
        self.assertEqual(self.request("/api/run", {"csvPath": str(self.csv), "fastaPath": str(self.fasta)})[0], 409)
        self.assertEqual(self.request(f"/download/{job['id']}/protein-ranking.csv?token={self.token}")[0], 409)
        final = self.complete(job)
        self.assertEqual(final["status"], "succeeded")
        self.assertEqual(final["downloads"], list(DOWNLOAD_FILES))
        status, headers, body = self.request(f"/download/{job['id']}/protein-ranking.csv?token={self.token}", token=False, origin=False)
        self.assertEqual(status, 200)
        self.assertEqual(body, b"fixture,value\r\nrow,1\r\n")
        self.assertIn("attachment", headers["Content-Disposition"])
        self.assertEqual(self.request(f"/download/{job['id']}/worker.log?token={self.token}")[0], 404)
        self.assertEqual(self.request(f"/download/{job['id']}/manifest.json")[0], 403)
        self.assertEqual(self.request(f"/download/{job['id']}/../species.fasta?token={self.token}")[0], 404)
        next_job = self.start()
        self.assertNotEqual(next_job["id"], job["id"])
        self.complete(next_job)

    def test_nonzero_exit_and_missing_complete_outputs_do_not_enable_downloads(self):
        for code, progress_status, all_outputs in [(1, "succeeded", True), (0, "running", True), (0, "succeeded", False)]:
            with self.subTest(code=code, progress_status=progress_status, all_outputs=all_outputs):
                job = self.start()
                final = self.complete(job, code=code, progress_status=progress_status, all_outputs=all_outputs)
                self.assertEqual(final["status"], "failed")
                self.assertEqual(final["downloads"], [])
                self.assertEqual(self.request(f"/download/{job['id']}/manifest.json?token={self.token}")[0], 409)

    def test_cancel_only_the_active_owned_worker_and_preserve_partial_outputs(self):
        job = self.start()
        directory = Path(job["outputDirectory"])
        partial = directory / "partial-scores.jsonl"
        partial.write_text('{"fixture": true}\n')
        status, _, _ = self.request("/api/cancel", {"jobId": "different-job"})
        self.assertEqual(status, 409)
        status, _, body = self.request("/api/cancel", {"jobId": job["id"]})
        self.assertEqual(status, 202, body)
        final = self.wait_finished()
        self.assertEqual(final["status"], "cancelled")
        self.assertTrue(self.workers[0].terminated)
        self.assertTrue((directory / "cancel.request").is_file())
        self.assertTrue((directory / "worker.log").is_file())
        self.assertEqual(partial.read_text(), '{"fixture": true}\n')
        self.assertEqual(final["downloads"], [])

    def test_invalid_inputs_oversized_json_and_preview_cannot_start_models(self):
        cases = [{"csvPath": str(self.root / "missing.csv"), "fastaPath": str(self.fasta)},
                 {"csvPath": str(self.root), "fastaPath": str(self.fasta)},
                 {"csvPath": str(self.csv), "fastaPath": str(self.csv)},
                 {"csvPath": str(self.csv), "fastaPath": str(self.fasta), "species": "A" * 201}]
        invalid_csv = self.root / "invalid.csv"
        invalid_csv.write_text("not,the,website,header\n")
        cases.append({"csvPath": str(invalid_csv), "fastaPath": str(self.fasta)})
        invalid_fasta = self.root / "invalid.fasta"
        invalid_fasta.write_text("ACGU\n")
        cases.append({"csvPath": str(self.csv), "fastaPath": str(invalid_fasta)})
        for payload in cases:
            with self.subTest(payload=payload):
                self.assertEqual(self.request("/api/run", payload)[0], 400)
        self.assertEqual(self.request("/api/run", raw=b"x" * (64 * 1024 + 1))[0], 413)
        self.manager.web_only = True
        self.assertEqual(self.request("/api/run", {"csvPath": str(self.csv), "fastaPath": str(self.fasta)})[0], 403)
        self.assertEqual(self.workers, [])
        self.assertFalse((self.root / "results").exists())

    def test_downloads_cannot_follow_a_symlink_outside_the_job_folder(self):
        job = self.start()
        final = self.complete(job)
        self.assertEqual(final["status"], "succeeded")
        directory = Path(job["outputDirectory"])
        # Change an owned fixture only, leaving all original inputs untouched.
        (directory / "manifest.json").unlink()
        (directory / "manifest.json").symlink_to(self.csv)
        self.assertEqual(self.request(f"/download/{job['id']}/manifest.json?token={self.token}")[0], 404)


if __name__ == "__main__":
    unittest.main()
