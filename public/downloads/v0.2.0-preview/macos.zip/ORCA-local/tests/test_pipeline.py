"""Small real CSV/FASTA transport fixtures with mocked model inference only."""
from contextlib import ExitStack, contextmanager
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_app import pipeline
from local_app.csv_input import CSV_COLUMNS, COORDINATE_SYSTEM
from local_app.esm_ranker import (
    AA, ESM_CHECKPOINT_SHA256, ESM_MODEL_ID, ESM_REVISION, FEATURE_DEFINITION,
    FrozenRanker, FROZEN_CHECKPOINT_SHA256, REFERENCE492_SHA256, REFERENCE493_SHA256,
)

PACKAGE = Path(__file__).resolve().parents[1]
TARGET = "A" * 50 + "C" + "A" * 50


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frozen = FrozenRanker(PACKAGE / "models/puf-ranker-492.json")

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.root = self.directory / "package"
        self.root.mkdir()
        self.output = self.directory / "results"
        self.csv = self.directory / "website.csv"
        self.fasta = self.directory / "species.fasta"
        self.fasta.write_text(
            ">synthetic\n" + TARGET + "\n>same-context\n" + TARGET +
            "\n>ambiguous\nR" + "A" * 49 + "C" + "A" * 50 + "\n>edge\nCC\n",
            encoding="utf-8",
        )
        mutant = list(self.frozen.reference492)
        mutant[0] = "A" if mutant[0] != "A" else "G"
        self.candidates = [
            ("selected", self.frozen.reference492, True),
            ("mutant", "".join(mutant), False),
            ("unsupported", "A" * 349, False),
        ]
        self.write_input_csv()

    def tearDown(self):
        self.temporary.cleanup()

    def write_input_csv(self, *, reference_sha="", reference_kind="transcript"):
        common = dict(target_id="synthetic", target_position_1based="51",
                      target_sequence=TARGET, design_id="R12-D2", library_version="fixture-v1",
                      recognition_rna="A" * 12, reference_name="species.fasta",
                      reference_species="Synthetic fixture", reference_kind=reference_kind,
                      reference_sha256=reference_sha, coordinate_system=COORDINATE_SYSTEM)
        target = dict(common, record_type="target", protein_candidate_id="selected",
                      protein_selected="true", protein_sequence=self.candidates[0][1],
                      scaffold_id="fixed492", trm_assignments="fixture assignments",
                      transcript_id="synthetic", binding_rna="A" * 12,
                      binding_start_1based="38", binding_end_1based="49",
                      site_position_1based="51", site_offset_nt="2",
                      # Saved website values must not feed the local model.
                      esm_rank="99", s_hat_raw="999", lamar_score="888",
                      lamar_score_available="true", lamar_status="scored")
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, CSV_COLUMNS, restval="", lineterminator="\r\n")
        writer.writeheader()
        writer.writerow(target)
        for identifier, protein, selected in self.candidates:
            writer.writerow(dict(common, record_type="protein_candidate", protein_candidate_id=identifier,
                                 protein_sequence=protein, protein_selected=str(selected).lower(),
                                 scaffold_id="fixed492" if len(protein) == 492 else "8R",
                                 trm_assignments="fixture assignments", lamar_score="777"))
        self.csv.write_bytes(("\ufeff" + stream.getvalue()).encode())

    def complete_reference_features(self):
        return {
            "schemaVersion": 1, "complete": True, "positions": list(range(493)),
            "values": [list(row) for row in self.frozen.score_logp] + [[-1.0] * 20],
            "metadata": {"featureDefinition": FEATURE_DEFINITION, "modelId": ESM_MODEL_ID,
                         "revision": ESM_REVISION, "checkpointSha256": ESM_CHECKPOINT_SHA256,
                         "referenceSha256": REFERENCE493_SHA256, "aaAlphabet": AA,
                         "torch": "2.0.1", "transformers": "4.32.1"},
        }

    @contextmanager
    def models(self, *, score_values=(0.0, -2.0, -3.0, 0.25), on_score=None):
        scores = iter(score_values)
        self.windows = []

        def score(model, tokenizer, window):
            self.windows.append(window)
            if on_score is not None:
                on_score(len(self.windows))
            return next(scores)

        ranking = {"rows": [
            {"id": "selected", "rank": 1, "S_hat": 0.0, "ESM2_score": -3.25,
             "C295_hat": -1.0, "C388_hat": -1.0, "C871_hat": -1.0},
            {"id": "mutant", "rank": 2, "S_hat": -1.5, "ESM2_score": 0.0,
             "C295_hat": -0.5, "C388_hat": -2.0, "C871_hat": -0.5}],
            "modelVersion": self.frozen.model_version,
            "sourceCheckpointSha256": FROZEN_CHECKPOINT_SHA256,
            "referenceSha256": REFERENCE492_SHA256,
            "featureSource": "recomputed-pinned-esm2-reference493",
            "numericalComparison": {"maxAbsoluteDifference": 0.0},
            "esmModelId": ESM_MODEL_ID, "esmRevision": ESM_REVISION,
            "esmCheckpointSha256": ESM_CHECKPOINT_SHA256}
        fake_torch = SimpleNamespace(set_num_threads=lambda n: None,
                                     get_num_interop_threads=lambda: 1,
                                     set_num_interop_threads=lambda n: None)
        self.rank_mock = Mock(return_value=ranking)
        self.esm_mock = Mock(return_value=(object(), object()))
        self.lamar_mock = Mock(return_value=(object(), object(), dict(pipeline.CORE_VERSIONS)))
        with ExitStack() as stack:
            stack.enter_context(patch.dict(sys.modules, {"torch": fake_torch}))
            stack.enter_context(patch.object(pipeline.importlib.metadata, "version", side_effect=lambda key: pipeline.CORE_VERSIONS[key]))
            stack.enter_context(patch.object(pipeline, "FrozenRanker", return_value=self.frozen))
            stack.enter_context(patch.object(pipeline, "verify_model_assets", return_value={}))
            stack.enter_context(patch.object(pipeline, "build_esm", self.esm_mock))
            stack.enter_context(patch.object(pipeline, "generate_reference_logp", return_value=self.complete_reference_features()))
            stack.enter_context(patch.object(pipeline, "rank_candidates", self.rank_mock))
            stack.enter_context(patch.object(pipeline, "verify_assets", return_value={}))
            stack.enter_context(patch.object(pipeline, "build_lamar", self.lamar_mock))
            stack.enter_context(patch.object(pipeline, "score_window", side_effect=score))
            yield

    def execute(self):
        return pipeline.run_analysis(self.root, self.csv, self.fasta, "Synthetic fixture", self.output)

    def manifest(self):
        return json.loads((self.output / "manifest.json").read_text())

    def test_every_c_raw_zero_negative_unsupported_and_boundary_outputs(self):
        original = {path: path.read_bytes() for path in (self.csv, self.fasta)}
        with self.models():
            result = self.execute()
        self.assertEqual(result["status"], "succeeded")
        self.assertEqual(result["counts"], {
            "candidates": 3, "rankedCandidates": 2, "incompatibleCandidates": 1,
            "records": 4, "bases": 305, "totalSites": 5,
            "scoredSites": 4, "unscoredSites": 1, "paddedSites": 2,
        })
        sites = read_csv(self.output / "lamar-sites.csv")
        self.assertEqual([(row["record_id"], row["site_position_1based"]) for row in sites],
                         [("synthetic", "51"), ("same-context", "51"), ("ambiguous", "51"), ("edge", "1"), ("edge", "2")])
        self.assertEqual([row["lamar_score"] for row in sites], ["0.0", "-2.0", "", "-3.0", "0.25"])
        self.assertEqual(sites[2]["lamar_status"], "unscored")
        self.assertIn("R", sites[2]["reason"])
        self.assertTrue(all(len(row["context_101nt"]) == 101 and row["context_101nt"][50] == "C" for row in sites))
        self.assertEqual([row["boundary_padded"] for row in sites], ["false", "false", "false", "true", "true"])
        self.assertEqual(len(self.windows), 4)  # Target score reused at only its exact record/site.
        for name, info in result["outputFiles"].items():
            data = (self.output / name).read_bytes()
            self.assertEqual(info["bytes"], len(data))
            self.assertEqual(info["sha256"], hashlib.sha256(data).hexdigest())
        self.assertEqual((self.output / "design-input.csv").read_bytes(), original[self.csv])
        for path, data in original.items():
            self.assertEqual(path.read_bytes(), data)

    def test_ranking_preserves_raw_values_and_lamar_is_not_copied_to_puf_candidates(self):
        with self.models():
            self.execute()
        ranks = {row["candidate_id"]: row for row in read_csv(self.output / "protein-ranking.csv")}
        self.assertEqual(ranks["selected"]["s_hat_raw"], "0.0")
        self.assertEqual(ranks["selected"]["esm2_score"], "-3.25")
        self.assertEqual(ranks["mutant"]["s_hat_raw"], "-1.5")
        self.assertEqual(ranks["mutant"]["esm2_score"], "0.0")
        self.assertEqual(ranks["unsupported"]["status"], "incompatible_scaffold")
        self.assertEqual(ranks["unsupported"]["rank"], "")
        self.assertEqual(ranks["unsupported"]["s_hat_raw"], "")
        self.assertEqual(len(self.rank_mock.call_args.args[0]), 2)
        combined = read_csv(self.output / "combined-results.csv")
        proteins = [row for row in combined if row["record_type"] == "protein_candidate"]
        sites = [row for row in combined if row["record_type"] == "external_site"]
        self.assertEqual(len(proteins), 3)
        self.assertTrue(all(row["lamar_score"] == "" and row["lamar_score_available"] == "" for row in proteins))
        self.assertTrue(all(row["s_hat_raw"] == "" and row["protein_candidate_id"] == "" for row in sites))
        self.assertEqual(combined[0]["lamar_score"], "0.0")
        self.assertEqual(combined[0]["lamar_score_available"], "true")
        self.assertEqual(sites[1]["lamar_score"], "-2.0")
        self.assertEqual(combined[0]["protein_sequence"], self.candidates[0][1])
        self.assertFalse(self.manifest()["models"]["lamar"]["PUFConditioned"])

    def test_identical_context_at_other_record_cannot_supply_target_score(self):
        self.fasta.write_text(self.fasta.read_text().replace(">synthetic\n", ">different-record\n"))
        with self.models():
            result = self.execute()
        self.assertFalse(result["inputs"]["targetReferenceRecordFound"])
        combined = read_csv(self.output / "combined-results.csv")
        self.assertEqual(combined[0]["record_type"], "target")
        self.assertEqual(combined[0]["lamar_score"], "")
        self.assertEqual(combined[0]["context_101nt"], "")
        external = [row for row in combined if row["record_type"] == "external_site"]
        self.assertEqual(external[0]["lamar_score"], "0.0")
        self.assertEqual(len(self.windows), 4)

    def test_changed_original_input_fails_and_preserves_partial_results(self):
        for changed_name in ("csv", "fasta"):
            with self.subTest(input=changed_name):
                # Each run owns a distinct output path; source files are tiny test fixtures.
                self.output = self.directory / ("changed-" + changed_name)
                target_file = getattr(self, changed_name)
                def change_once(call):
                    if call == 4:
                        with target_file.open("ab") as stream:
                            stream.write(b"\n")
                with self.models(on_score=change_once):
                    with self.assertRaisesRegex(ValueError, "input changed"):
                        self.execute()
                manifest = self.manifest()
                self.assertEqual(manifest["status"], "failed")
                self.assertNotIn("outputFiles", manifest)
                self.assertEqual(len(read_csv(self.output / "lamar-sites.csv")), 5)
                self.assertEqual(json.loads((self.output / "progress.json").read_text())["status"], "failed")

    def test_cancel_keeps_partial_outputs_and_never_marks_complete(self):
        def cancel(call):
            if call == 2:
                (self.output / "cancel.request").write_text("fixture cancellation")
        with self.models(on_score=cancel):
            with self.assertRaises(InterruptedError):
                self.execute()
        manifest = self.manifest()
        self.assertEqual(manifest["status"], "cancelled")
        self.assertNotIn("outputFiles", manifest)
        self.assertLess(manifest["counts"]["scoredSites"] + manifest["counts"]["unscoredSites"], 5)
        self.assertEqual(len(read_csv(self.output / "lamar-sites.csv")), 2)
        self.assertTrue((self.output / "protein-ranking.csv").is_file())
        self.assertTrue((self.output / "design-input.csv").is_file())
        self.assertEqual(json.loads((self.output / "progress.json").read_text())["status"], "cancelled")

    def test_existing_output_cannot_be_reused_or_overwritten(self):
        self.output.mkdir()
        previous = self.output / "protein-ranking.csv"
        previous.write_bytes(b"immutable fixture output\n")
        with self.models():
            with self.assertRaisesRegex(ValueError, "new output directory"):
                self.execute()
        self.assertEqual(previous.read_bytes(), b"immutable fixture output\n")
        self.assertFalse((self.output / "manifest.json").exists())
        self.esm_mock.assert_not_called()
        self.lamar_mock.assert_not_called()

    def test_existing_progress_or_input_copy_cannot_be_overwritten(self):
        for filename in ("progress.json", "design-input.csv"):
            with self.subTest(filename=filename):
                self.output = self.directory / ("existing-" + filename)
                self.output.mkdir()
                previous = self.output / filename
                previous.write_bytes(b"existing fixture must remain unchanged\n")
                with self.models():
                    with self.assertRaisesRegex(ValueError, "new output directory"):
                        self.execute()
                self.assertEqual(previous.read_bytes(), b"existing fixture must remain unchanged\n")
                self.assertFalse((self.output / "manifest.json").exists())
                self.esm_mock.assert_not_called()
                self.lamar_mock.assert_not_called()

    def test_input_copy_and_final_checksum_use_the_readers_resolved_csv_path(self):
        verified = pipeline.load_design_csv(self.csv)
        with self.models():
            with patch.object(pipeline, "load_design_csv", return_value=verified):
                result = pipeline.run_analysis(self.root, "~/fixture-alias.csv", self.fasta,
                                               "Synthetic fixture", self.output)
        self.assertEqual(result["status"], "succeeded")
        self.assertEqual((self.output / "design-input.csv").read_bytes(), self.csv.read_bytes())

    def test_genome_label_is_preserved_and_never_claims_transcript_scope(self):
        self.write_input_csv(reference_kind="genome")
        with self.models():
            self.execute()
        combined = read_csv(self.output / "combined-results.csv")
        self.assertTrue(all(row["reference_kind"] == "genome" for row in combined))
        lamar = [row for row in combined if row["lamar_status"]]
        self.assertTrue(lamar)
        self.assertTrue(all(row["lamar_scope"] == "uploaded-sequence-fasta" for row in lamar))

    def test_wrong_reference_or_changed_target_record_fails_before_inference(self):
        self.write_input_csv(reference_sha="0" * 64)
        with self.models():
            with self.assertRaisesRegex(ValueError, "reference recorded"):
                self.execute()
        self.assertEqual(self.manifest()["status"], "failed")
        self.esm_mock.assert_not_called()
        self.lamar_mock.assert_not_called()
        self.write_input_csv()
        self.output = self.directory / "wrong-target"
        self.fasta.write_text(self.fasta.read_text().replace(TARGET, "G" + TARGET[1:], 1))
        with self.models():
            with self.assertRaisesRegex(ValueError, "target RNA"):
                self.execute()
        self.assertEqual(self.manifest()["status"], "failed")
        self.esm_mock.assert_not_called()
        self.lamar_mock.assert_not_called()


if __name__ == "__main__":
    unittest.main()
