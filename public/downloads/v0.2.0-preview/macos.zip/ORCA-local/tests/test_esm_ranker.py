"""Numerical and provenance checks; no model download or GPU work."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_app.esm_ranker import (
    AA, ESM_CHECKPOINT_SHA256, ESM_MODEL_ID, ESM_REVISION, FEATURE_DEFINITION,
    FrozenRanker, NumericalCompatibilityError, REFERENCE493_SHA256,
    compare_reference_logp, load_reference_logp, rank_candidates, save_reference_logp,
    verify_model_assets,
)

MODEL = Path(__file__).resolve().parents[1] / "models" / "puf-ranker-492.json"
GOLDEN = [
    ("10_p1_gvd", {35: "G", 36: "V", 39: "D"},
     [0.23296760614152492, 0.5378618376456891, 0.3798477348976823,
      0.23145416712608546, -7.390573441982269]),
    ("11_p1_sne", {36: "N"},
     [0.25013567129743375, 0.552471802425101, 0.4095791502551604,
      0.22261439164880392, -1.0240983963012695]),
    ("12_p1_sre", {36: "R"},
     [0.2559059393295896, 0.5612013880092319, 0.43140483520556216,
      0.21754600074165603, 4.279422149062157]),
]


def features(frozen, *, positions=None):
    positions = list(range(493)) if positions is None else positions
    values = [list(frozen.score_logp[index]) if index < 492 else [-1.0] * 20 for index in positions]
    return {"schemaVersion": 1, "complete": positions == list(range(493)),
            "positions": positions, "values": values,
            "metadata": {"featureDefinition": FEATURE_DEFINITION, "modelId": ESM_MODEL_ID,
                         "revision": ESM_REVISION, "checkpointSha256": ESM_CHECKPOINT_SHA256,
                         "referenceSha256": REFERENCE493_SHA256, "aaAlphabet": AA}}


class RankerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frozen = FrozenRanker(MODEL)

    def golden_candidates(self):
        result = []
        for identifier, mutations, expected in GOLDEN:
            sequence = list(self.frozen.reference492)
            for position, residue in mutations.items():
                sequence[position] = residue
            result.append({"id": identifier, "protein": "".join(sequence)})
        return result

    def test_archived_independent_predictions(self):
        rows = rank_candidates(self.golden_candidates(), self.frozen)["rows"]
        self.assertEqual([row["id"] for row in rows], [item[0] for item in GOLDEN])
        for row, (_, _, expected) in zip(rows, GOLDEN):
            for field, value in zip(("C295_hat", "C388_hat", "C871_hat", "S_hat", "ESM2_score"), expected):
                self.assertLessEqual(abs(row[field] - value), 1e-12, field)

    def test_original493_view_keeps_input_and_values(self):
        candidate = self.golden_candidates()[0]
        original = {"id": candidate["id"], "protein": candidate["protein"] + "G"}
        short = rank_candidates([candidate], self.frozen)["rows"][0]
        long = rank_candidates([original], self.frozen)["rows"][0]
        for field in ("C295_hat", "C388_hat", "C871_hat", "S_hat", "ESM2_score"):
            self.assertEqual(short[field], long[field])
        self.assertEqual(short["protein"], candidate["protein"])
        self.assertEqual(long["protein"], original["protein"])

    def test_equal_recomputed_features_preserve_fits(self):
        candidates = self.golden_candidates()
        expected = rank_candidates(candidates, self.frozen)["rows"]
        result = rank_candidates(candidates, self.frozen, features(self.frozen), numerical_tolerance=0)
        self.assertEqual(result["rows"], expected)
        self.assertEqual(result["numericalComparison"]["comparedValues"], 9840)

    def test_subset_can_be_compared_but_never_ranked(self):
        subset = features(self.frozen, positions=[0, 34, 491])
        self.assertEqual(compare_reference_logp(subset, self.frozen)["comparedValues"], 60)
        with self.assertRaisesRegex(ValueError, "subset"):
            rank_candidates(self.golden_candidates(), self.frozen, subset, numerical_tolerance=0)
        subset["complete"] = True
        with self.assertRaisesRegex(ValueError, "falsely"):
            compare_reference_logp(subset, self.frozen)

    def test_numerical_differences_are_measured_and_require_explicit_acceptance(self):
        fresh = features(self.frozen)
        fresh["values"][34][0] += 0.125
        measured = compare_reference_logp(fresh, self.frozen)
        self.assertEqual(measured["maxAbsoluteDifference"], 0.125)
        with self.assertRaises(NumericalCompatibilityError) as caught:
            rank_candidates(self.golden_candidates(), self.frozen, fresh)
        self.assertEqual(caught.exception.comparison["maxAbsoluteDifference"], 0.125)
        with self.assertRaises(NumericalCompatibilityError):
            rank_candidates(self.golden_candidates(), self.frozen, fresh, numerical_tolerance=0.01)

    def test_altered_checkpoint_and_nonfinite_features_rejected(self):
        for mutate in (
            lambda item: item["metadata"].update(revision="main"),
            lambda item: item["metadata"].update(featureDefinition="mean-embeddings"),
            lambda item: item["values"][0].__setitem__(0, float("nan")),
            lambda item: item["values"][0].pop(),
        ):
            fresh = features(self.frozen)
            mutate(fresh)
            with self.assertRaises(ValueError):
                compare_reference_logp(fresh, self.frozen)

    def test_unsupported_proteins_and_duplicate_candidates_rejected(self):
        for protein in ("A" * 491, "A" * 493, "A" * 494, "X" * 492, self.frozen.reference492.lower()):
            with self.assertRaises(ValueError):
                rank_candidates([{"id": "invalid", "protein": protein}], self.frozen)
        candidate = self.golden_candidates()[0]
        with self.assertRaises(ValueError):
            rank_candidates([candidate, candidate], self.frozen)

    def test_immutable_cache_roundtrip_detects_tampering(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "reference.json"
            value = features(self.frozen, positions=[0, 1])
            manifest = save_reference_logp(path, value)
            self.assertFalse(manifest["complete"])
            self.assertEqual(load_reference_logp(path)["values"], value["values"])
            self.assertEqual(manifest["fileSha256"], hashlib.sha256(path.read_bytes()).hexdigest())
            with self.assertRaises(FileExistsError):
                save_reference_logp(path, value)
            altered = json.loads(path.read_text())
            altered["values"][0][0] += 1
            path.write_text(json.dumps(altered))
            with self.assertRaisesRegex(ValueError, "checksum"):
                load_reference_logp(path)

    def test_model_and_asset_files_require_pinned_checksums(self):
        with tempfile.TemporaryDirectory() as directory:
            model = Path(directory) / "altered.json"
            model.write_bytes(MODEL.read_bytes() + b" ")
            with self.assertRaisesRegex(ValueError, "checksum"):
                FrozenRanker(model)
            with self.assertRaisesRegex(ValueError, "missing or altered"):
                verify_model_assets(directory)


if __name__ == "__main__":
    unittest.main()
