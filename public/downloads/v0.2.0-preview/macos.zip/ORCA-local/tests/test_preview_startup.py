"""The preview must work before model dependencies or weights are installed."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SERVER = Path(__file__).resolve().parents[1] / "local_app" / "server.py"


class PreviewStartupTests(unittest.TestCase):
    def test_self_check_is_standard_library_only_and_rejects_incomplete_ui(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ui = root / "ui"
            ui.mkdir()
            page = ui / "index.html"
            page.write_text('<form id="run-form"></form>__ORCA_TOKEN__', encoding="utf-8")
            command = [sys.executable, "-I", "-S", "-B", str(SERVER), "--root", str(root),
                       "--self-check", "--web-only", "--no-browser"]
            checked = subprocess.run(command, capture_output=True, text=True, timeout=10)
            self.assertEqual(checked.returncode, 0, checked.stderr)
            self.assertEqual(json.loads(checked.stdout),
                             {"status": "passed", "scope": "local interface only", "modelChecks": False})
            page.write_text("incomplete test interface", encoding="utf-8")
            rejected = subprocess.run(command, capture_output=True, text=True, timeout=10)
            self.assertEqual(rejected.returncode, 1)
            self.assertEqual(json.loads(rejected.stderr)["status"], "failed")


if __name__ == "__main__":
    unittest.main()
