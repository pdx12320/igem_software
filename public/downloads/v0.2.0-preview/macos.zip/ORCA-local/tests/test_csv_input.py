"""Small contract fixtures for website CSV → fresh local model inputs."""
import csv
import hashlib
import io
from pathlib import Path
import re
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local_app.csv_input import CSV_COLUMNS, COORDINATE_SYSTEM, load_design_csv, parse_design_csv


def fixture():
    context = "A" * 50 + "C" + "G" * 50
    row = {key: "" for key in CSV_COLUMNS}
    row.update(
        record_type="target", target_id="fixture-target", target_position_1based="51",
        target_sequence=context, design_id="R12-D2", protein_selected="true",
        protein_sequence="A" * 492, scaffold_id="PUF12-9_WT", trm_assignments="P1:A:SRQ",
        library_version="fixture-library", recognition_rna="A" * 12,
        transcript_id="fixture-target", binding_rna="A" * 12,
        binding_start_1based="38", binding_end_1based="49", site_position_1based="51",
        site_offset_nt="2", context_101nt=context, reference_name="fixture.fasta",
        reference_species="", reference_kind="transcript", coordinate_system=COORDINATE_SYSTEM,
    )
    return row


def candidate(target, *, candidate_id="candidate-1", protein=None, selected=True):
    result = dict(target)
    result.update(record_type="protein_candidate", protein_candidate_id=candidate_id,
                  protein_sequence=protein or target["protein_sequence"],
                  protein_selected=str(selected).lower())
    for key in ("transcript_id", "binding_rna", "binding_start_1based", "binding_end_1based",
                "site_position_1based", "site_offset_nt", "binding_mismatches", "context_101nt"):
        result[key] = ""
    return result


def encode(rows, *, bom=True, columns=CSV_COLUMNS):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, columns, lineterminator="\r\n")
    writer.writeheader()
    writer.writerows(rows)
    return (("\ufeff" if bom else "") + stream.getvalue()).encode("utf-8")


class CsvInputTests(unittest.TestCase):
    def test_field_limit_is_portable_to_windows_c_long_and_restored(self):
        original = csv.field_size_limit()
        actual_field_size_limit = csv.field_size_limit

        def windows_field_size_limit(*args):
            if args and args[0] > 2**31 - 1:
                raise OverflowError("Python int too large to convert to C long")
            return actual_field_size_limit(*args)

        with patch("local_app.csv_input.sys.maxsize", 2**63 - 1), \
                patch("local_app.csv_input.csv.field_size_limit", side_effect=windows_field_size_limit):
            result = parse_design_csv(encode([fixture()]))
        self.assertEqual(len(result["candidates"]), 1)
        self.assertEqual(csv.field_size_limit(), original)

    def test_header_matches_the_actual_website_exporter(self):
        website = Path(__file__).resolve().parents[2] / "site-downloads-publish/lib/scientist-csv.ts"
        if not website.exists():
            self.skipTest("Source comparison is only available in the development workspace.")
        source = website.read_text(encoding="utf-8")
        exported = source.split("export const SCIENTIST_CSV_COLUMNS = [", 1)[1].split("] as const", 1)[0]
        self.assertEqual(list(CSV_COLUMNS), re.findall(r"'([a-z0-9_]+)'", exported))

    def test_selected_target_fallback_keeps_protein_and_coordinate_convention(self):
        row = fixture()
        data = encode([row])
        result = parse_design_csv(data)
        self.assertEqual(result["target"]["bindingStart"], 38)
        self.assertEqual(result["target"]["bindingEnd"], 49)
        self.assertEqual(result["target"]["position"], 51)
        self.assertEqual(result["target"]["selectedCandidateId"], "R12-D2")
        self.assertEqual(result["candidates"][0]["protein"], row["protein_sequence"])
        self.assertTrue(result["candidates"][0]["selected"])
        self.assertEqual(result["candidates"][0]["compatibility"]["length"], 492)
        self.assertTrue(result["candidates"][0]["compatibility"]["fixed492Compatible"])
        self.assertEqual(result["source"]["sha256"], hashlib.sha256(data).hexdigest())
        self.assertEqual(result["source"]["sizeBytes"], len(data))
        self.assertEqual(result["source"]["rowCount"], 1)

    def test_unranked_candidates_and_the_selected_protein_are_preserved(self):
        row = fixture()
        row["protein_candidate_id"] = "chosen"
        chosen = candidate(row, candidate_id="chosen")
        other = candidate(row, candidate_id="other", protein="C" * 492, selected=False)
        result = parse_design_csv(encode([row, chosen, other], bom=False))
        self.assertEqual([p["id"] for p in result["candidates"]], ["chosen", "other"])
        self.assertEqual([p["selected"] for p in result["candidates"]], [True, False])
        self.assertEqual(result["warnings"], [])
        self.assertNotIn("esm2_score", result["candidates"][0])

    def test_selected_target_is_added_to_a_different_saved_queue(self):
        row = fixture()
        other = candidate(row, candidate_id="other", protein="C" * 492, selected=False)
        result = parse_design_csv(encode([row, other]))
        self.assertEqual([p["id"] for p in result["candidates"]], ["other", "R12-D2"])
        self.assertEqual(result["target"]["selectedCandidateId"], "R12-D2")

    def test_493_terminal_g_protein_is_not_truncated_or_rewritten(self):
        row = fixture()
        row["protein_sequence"] += "G"
        result = parse_design_csv(encode([row]))
        protein = result["candidates"][0]
        self.assertEqual(protein["protein"], "A" * 492 + "G")
        self.assertFalse(protein["compatibility"]["fixed492Compatible"])
        self.assertTrue(protein["compatibility"]["terminalG493Compatible"])

    def test_known_sequence_apostrophes_are_restored_but_identifiers_are_kept(self):
        row = fixture()
        row["target_id"] = "'=protected,中文"
        row["transcript_id"] = row["target_id"]
        for key in ("target_sequence", "protein_sequence", "recognition_rna", "binding_rna", "context_101nt"):
            row[key] = "'" + row[key]
        result = parse_design_csv(encode([row]))
        self.assertEqual(result["target"]["id"], "'=protected,中文")
        self.assertEqual(result["target"]["sequence"], "A" * 50 + "C" + "G" * 50)
        self.assertEqual(result["candidates"][0]["protein"], "A" * 492)
        self.assertIn("identifier", result["warnings"][-1])

    def test_saved_scores_are_ignored_instead_of_becoming_new_model_inputs(self):
        row = fixture()
        row.update(s_hat_raw="-0.25", esm2_score="0", lamar_score="2.75", esm_rank="1")
        result = parse_design_csv(encode([row]))
        self.assertTrue(any("ignored" in warning for warning in result["warnings"]))
        self.assertNotIn("lamar_score", result["target"])
        self.assertNotIn("s_hat_raw", result["candidates"][0])

    def test_actual_previous_full_export_keeps_one_492_aa_candidate(self):
        path = Path(__file__).resolve().parents[2] / "package/examples/expected-scientist-full.csv"
        if not path.exists():
            self.skipTest("Previous full export fixture is only available in the development workspace.")
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        result = load_design_csv(path)
        self.assertEqual(result["target"]["id"], "ORCA_SYNTHETIC_TARGET")
        self.assertEqual(result["target"]["position"], 51)
        self.assertEqual(len(result["candidates"]), 1)
        self.assertEqual(len(result["candidates"][0]["protein"]), 492)
        self.assertEqual(result["candidates"][0]["compatibility"]["version"], "drop-fixed-terminal-g-v1")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)

    def test_file_loading_does_not_change_original_bytes(self):
        data = encode([fixture()])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "设计输入.csv"
            path.write_bytes(data)
            result = load_design_csv(path)
            self.assertEqual(path.read_bytes(), data)
            self.assertEqual(result["source"]["path"], str(path.resolve()))

    def test_no_protein_produces_an_actionable_error(self):
        row = fixture()
        row.update(protein_sequence="", protein_selected="false")
        with self.assertRaisesRegex(ValueError, "Complete the PUF design"):
            parse_design_csv(encode([row]))

    def test_duplicate_candidate_id_and_sequence_are_rejected(self):
        row = fixture()
        first = candidate(row, candidate_id="candidate-1")
        with self.assertRaisesRegex(ValueError, "Duplicate protein candidate ID"):
            parse_design_csv(encode([row, first, candidate(row, candidate_id="candidate-1", protein="C" * 492, selected=False)]))
        with self.assertRaisesRegex(ValueError, "Duplicate protein sequence"):
            parse_design_csv(encode([row, first, candidate(row, candidate_id="different", selected=False)]))

    def test_selected_candidate_id_cannot_point_to_another_protein(self):
        row = fixture()
        row["protein_candidate_id"] = "same-id"
        other = candidate(row, candidate_id="same-id", protein="C" * 492, selected=False)
        with self.assertRaisesRegex(ValueError, "already belongs to a different protein"):
            parse_design_csv(encode([row, other]))

    def test_multiple_target_records_and_mixed_designs_are_rejected(self):
        row = fixture()
        with self.assertRaisesRegex(ValueError, "Expected one target record"):
            parse_design_csv(encode([row, row]))
        other = candidate(row)
        other["target_id"] = "unrelated"
        with self.assertRaisesRegex(ValueError, "different target, design or reference"):
            parse_design_csv(encode([row, other]))

    def test_invalid_sequence_or_coordinates_are_rejected(self):
        invalid = {
            "target_sequence": "A" * 101,
            "target_position_1based": "0",
            "binding_start_1based": "39",
            "site_offset_nt": "3",
            "protein_sequence": "A" * 491 + "X",
            "context_101nt": "A" * 101,
            "coordinate_system": "0-based",
            "recognition_rna": "A" * 13,
        }
        for key, value in invalid.items():
            with self.subTest(key=key):
                row = fixture()
                row[key] = value
                with self.assertRaises(ValueError):
                    parse_design_csv(encode([row]))

    def test_malformed_header_record_width_encoding_and_quotes_are_rejected(self):
        row = fixture()
        valid = encode([row])
        cases = [valid.replace(b"record_type", b"record_kind", 1),
                 valid + b"target,too,few\r\n", b"\xff\xfe\x00", valid + b'"unterminated']
        for data in cases:
            with self.subTest(data=data[:15]):
                with self.assertRaises(ValueError):
                    parse_design_csv(data)


if __name__ == "__main__":
    unittest.main()
