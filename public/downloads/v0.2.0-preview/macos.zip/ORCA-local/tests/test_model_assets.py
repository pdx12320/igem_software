"""Tiny HTTP fixtures for the pinned model installer; no real model downloads."""
from __future__ import annotations

from contextlib import contextmanager, redirect_stdout
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib.util
import io
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("orca_model_assets", ROOT / "bootstrap" / "model_assets.py")
assets = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = assets
SPEC.loader.exec_module(assets)


def digest(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def fixture_server(data, mode="range"):
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *arguments):
            pass

        def do_GET(self):
            requests.append(dict(self.headers))
            requested = self.headers.get("Range")
            start = int(requested.removeprefix("bytes=").removesuffix("-")) if requested else 0
            resumed = bool(requested) and mode != "ignore-range"
            body = data[start:] if resumed else data
            self.send_response(206 if resumed else 200)
            if resumed:
                range_start = start + 1 if mode == "bad-range" else start
                self.send_header("Content-Range", f"bytes {range_start}-{len(data)-1}/{len(data)}")
            self.send_header("Content-Length", str(len(body) + (1 if mode == "bad-length" else 0)))
            self.send_header("Content-Type", "application/octet-stream")
            self.end_headers()
            self.wfile.write(body[:3] if mode == "truncated" else body)
            self.close_connection = True

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}/asset", requests
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


class ModelAssetTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.cache = self.root / "cache"
        self.output = self.root / "models" / "weights.bin"
        self.stdout = redirect_stdout(io.StringIO())
        self.stdout.__enter__()

    def tearDown(self):
        self.stdout.__exit__(None, None, None)
        self.temporary.cleanup()

    def asset(self, url, data):
        return assets.Asset("weights.bin", url, len(data), digest(data))

    def partial(self, asset, data):
        self.cache.mkdir()
        path = self.cache / (asset.sha256 + "-weights.bin.part")
        path.write_bytes(data)
        return path

    def test_resume_headers_checksum_and_reuse(self):
        data = b"verified tiny model fixture"
        with fixture_server(data) as (url, requests):
            asset = self.asset(url, data)
            self.partial(asset, data[:8])
            assets._download_asset(asset, self.output, self.cache)
            assets._download_asset(asset, self.output, self.cache)
        self.assertEqual(self.output.read_bytes(), data)
        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["Range"], "bytes=8-")
        self.assertEqual(requests[0]["Accept-Encoding"], "identity")
        self.assertTrue(requests[0]["User-Agent"].startswith("Mozilla/5.0"))

    def test_existing_wrong_model_is_preserved_without_download(self):
        data = b"expected fixture"
        self.output.parent.mkdir(parents=True)
        self.output.write_bytes(b"existing user file")
        with fixture_server(data) as (url, requests):
            with self.assertRaisesRegex(assets.ModelAssetError, "preserved existing file"):
                assets._download_asset(self.asset(url, data), self.output, self.cache)
        self.assertEqual(self.output.read_bytes(), b"existing user file")
        self.assertEqual(requests, [])

    def test_ignored_range_preserves_original_partial_and_restarts_separately(self):
        data = b"preserve partial on ignored range"
        with fixture_server(data, "ignore-range") as (url, requests):
            asset = self.asset(url, data)
            partial = self.partial(asset, data[:7])
            assets._download_asset(asset, self.output, self.cache)
        self.assertEqual(partial.read_bytes(), data[:7])
        self.assertEqual(self.output.read_bytes(), data)
        self.assertEqual(requests[0]["Range"], "bytes=7-")

    def test_bad_range_or_length_does_not_append_to_partial(self):
        for mode in ("bad-range", "bad-length"):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as temporary:
                data = b"precise response header fixture"
                cache = Path(temporary) / "cache"
                cache.mkdir()
                with fixture_server(data, mode) as (url, _):
                    asset = self.asset(url, data)
                    partial = cache / (asset.sha256 + "-weights.bin.part")
                    partial.write_bytes(data[:4])
                    with self.assertRaises(assets.ModelAssetError):
                        assets._download_asset(asset, Path(temporary) / "output", cache)
                self.assertEqual(partial.read_bytes(), data[:4])

    def test_hash_failure_retains_partial_and_never_publishes(self):
        expected = b"expected immutable weights"
        wrong = b"x" * len(expected)
        with fixture_server(wrong) as (url, _):
            with self.assertRaisesRegex(assets.ModelAssetError, "SHA256"):
                assets._download_asset(self.asset(url, expected), self.output, self.cache)
        self.assertFalse(self.output.exists())
        self.assertEqual(next(self.cache.glob("*.part")).read_bytes(), wrong)

    def test_truncated_response_retains_bytes_and_resumes_next_run(self):
        data = b"resume after fixture interruption"
        with fixture_server(data, "truncated") as (url, _):
            with self.assertRaises(assets.ModelAssetError):
                assets._download_asset(self.asset(url, data), self.output, self.cache)
        self.assertEqual(next(self.cache.glob("*.part")).read_bytes(), data[:3])
        with fixture_server(data) as (url, requests):
            assets._download_asset(self.asset(url, data), self.output, self.cache)
        self.assertEqual(requests[0]["Range"], "bytes=3-")
        self.assertEqual(self.output.read_bytes(), data)

    def test_extracts_only_named_weights_and_verifies_content(self):
        data = b"tiny verified weights"
        archive = self.root / "source.zip"
        member = "ORCA-local/models/model_101_classifier/best_model/model.safetensors"
        with zipfile.ZipFile(archive, "w") as package:
            package.writestr(member, data)
            package.writestr("../../unexpected.txt", "must never be extracted")
            package.writestr("ORCA-local/other.txt", "not a requested file")
        assets._extract_member(archive, member, self.output, len(data), digest(data), self.cache)
        self.assertEqual(self.output.read_bytes(), data)
        self.assertFalse((self.root / "other.txt").exists())
        self.assertEqual(len(list(self.output.parent.iterdir())), 1)
        with self.assertRaises(assets.ModelAssetError):
            assets._extract_member(archive, member, self.root / "wrong", len(data), "0" * 64, self.cache)
        self.assertFalse((self.root / "wrong").exists())

    def test_duplicate_archive_member_and_existing_wrong_output_are_preserved(self):
        data = b"weights"
        archive = self.root / "duplicate.zip"
        with zipfile.ZipFile(archive, "w") as package:
            package.writestr("weights", data)
            package.writestr("weights", data)
        with self.assertRaisesRegex(assets.ModelAssetError, "duplicated"):
            assets._extract_member(archive, "weights", self.output, len(data), digest(data), self.cache)
        self.output.parent.mkdir(parents=True)
        self.output.write_bytes(b"keep this original")
        with self.assertRaisesRegex(assets.ModelAssetError, "preserved"):
            assets._extract_member(archive, "weights", self.output, len(data), digest(data), self.cache)
        self.assertEqual(self.output.read_bytes(), b"keep this original")

    def test_ensure_models_returns_exact_checks_with_tiny_injected_assets(self):
        data = b"tiny ESM"
        lamar_data = b"tiny LaMAR"
        esm = self.root / "models" / "esm2_t12_35M_UR50D"
        esm.mkdir(parents=True)
        (esm / "config.json").write_bytes(data)
        lamar = self.root / "models" / "model_101_classifier" / "best_model" / "model.safetensors"
        lamar.parent.mkdir(parents=True)
        lamar.write_bytes(lamar_data)
        with patch.object(assets, "ESM_ASSETS", {"config.json": (len(data), digest(data))}), \
                patch.object(assets, "LAMAR_SIZE", len(lamar_data)), patch.object(assets, "LAMAR_SHA256", digest(lamar_data)), \
                patch.object(assets.urllib.request, "urlopen", side_effect=AssertionError("No network for verified files")):
            checks = assets.ensure_models(self.root)
        self.assertEqual(checks["esm2/config.json"], {"bytes": len(data), "sha256": digest(data)})
        self.assertEqual(checks["lamar/model.safetensors"], {"bytes": len(lamar_data), "sha256": digest(lamar_data)})
        self.assertFalse((self.root / ".runtime/cache/model-downloads/install.lock").exists())


if __name__ == "__main__":
    unittest.main()
