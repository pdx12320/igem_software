"""Loopback-only ORCA desktop workflow; standard library, one worker at a time."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
from pathlib import Path
import secrets
import subprocess
import sys
import threading
from urllib.parse import parse_qs, urlsplit
import uuid
import webbrowser

MAX_JSON_BYTES = 64 * 1024
DOWNLOAD_FILES = ("protein-ranking.csv", "lamar-sites.csv", "combined-results.csv", "manifest.json")
LOCAL_APP_DIR = Path(__file__).resolve().parent


def utc_now():
    return datetime.now(timezone.utc).isoformat()


class RequestError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def input_path(value, label):
    if not isinstance(value, str) or not value.strip() or any(ord(char) < 32 for char in value):
        raise RequestError(400, label + " must be an existing local file path.")
    try:
        path = Path(value).expanduser().resolve(strict=True)
    except (OSError, ValueError, RuntimeError) as exc:
        raise RequestError(400, label + " does not identify a readable local file.") from exc
    if not path.is_file():
        raise RequestError(400, label + " must identify a file, not a directory.")
    try:
        with path.open("rb") as source:
            source.read(1)
    except OSError as exc:
        raise RequestError(400, label + " is not readable.") from exc
    return path


class JobManager:
    def __init__(self, root, *, web_only=False, process_factory=subprocess.Popen,
                 cancel_grace=10.0):
        self.root = Path(root).resolve()
        self.web_only = web_only
        self.process_factory = process_factory
        self.cancel_grace = cancel_grace
        self.lock = threading.RLock()
        self.jobs = {}
        self.active_id = None

    def start(self, payload):
        if self.web_only:
            raise RequestError(403, "This is a UI preview. Model runs are disabled.")
        if not isinstance(payload, dict) or set(payload) - {"csvPath", "fastaPath", "species"}:
            raise RequestError(400, "Expected CSV path, FASTA path and an optional species label.")
        csv_path = input_path(payload.get("csvPath"), "Website CSV path")
        fasta_path = input_path(payload.get("fastaPath"), "Species FASTA path")
        if csv_path == fasta_path:
            raise RequestError(400, "CSV and FASTA must be separate input files.")
        # Isolated Python deliberately omits the script directory from sys.path.
        # Add only this package's known module directory, never an input directory.
        if str(LOCAL_APP_DIR) not in sys.path:
            sys.path.insert(0, str(LOCAL_APP_DIR))
        from csv_input import load_design_csv
        try:
            load_design_csv(csv_path)
            with fasta_path.open("r", encoding="utf-8-sig") as fasta:
                first = next((line.strip() for line in fasta if line.strip()), "")
            if not first.startswith(">") or not first[1:].strip():
                raise ValueError("Species FASTA must begin with a named transcript header.")
        except (OSError, ValueError, UnicodeError) as exc:
            raise RequestError(400, str(exc)) from exc
        species = payload.get("species", "")
        if not isinstance(species, str) or len(species) > 200 or any(ord(char) < 32 for char in species):
            raise RequestError(400, "Species label must contain at most 200 characters without controls.")
        worker = self.root / "local_app" / "run_analysis.py"
        if not worker.is_file():
            raise RequestError(503, "The analysis worker is missing from this package.")
        with self.lock:
            if self.active_id is not None:
                raise RequestError(409, "A local run is already active. Wait for it or cancel it first.")
            job_id = uuid.uuid4().hex
            directory = self.root / "results" / job_id
            directory.mkdir(parents=True, exist_ok=False)
            log = (directory / "worker.log").open("xb")
            job = {"id": job_id, "directory": directory, "status": "running",
                   "message": "Starting local models.", "createdAt": utc_now(), "finishedAt": None,
                   "cancelRequested": False, "process": None, "log": log, "exitCode": None}
            self.jobs[job_id] = job
            argv = [sys.executable, "-I", "-B", str(worker), "--root", str(self.root),
                    "--csv", str(csv_path), "--fasta", str(fasta_path),
                    "--species", species.strip(), "--output", str(directory)]
            try:
                job["process"] = self.process_factory(argv, cwd=str(self.root), stdout=log,
                                                       stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            except (OSError, ValueError) as exc:
                log.close()
                job.update(status="failed", message="The local analysis worker could not start: " + str(exc), finishedAt=utc_now())
                raise RequestError(500, job["message"]) from exc
            self.active_id = job_id
            threading.Thread(target=self._monitor, args=(job_id,), daemon=True).start()
            return self._snapshot(job)

    @staticmethod
    def _progress(job):
        try:
            path = job["directory"] / "progress.json"
            if path.stat().st_size > MAX_JSON_BYTES:
                return {}
            with path.open("r", encoding="utf-8") as source:
                value = json.load(source)
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError, UnicodeError):
            # The worker may be writing this file; retain the last server state.
            return {}

    @staticmethod
    def _outputs_present(job):
        for filename in DOWNLOAD_FILES:
            path = job["directory"] / filename
            if path.is_symlink() or not path.is_file() or path.resolve().parent != job["directory"]:
                return False
        return True

    def _monitor(self, job_id):
        job = self.jobs[job_id]
        code = job["process"].wait()
        job["log"].close()
        progress = self._progress(job)
        with self.lock:
            job["exitCode"] = code
            if job["cancelRequested"]:
                job.update(status="cancelled", message="Run cancelled. Partial files and worker.log remain in its result folder.")
            elif code == 0 and progress.get("status") == "succeeded" and self._outputs_present(job):
                job.update(status="succeeded", message="Local analysis completed.")
            else:
                message = progress.get("message")
                job.update(status="failed", message=message if isinstance(message, str) and message else
                           "The worker did not complete successfully. See worker.log in the result folder.")
            job["finishedAt"] = utc_now()
            if self.active_id == job_id:
                self.active_id = None

    def _snapshot(self, job):
        progress = self._progress(job)
        message = job["message"]
        if job["status"] == "running" and isinstance(progress.get("message"), str):
            message = progress["message"]
        counts = {}
        for key in ("completedSites", "totalSites"):
            value = progress.get(key)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                counts[key] = value
        return {"id": job["id"], "status": job["status"], "message": message,
                "progress": counts, "createdAt": job["createdAt"], "finishedAt": job["finishedAt"],
                "exitCode": job["exitCode"], "outputDirectory": str(job["directory"]),
                "downloads": list(DOWNLOAD_FILES) if job["status"] == "succeeded" else []}

    def status(self):
        with self.lock:
            latest = next(reversed(self.jobs.values())) if self.jobs else None
            return {"webOnly": self.web_only, "job": self._snapshot(latest) if latest else None}

    def cancel(self, payload):
        if not isinstance(payload, dict) or set(payload) != {"jobId"}:
            raise RequestError(400, "Expected the active job ID.")
        with self.lock:
            if not self.active_id or payload["jobId"] != self.active_id:
                raise RequestError(409, "That job is no longer the active local run.")
            job = self.jobs[self.active_id]
            if not job["cancelRequested"]:
                # Only this task's worker is asked to stop; partial data is retained.
                try:
                    with (job["directory"] / "cancel.request").open("x", encoding="utf-8") as marker:
                        marker.write(utc_now() + "\n")
                except FileExistsError:
                    pass
                job.update(cancelRequested=True, status="cancelling", message="Cancelling the local run.")
                threading.Thread(target=self._stop_worker, args=(job,), daemon=True).start()
            return self._snapshot(job)

    def _stop_worker(self, job):
        process = job["process"]
        try:
            process.wait(timeout=self.cancel_grace)
            return
        except subprocess.TimeoutExpired:
            pass
        if process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if process.poll() is None:
                process.kill()

    def download_path(self, job_id, filename):
        if filename not in DOWNLOAD_FILES:
            raise RequestError(404, "Unknown download.")
        with self.lock:
            job = self.jobs.get(job_id)
            if not job or job["status"] != "succeeded":
                raise RequestError(409, "Downloads are available only after a successful completed run.")
            path = job["directory"] / filename
            if path.is_symlink() or not path.is_file() or path.resolve().parent != job["directory"]:
                raise RequestError(404, "The completed output file is unavailable.")
            return path

    def close(self):
        with self.lock:
            active = self.active_id
        if active:
            self.cancel({"jobId": active})
            # The launcher must not exit while its worker is still alive.
            self._stop_worker(self.jobs[active])


def make_handler(manager, token, ui_path):
    class Handler(BaseHTTPRequestHandler):
        server_version = "ORCA-local"

        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, *_args):
            # Never log capability tokens or copied local paths.
            pass

        def _check_request(self, protected=False):
            port = self.server.server_address[1]
            hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            host_values = self.headers.get_all("Host", [])
            if len(host_values) != 1 or host_values[0].lower() not in hosts:
                raise RequestError(403, "Only the local ORCA origin is accepted.")
            origins = self.headers.get_all("Origin", [])
            if len(origins) > 1 or (origins and origins[0] not in {"http://" + host for host in hosts}):
                raise RequestError(403, "Cross-origin requests are not accepted.")
            if self.headers.get("Sec-Fetch-Site") == "cross-site":
                raise RequestError(403, "Cross-site requests are not accepted.")
            if protected:
                if self.command == "POST" and len(origins) != 1:
                    raise RequestError(403, "Local API requests require the local page origin.")
                parts = urlsplit(self.path)
                if parts.path.startswith("/download/"):
                    query = parse_qs(parts.query, keep_blank_values=True)
                    candidates = query.get("token", []) if set(query) == {"token"} else []
                else:
                    candidates = self.headers.get_all("X-ORCA-Token", [])
                if len(candidates) != 1 or not hmac.compare_digest(candidates[0].encode("utf-8"), token.encode("ascii")):
                    raise RequestError(403, "A valid local page token is required.")

        def _headers(self, status, content_type, length, **extra):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
            for key, value in extra.items():
                self.send_header(key.replace("_", "-"), value)
            self.end_headers()

        def _json(self, status, value):
            body = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self._headers(status, "application/json; charset=utf-8", len(body))
            self.wfile.write(body)

        def _body(self):
            if self.headers.get("Transfer-Encoding"):
                raise RequestError(400, "Chunked API requests are not accepted.")
            lengths = self.headers.get_all("Content-Length", [])
            if len(lengths) != 1 or not lengths[0].isdigit():
                raise RequestError(411, "A valid Content-Length is required.")
            length = int(lengths[0])
            if length > MAX_JSON_BYTES:
                raise RequestError(413, "API JSON input exceeds 64 KiB.")
            if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
                raise RequestError(415, "Expected application/json.")
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise RequestError(400, "The API request body is incomplete.")
            try:
                return json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeError) as exc:
                raise RequestError(400, "Expected valid UTF-8 JSON.") from exc

        def do_GET(self):
            try:
                path = urlsplit(self.path).path
                self._check_request(path.startswith(("/api/", "/download/")))
                if path == "/":
                    body = Path(ui_path).read_text(encoding="utf-8").replace("__ORCA_TOKEN__", token).encode("utf-8")
                    self._headers(200, "text/html; charset=utf-8", len(body))
                    self.wfile.write(body)
                elif path == "/api/status":
                    self._json(200, manager.status())
                elif path.startswith("/download/"):
                    pieces = path.split("/")
                    if len(pieces) != 4:
                        raise RequestError(404, "Unknown download.")
                    source = manager.download_path(pieces[2], pieces[3])
                    content_type = "application/json" if source.suffix == ".json" else "text/csv; charset=utf-8"
                    with source.open("rb") as stream:
                        self._headers(200, content_type, source.stat().st_size,
                                      Content_Disposition=f'attachment; filename="{source.name}"')
                        while block := stream.read(64 * 1024):
                            self.wfile.write(block)
                else:
                    raise RequestError(404, "Not found.")
            except RequestError as exc:
                self._json(exc.status, {"error": str(exc)})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except OSError:
                self._json(500, {"error": "A local file could not be read."})

        def do_POST(self):
            try:
                self._check_request(True)
                path = urlsplit(self.path).path
                payload = self._body()
                if path == "/api/run":
                    self._json(202, {"job": manager.start(payload)})
                elif path == "/api/cancel":
                    self._json(202, {"job": manager.cancel(payload)})
                else:
                    raise RequestError(404, "Unknown API route.")
            except RequestError as exc:
                self._json(exc.status, {"error": str(exc)})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except OSError:
                self._json(500, {"error": "The local run could not access its result folder."})

        def do_OPTIONS(self):
            self._json(405, {"error": "Cross-origin API access is disabled."})

    return Handler


def main(argv=None):
    parser = argparse.ArgumentParser(description="ORCA local ESM-2 ranking and LaMAR analysis")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--web-only", action="store_true", help="Preview the interface without allowing model runs")
    parser.add_argument("--self-check", action="store_true", help="Verify package models and small forward passes")
    args = parser.parse_args(argv)
    root = args.root.resolve()
    if args.self_check:
        try:
            if args.web_only:
                page = (root / "ui" / "index.html").read_text(encoding="utf-8")
                if "__ORCA_TOKEN__" not in page or 'id="run-form"' not in page:
                    raise ValueError("The local interface is missing its form or local access token placeholder.")
                print(json.dumps({"status": "passed", "scope": "local interface only", "modelChecks": False}))
                return 0
            if str(LOCAL_APP_DIR) not in sys.path:
                sys.path.insert(0, str(LOCAL_APP_DIR))
            from pipeline import self_check_package
            result = self_check_package(root)
            print(json.dumps(result, ensure_ascii=False))
            return 1 if isinstance(result, dict) and (result.get("status") == "failed" or result.get("passed") is False) else 0
        except Exception as exc:
            print(json.dumps({"status": "failed", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
            return 1
    if not 0 <= args.port <= 65535:
        parser.error("--port must be between 0 and 65535")
    manager = JobManager(root, web_only=args.web_only)
    token = secrets.token_hex(32)
    handler = make_handler(manager, token, root / "ui" / "index.html")
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    server.daemon_threads = True
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    print("ORCA local is ready: " + url, flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        manager.close()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
