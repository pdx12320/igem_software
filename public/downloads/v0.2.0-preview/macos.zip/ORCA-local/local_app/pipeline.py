"""Local CSV + species FASTA analysis using the original pinned model definitions."""
from __future__ import annotations

import csv
import gc
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time

PACKAGE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PACKAGE))
sys.path.insert(0, str(PACKAGE / 'runtime'))
from local_app.csv_input import CSV_COLUMNS, load_design_csv
from local_app.esm_ranker import (FrozenRanker, build_model as build_esm,
    generate_reference_logp, compare_reference_logp, load_reference_logp,
    save_reference_logp, rank_candidates, verify_model_assets, ESM_REVISION,
    ESM_CHECKPOINT_SHA256, FEATURE_DEFINITION)
from runtime.contracts import iter_fasta
from runtime.model_runner import (build_model as build_lamar, center_window,
    score_window, sha256_file, verify_assets, atomic_json, self_check,
    MODEL_VERSION, CHECKPOINT_SHA256, CORE_VERSIONS, MODEL_ALPHABET)

# This is only a float32 CPU-vs-original-GPU reproduction tolerance. The
# checkpoint, Ridge coefficients, normalization and scientific scores are fixed.
NUMERICAL_REPRODUCTION_ATOL = 1e-4
RANK_COLUMNS = ['candidate_id','protein_sequence','selected','rank','s_hat_raw',
    'esm2_score','c295_hat','c388_hat','c871_hat','status','reason',
    'esm_model_version','esm_checkpoint_sha256','ridge_checkpoint_sha256']
SITE_COLUMNS = ['record_id','site_position_1based','context_101nt','lamar_score',
    'lamar_status','boundary_padded','reason','species','reference_sha256','model_version']


def protected(value):
    if value is None: return ''
    if isinstance(value, bool): return str(value).lower()
    if isinstance(value, (int, float)): return value if math.isfinite(value) else ''
    value = str(value)
    return "'" + value if re.match(r'^[\s\x00-\x1f]*[=+@-]', value) else value


def writer(file, columns):
    stream = Path(file).open('x', encoding='utf-8-sig', newline='')
    output = csv.DictWriter(stream, fieldnames=columns, lineterminator='\r\n')
    output.writeheader()
    return stream, output


def write_row(output, columns, values):
    output.writerow({key: protected(values.get(key)) for key in columns})


def self_check_package(root):
    root = Path(root).resolve()
    frozen = FrozenRanker(root / 'models/puf-ranker-492.json')
    lamar = self_check(root)
    model, tokenizer = build_esm(root / 'models/esm2_t12_35M_UR50D')
    fixture = generate_reference_logp(model, tokenizer, frozen.reference493,
                                     positions=[0,35,36,39,491,492])
    comparison = compare_reference_logp(fixture, frozen)
    if comparison['maxAbsoluteDifference'] > NUMERICAL_REPRODUCTION_ATOL:
        raise ValueError('Pinned ESM-2 features failed CPU numerical reproduction.')
    return {'status':'passed','lamar':lamar,'esm2':comparison,
            'numericalReproductionAtol':NUMERICAL_REPRODUCTION_ATOL,
            'scope':'small synthetic LaMAR and six reference-position ESM-2 checks',
            'biologicalValidation':False}


def run_analysis(root, csv_path, fasta_path, species, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any((output / name).exists() for name in ('manifest.json','protein-ranking.csv','lamar-sites.csv','combined-results.csv','progress.json','design-input.csv')):
        raise ValueError('Use a new output directory. Existing results are retained.')
    started = time.monotonic()
    total_sites = completed_sites = 0
    phase = 'validation'
    files = []
    counts = {'candidates':0,'rankedCandidates':0,'incompatibleCandidates':0,
              'records':0,'bases':0,'totalSites':0,'scoredSites':0,'unscoredSites':0,'paddedSites':0}
    manifest = {'kind':'orca-local-analysis','schemaVersion':1,'status':'running',
                'softwareVersion':'0.2.0','models':{},'counts':counts,
                'biologicalValidation':False,'scoreCombination':'separate model outputs; no joint probability'}

    def cancelled(): return (output / 'cancel.request').exists()
    def check_cancel():
        if cancelled(): raise InterruptedError('Cancelled; partial results and original inputs are retained.')
    def progress(message, status='running'):
        atomic_json(output / 'progress.json', {'status':status,'message':message,'phase':phase,
            'completedSites':completed_sites,'totalSites':total_sites,'elapsedSeconds':round(time.monotonic()-started,3)})

    try:
        progress('Checking CSV and species FASTA.')
        import torch
        actual_versions = {key:importlib.metadata.version(key) for key in CORE_VERSIONS}
        if any(value != CORE_VERSIONS[key] and not (key == 'torch' and value == '2.0.1+cpu') for key,value in actual_versions.items()):
            raise ValueError('Inference dependencies differ from the pinned model environment.')
        torch.set_num_threads(2)
        if torch.get_num_interop_threads() != 1: torch.set_num_interop_threads(1)
        inputs = load_design_csv(csv_path)
        csv_path = Path(inputs['source']['path'])
        fasta = Path(fasta_path).expanduser().resolve(strict=True)
        if not fasta.is_file(): raise ValueError('FASTA path must identify a file.')
        fasta_hash = sha256_file(fasta)
        species = species.strip() or inputs['reference']['species'] or 'Unspecified'
        if inputs['reference']['sha256'] and inputs['reference']['sha256'] != fasta_hash:
            raise ValueError('FASTA differs from the reference recorded in the website CSV.')
        target = inputs['target']
        target_found = False
        for record, sequence in iter_fasta(fasta):
            check_cancel()
            counts['records'] += 1; counts['bases'] += len(sequence)
            total_sites += sequence.count('C')
            if record == target['id']:
                if sequence != target['sequence'].replace('U','T'):
                    raise ValueError('FASTA record with the target ID differs from the full target RNA.')
                target_found = True
        counts['totalSites'] = total_sites
        manifest['inputs'] = {'csvSha256':inputs['source']['sha256'],
            'fastaSha256':fasta_hash,'fastaBytes':fasta.stat().st_size,
            'species':species,'target':target,'csvRows':inputs['source']['rowCount'],
            'targetReferenceRecordFound':target_found,'warnings':inputs['warnings']}
        with (output / 'design-input.csv').open('xb') as saved:
            saved.write(Path(csv_path).read_bytes())
        candidates = inputs['candidates']
        counts['candidates'] = len(candidates)
        eligible = [c for c in candidates if len(c['protein']) == 492 or (len(c['protein']) == 493 and c['protein'].endswith('G'))]
        counts['incompatibleCandidates'] = len(candidates) - len(eligible)
        frozen = FrozenRanker(root / 'models/puf-ranker-492.json')
        verify_model_assets(root / 'models/esm2_t12_35M_UR50D')
        rank_result = None
        phase = 'esm2'
        if eligible:
            cache_dir = root / '.runtime/cache/esm2'
            cache_dir.mkdir(parents=True, exist_ok=True)
            cache = cache_dir / 'reference-cpu-torch2.0.1-transformers4.32.1.json'
            if cache.exists():
                features = load_reference_logp(cache)
                if features['metadata'].get('torch') not in ('2.0.1','2.0.1+cpu') or features['metadata'].get('transformers') != '4.32.1':
                    raise ValueError('Reference feature cache uses a different inference environment.')
                progress('Reusing features previously computed by the installed ESM-2 model.')
            else:
                progress('Loading ESM-2 and computing the original reference features.')
                esm, tokenizer = build_esm(root / 'models/esm2_t12_35M_UR50D')
                features = generate_reference_logp(esm, tokenizer, frozen.reference493,
                    progress=lambda n,total:progress(f'ESM-2 reference positions: {n}/{total}'), cancelled=cancelled)
                del esm, tokenizer; gc.collect()
            rank_result = rank_candidates(eligible, frozen, features,
                                          numerical_tolerance=NUMERICAL_REPRODUCTION_ATOL)
            if not cache.exists(): save_reference_logp(cache, features)
            counts['rankedCandidates'] = len(rank_result['rows'])
            manifest['models']['esm2'] = {k:v for k,v in rank_result.items() if k != 'rows'}
            manifest['models']['esm2']['featureDefinition'] = FEATURE_DEFINITION
        else:
            manifest['models']['esm2'] = {'status':'no compatible candidates','revision':ESM_REVISION,
                'checkpointSha256':ESM_CHECKPOINT_SHA256,'scope':'fixed 492/493-aa scaffold'}
        check_cancel()
        rank_lookup = {row['id']:row for row in (rank_result or {}).get('rows',[])}
        rank_rows = []
        for candidate in candidates:
            row = rank_lookup.get(candidate['id'])
            rank_rows.append({'candidate_id':candidate['id'],'protein_sequence':candidate['protein'],
                'selected':candidate['selected'],'rank':row['rank'] if row else None,
                's_hat_raw':row['S_hat'] if row else None,'esm2_score':row['ESM2_score'] if row else None,
                'c295_hat':row['C295_hat'] if row else None,'c388_hat':row['C388_hat'] if row else None,
                'c871_hat':row['C871_hat'] if row else None,'status':'scored' if row else 'incompatible_scaffold',
                'reason':'' if row else 'Frozen ranker supports the fixed 492-aa scaffold or its 493-aa terminal-G form.',
                'esm_model_version':frozen.model_version,'esm_checkpoint_sha256':ESM_CHECKPOINT_SHA256,
                'ridge_checkpoint_sha256':manifest['models']['esm2'].get('sourceCheckpointSha256')})
        ranks_file, ranks_writer = writer(output / 'protein-ranking.csv', RANK_COLUMNS); files.append(ranks_file)
        for row in sorted(rank_rows, key=lambda row:(row['rank'] is None,row['rank'] or 0,row['candidate_id'])):
            write_row(ranks_writer,RANK_COLUMNS,row)
        ranks_file.close()
        phase = 'lamar'
        progress('Verifying and loading LaMAR. Every C in the FASTA is retained.')
        asset_checks = verify_assets(root)
        lamar, tokenizer, runtime_versions = build_lamar(root)
        manifest['models']['lamar'] = {'modelVersion':MODEL_VERSION,'checkpointSha256':CHECKPOINT_SHA256,
            'assets':asset_checks,'runtimeVersions':runtime_versions,'windowNt':101,
            'centerPosition1Based':51,'padding':'N','scoreType':'raw_ranking_score',
            'motifFilter':False,'scoreCutoff':None,'topKCutoff':None,'PUFConditioned':False}
        sites_file, sites_writer = writer(output / 'lamar-sites.csv',SITE_COLUMNS); files.append(sites_file)
        combined_file, combined_writer = writer(output / 'combined-results.csv',CSV_COLUMNS); files.append(combined_file)
        common = {'target_id':target['id'],'target_position_1based':target['position'],
            'target_sequence':target['sequence'],'design_id':target['designId'],
            'library_version':target['libraryVersion'],'recognition_rna':target['motif'],
            'reference_name':fasta.name,'reference_species':species,'reference_kind':inputs['reference']['kind'],
            'reference_sha256':fasta_hash,'coordinate_system':'1-based sequence-record coordinates'}
        selected = next((candidate for candidate in candidates if candidate['selected']),None)
        selected_rank = rank_lookup.get(selected['id']) if selected else None
        def score_columns(row):
            return {'esm_rank':row['rank'] if row else None,'s_hat_raw':row['S_hat'] if row else None,
                'esm2_score':row['ESM2_score'] if row else None,'c295_hat':row['C295_hat'] if row else None,
                'c388_hat':row['C388_hat'] if row else None,'c871_hat':row['C871_hat'] if row else None,
                'esm_model_version':frozen.model_version,'esm_scope':'fixed-assay-C295-C388-C871',
                'esm_status':'scored' if row else 'incompatible_scaffold',
                'esm_reference_sha256':(rank_result or {}).get('referenceSha256'),
                'esm_source':'local-recomputed-esm2-reference',
                'esm_checkpoint_sha256':(rank_result or {}).get('sourceCheckpointSha256'),
                'esm_compatibility_version':'drop-fixed-terminal-g-v1'}
        target_row = dict(common,record_type='target',transcript_id=target['id'],
            binding_rna=target['motif'],binding_start_1based=target['bindingStart'],
            binding_end_1based=target['bindingEnd'],site_position_1based=target['position'],
            site_offset_nt=target['position']-target['bindingEnd'],protein_candidate_id=selected['id'] if selected else '',
            protein_sequence=selected['protein'] if selected else '',protein_selected=bool(selected),
            scaffold_id=target['scaffoldId'],trm_assignments=target['trmAssignments'],**score_columns(selected_rank))
        target_score = None
        target_context = None
        if target_found:
            window, _ = center_window(target['sequence'].replace('U','T'),target['position']-1)
            target_context = window.replace('T','U')
            if not set(window)-MODEL_ALPHABET: target_score = score_window(lamar,tokenizer,window)
            target_row.update(context_101nt=target_context,lamar_score=target_score,
                lamar_score_available=target_score is not None,lamar_status='scored' if target_score is not None else 'unscored',
                lamar_score_type='raw_ranking_score',lamar_model_version=MODEL_VERSION,
                lamar_reference_set=fasta.name,lamar_scope='uploaded-sequence-fasta',lamar_reference_sha256=fasta_hash)
        # Bind the target score only to its exact verified record and coordinate.
        write_row(combined_writer,CSV_COLUMNS,target_row)
        for candidate in candidates:
            write_row(combined_writer,CSV_COLUMNS,dict(common,record_type='protein_candidate',
                protein_candidate_id=candidate['id'],protein_sequence=candidate['protein'],
                protein_selected=candidate['selected'],scaffold_id=candidate['scaffoldId'],
                trm_assignments=candidate['trmAssignments'],**score_columns(rank_lookup.get(candidate['id']))))
        last_progress = 0.0
        for record, sequence in iter_fasta(fasta):
            for position, base in enumerate(sequence):
                if base != 'C':
                    if position % 10000 == 0: check_cancel()
                    continue
                check_cancel()
                window, boundary = center_window(sequence,position)
                unsupported = sorted(set(window)-MODEL_ALPHABET)
                exact_target = target_found and record == target['id'] and position+1 == target['position']
                score = None if unsupported else target_score if exact_target else score_window(lamar,tokenizer,window)
                status = 'unscored' if unsupported else 'scored'
                reason = 'Unsupported context symbols: '+''.join(unsupported) if unsupported else ''
                context = window.replace('T','U')
                counts['paddedSites'] += int(boundary)
                counts['unscoredSites' if unsupported else 'scoredSites'] += 1
                write_row(sites_writer,SITE_COLUMNS,{'record_id':record,'site_position_1based':position+1,
                    'context_101nt':context,'lamar_score':score,'lamar_status':status,
                    'boundary_padded':boundary,'reason':reason,'species':species,
                    'reference_sha256':fasta_hash,'model_version':MODEL_VERSION})
                write_row(combined_writer,CSV_COLUMNS,dict(common,record_type='external_site',transcript_id=record,
                    site_position_1based=position+1,context_101nt=context,lamar_score=score,
                    lamar_score_available=score is not None,lamar_score_type='raw_ranking_score',
                    lamar_status=status,lamar_model_version=MODEL_VERSION,
                    lamar_reference_set=fasta.name,lamar_scope='uploaded-sequence-fasta',lamar_reference_sha256=fasta_hash))
                completed_sites += 1
                if time.monotonic()-last_progress>=0.5:
                    progress(f'LaMAR C sites: {completed_sites}/{total_sites}');last_progress=time.monotonic()
        check_cancel()
        if completed_sites!=total_sites or counts['scoredSites']+counts['unscoredSites']!=total_sites:
            raise ValueError('Output site counts differ from the complete FASTA.')
        if sha256_file(fasta)!=fasta_hash or sha256_file(csv_path)!=inputs['source']['sha256']:
            raise ValueError('An original input changed during the run; completed results are unavailable.')
        for stream in files:
            if not stream.closed: stream.close()
        manifest.update(status='succeeded',elapsedSeconds=round(time.monotonic()-started,3),
            device='cpu',threads=2,python=platform.python_version(),platform=platform.platform())
        manifest['outputFiles'] = {name:{'sha256':sha256_file(output/name),'bytes':(output/name).stat().st_size}
            for name in ('protein-ranking.csv','lamar-sites.csv','combined-results.csv')}
        with (output/'manifest.json').open('x',encoding='utf-8') as stream:
            json.dump(manifest,stream,ensure_ascii=False,allow_nan=False,indent=2);stream.write('\n')
        progress('Complete. Download the ranking, LaMAR sites and combined CSV.',status='succeeded')
        return manifest
    except BaseException as error:
        status = 'cancelled' if isinstance(error,(InterruptedError,KeyboardInterrupt)) else 'failed'
        manifest.update(status=status,message=str(error),elapsedSeconds=round(time.monotonic()-started,3))
        if not (output/'manifest.json').exists():
            with (output/'manifest.json').open('x',encoding='utf-8') as stream:
                json.dump(manifest,stream,ensure_ascii=False,allow_nan=False,indent=2);stream.write('\n')
        progress(str(error) or status,status=status)
        raise
    finally:
        for stream in files:
            if not stream.closed: stream.close()
