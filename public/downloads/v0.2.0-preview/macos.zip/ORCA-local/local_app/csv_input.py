"""Read ORCA's scientist CSV as model inputs, without reusing saved scores.

The column names and coordinate convention are the unchanged schema v1 from
website/lib/scientist-csv.ts. Protein strings remain in their exported coordinate
system; the model runner owns any audited 492/493-aa compatibility view. Only a
leading spreadsheet apostrophe on a known sequence cell may be removed, and only
when the rest of that cell is a valid sequence. Identifiers are never unescaped.
"""
from __future__ import annotations

import csv
import hashlib
import io
from pathlib import Path
import re
import sys
from typing import TypedDict


CSV_COLUMNS = (
    "record_type", "target_id", "target_position_1based", "target_sequence",
    "design_id", "protein_candidate_id", "protein_selected", "protein_sequence",
    "scaffold_id", "trm_assignments", "library_version", "recognition_rna",
    "transcript_id", "binding_rna", "binding_start_1based", "binding_end_1based",
    "site_position_1based", "site_offset_nt", "binding_mismatches", "context_101nt",
    "esm_rank", "s_hat_raw", "esm2_score", "c295_hat", "c388_hat", "c871_hat",
    "esm_model_version", "esm_scope", "esm_status", "esm_reference_sha256", "esm_source",
    "esm_checkpoint_sha256", "esm_compatibility_version",
    "lamar_score", "lamar_score_available", "lamar_score_type", "lamar_status",
    "lamar_model_version", "lamar_reference_set", "lamar_scope", "lamar_reference_sha256",
    "reference_name", "reference_species", "reference_kind", "reference_sha256",
    "coordinate_system",
)
COORDINATE_SYSTEM = "1-based sequence-record coordinates"
RECORD_TYPES = {"target", "protein_candidate", "binding_site", "binding_hit_no_c", "external_site"}
AA = re.compile(r"[ACDEFGHIKLMNPQRSTVWY]{1,2000}\Z")
RNA = re.compile(r"[ACGU]+\Z")
REFERENCE_RNA = re.compile(r"[ACGURYSWKMBDHVN]+\Z")
IDENTIFIER = re.compile(r"[^\x00-\x1f\x7f]+\Z")
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")


class TargetInput(TypedDict):
    id: str
    sequence: str
    position: int
    motif: str
    bindingStart: int
    bindingEnd: int
    designId: str
    scaffoldId: str
    trmAssignments: str
    libraryVersion: str
    selectedCandidateId: str | None


class ProteinCompatibility(TypedDict):
    length: int
    fixed492Compatible: bool
    terminalG493Compatible: bool
    version: str | None
    referenceSha256: str | None
    sourceCheckpointSha256: str | None


class ProteinInput(TypedDict):
    id: str
    protein: str
    selected: bool
    scaffoldId: str
    trmAssignments: str
    compatibility: ProteinCompatibility


class ReferenceInput(TypedDict):
    name: str
    species: str
    kind: str
    sha256: str | None


class CsvSource(TypedDict):
    path: str | None
    sha256: str
    sizeBytes: int
    rowCount: int


class DesignInput(TypedDict):
    schemaVersion: int
    target: TargetInput
    candidates: list[ProteinInput]
    reference: ReferenceInput
    source: CsvSource
    warnings: list[str]


def _error(row: int, message: str) -> ValueError:
    return ValueError(f"CSV record {row}: {message}")


def _identifier(value: str, field: str, row: int, maximum: int = 300) -> str:
    if not value.strip() or len(value) > maximum or not IDENTIFIER.fullmatch(value):
        raise _error(row, f"{field} must be a nonempty identifier without control characters.")
    return value


def _sequence(value: str, field: str, row: int, pattern: re.Pattern[str],
              *, optional: bool = False) -> str:
    if optional and value == "":
        return ""
    # Do not strip apostrophes from IDs, metadata, numeric cells or arbitrary text.
    # A second apostrophe, a formula or whitespace remains invalid sequence input.
    if value.startswith("'") and pattern.fullmatch(value[1:]):
        value = value[1:]
    if not pattern.fullmatch(value):
        raise _error(row, f"{field} contains invalid sequence characters or an empty sequence.")
    return value


def _integer(value: str, field: str, row: int, *, optional: bool = False,
             minimum: int = 1) -> int | None:
    if optional and value == "":
        return None
    if not re.fullmatch(r"0|[1-9][0-9]*", value):
        raise _error(row, f"{field} must be an integer in the recorded coordinate system.")
    result = int(value)
    if not minimum <= result <= 2**53 - 1:
        raise _error(row, f"{field} is outside the valid integer range.")
    return result


def _boolean(value: str, field: str, row: int) -> bool:
    if value not in ("true", "false"):
        raise _error(row, f"{field} must be true or false.")
    return value == "true"


def _hash(value: str, field: str, row: int) -> str | None:
    if value == "":
        return None
    if not SHA256.fullmatch(value):
        raise _error(row, f"{field} must be a SHA-256 value or blank.")
    return value.lower()


def _protein(row: dict[str, str], number: int, candidate_id: str,
             selected: bool, protein: str) -> ProteinInput:
    return {
        "id": _identifier(candidate_id, "protein_candidate_id", number, 120),
        "protein": protein, "selected": selected,
        "scaffoldId": row["scaffold_id"], "trmAssignments": row["trm_assignments"],
        "compatibility": {
            "length": len(protein), "fixed492Compatible": len(protein) == 492,
            "terminalG493Compatible": len(protein) == 493 and protein.endswith("G"),
            "version": row["esm_compatibility_version"] or None,
            "referenceSha256": _hash(row["esm_reference_sha256"], "esm_reference_sha256", number),
            "sourceCheckpointSha256": _hash(row["esm_checkpoint_sha256"], "esm_checkpoint_sha256", number),
        },
    }


def _validate_site_row(row: dict[str, str], number: int) -> None:
    """Check saved evidence shape; none of its scores becomes a model input."""
    if row["transcript_id"]:
        _identifier(row["transcript_id"], "transcript_id", number)
    binding = _sequence(row["binding_rna"], "binding_rna", number, RNA, optional=True)
    start = _integer(row["binding_start_1based"], "binding_start_1based", number, optional=True)
    end = _integer(row["binding_end_1based"], "binding_end_1based", number, optional=True)
    site = _integer(row["site_position_1based"], "site_position_1based", number, optional=True)
    offset = _integer(row["site_offset_nt"], "site_offset_nt", number, optional=True)
    _integer(row["binding_mismatches"], "binding_mismatches", number, optional=True, minimum=0)
    if end is not None and (start is None or end < start):
        raise _error(number, "The binding interval has no valid start or has an end before its start.")
    if binding and start is not None and end is not None and len(binding) != end - start + 1:
        raise _error(number, "binding_rna length differs from the binding interval.")
    if offset is not None and (site is None or end is None or site - end != offset):
        raise _error(number, "site_offset_nt differs from site_position_1based minus binding_end_1based.")
    context = _sequence(row["context_101nt"], "context_101nt", number, REFERENCE_RNA, optional=True)
    if context and (len(context) != 101 or context[50] != "C"):
        raise _error(number, "context_101nt must contain 101 bases with C at index 50.")
    if row["record_type"] == "binding_hit_no_c" and site is not None:
        raise _error(number, "binding_hit_no_c must not contain a site coordinate.")


def parse_design_csv(data: bytes, *, source_path: str | None = None) -> DesignInput:
    """Validate a complete website CSV and return fresh-run inputs as plain dicts.

    Existing score and rank columns are intentionally excluded from the returned
    input schema. Unranked candidate rows are accepted. If the CSV has an assembled
    selected protein but no matching candidate row, that selected protein is added
    using its existing candidate ID or design ID; no sequence or score is invented.
    """
    if not isinstance(data, bytes):
        raise TypeError("CSV input must be bytes.")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("The design CSV must use UTF-8 encoding.") from exc
    if "\x00" in text:
        raise ValueError("The design CSV contains a NUL character.")
    # The default csv module limit is smaller than a valid full target transcript.
    # This is a parser capacity change only, not a sequence or model threshold.
    # Python 3.10 accepts a C long here, which is 32-bit on 64-bit Windows.
    old_limit = csv.field_size_limit()
    csv.field_size_limit(min(sys.maxsize, 2**31 - 1))
    try:
        reader = csv.reader(io.StringIO(text, newline=""), strict=True)
        header = next(reader, None)
        if header != list(CSV_COLUMNS):
            raise ValueError("CSV columns differ from ORCA scientist CSV schema v1. Export a fresh CSV from Work → Export.")
        rows = []
        for number, cells in enumerate(reader, 2):
            if not cells:
                continue
            if len(cells) != len(CSV_COLUMNS):
                raise _error(number, "Record width differs from the CSV header.")
            rows.append((number, dict(zip(CSV_COLUMNS, cells))))
    except csv.Error as exc:
        raise ValueError("The design CSV is malformed: " + str(exc)) from exc
    finally:
        csv.field_size_limit(old_limit)
    if not rows or rows[0][1]["record_type"] != "target":
        raise ValueError("The design CSV must begin with exactly one target record.")
    number, selected_row = rows[0]
    target_id = _identifier(selected_row["target_id"], "target_id", number)
    design_id = _identifier(selected_row["design_id"], "design_id", number, 120)
    sequence = _sequence(selected_row["target_sequence"], "target_sequence", number, RNA)
    position = _integer(selected_row["target_position_1based"], "target_position_1based", number)
    if position is None or position > len(sequence) or sequence[position - 1] != "C":
        raise _error(number, "target_position_1based must identify C within the full target RNA.")
    motif = _sequence(selected_row["recognition_rna"], "recognition_rna", number, RNA)
    if not 8 <= len(motif) <= 12:
        raise _error(number, "recognition_rna must retain the website's 8–12-base recognition interval.")
    start = _integer(selected_row["binding_start_1based"], "binding_start_1based", number)
    end = _integer(selected_row["binding_end_1based"], "binding_end_1based", number)
    if start is None or end is None or end > len(sequence) or end - start + 1 != len(motif) or sequence[start - 1:end] != motif:
        raise _error(number, "The recognition RNA or binding coordinates differ from the target interval.")
    if selected_row["transcript_id"] != target_id or selected_row["site_position_1based"] != str(position):
        raise _error(number, "The target record's transcript/site coordinate differs from its target identity.")
    if _sequence(selected_row["binding_rna"], "binding_rna", number, RNA) != motif:
        raise _error(number, "The target binding_rna differs from recognition_rna.")
    if _integer(selected_row["site_offset_nt"], "site_offset_nt", number) != position - end:
        raise _error(number, "The target site offset differs from its recognition interval.")
    target_protein = _sequence(selected_row["protein_sequence"], "protein_sequence", number, AA, optional=True)
    target_selected = _boolean(selected_row["protein_selected"], "protein_selected", number)
    if target_selected != bool(target_protein):
        raise _error(number, "The selected target protein flag and sequence disagree.")
    reference_kind = selected_row["reference_kind"]
    if reference_kind not in ("transcript", "genome", "unspecified"):
        raise _error(number, "reference_kind must retain transcript, genome or unspecified.")
    reference: ReferenceInput = {
        "name": selected_row["reference_name"], "species": selected_row["reference_species"],
        "kind": reference_kind, "sha256": _hash(selected_row["reference_sha256"], "reference_sha256", number),
    }
    candidates: list[ProteinInput] = []
    seen_ids: set[str] = set()
    seen_proteins: set[str] = set()
    warnings: list[str] = []
    common = ("target_id", "target_position_1based", "design_id", "library_version",
              "reference_name", "reference_species", "reference_kind", "reference_sha256", "coordinate_system")
    for row_number, row in rows:
        if row["record_type"] not in RECORD_TYPES or (row_number != number and row["record_type"] == "target"):
            raise _error(row_number, "Expected one target record, protein candidates and optional saved site records.")
        if row["coordinate_system"] != COORDINATE_SYSTEM:
            raise _error(row_number, "Unsupported coordinate_system; export a new website CSV.")
        if any(row[key] != selected_row[key] for key in common):
            raise _error(row_number, "This record belongs to a different target, design or reference.")
        if (_sequence(row["target_sequence"], "target_sequence", row_number, RNA) != sequence or
                _sequence(row["recognition_rna"], "recognition_rna", row_number, RNA) != motif):
            raise _error(row_number, "This record's target/recognition sequence differs from the target record.")
        _validate_site_row(row, row_number)
        if row["record_type"] == "protein_candidate":
            protein = _sequence(row["protein_sequence"], "protein_sequence", row_number, AA)
            candidate = _protein(row, row_number, row["protein_candidate_id"],
                                 _boolean(row["protein_selected"], "protein_selected", row_number), protein)
            if candidate["id"] in seen_ids:
                raise _error(row_number, "Duplicate protein candidate ID: " + candidate["id"])
            if protein in seen_proteins:
                raise _error(row_number, "Duplicate protein sequence: " + candidate["id"])
            seen_ids.add(candidate["id"])
            seen_proteins.add(protein)
            candidates.append(candidate)
    matches = [candidate for candidate in candidates if candidate["protein"] == target_protein] if target_protein else []
    explicit_id = selected_row["protein_candidate_id"]
    if target_protein:
        if matches:
            matched = matches[0]
            if explicit_id and matched["id"] != explicit_id:
                raise _error(number, "Selected protein candidate ID differs from its matching candidate record.")
            matched["selected"] = True
        else:
            candidate_id = explicit_id or design_id
            if candidate_id in seen_ids:
                raise _error(number, "The selected candidate ID already belongs to a different protein.")
            matched = _protein(selected_row, number, candidate_id, True, target_protein)
            candidates.append(matched)
            warnings.append("Selected target protein added because no matching protein_candidate record was exported.")
    selected_candidates = [candidate for candidate in candidates if candidate["selected"]]
    if len(selected_candidates) > 1 or (selected_candidates and selected_candidates[0]["protein"] != target_protein):
        raise _error(number, "Selected candidate records disagree with the selected target protein.")
    if not candidates:
        raise ValueError("The CSV contains no assembled PUF protein. Complete the PUF design or save a protein candidate on the website, then export CSV again.")
    if any(row[key] for _, row in rows for key in ("esm_rank", "s_hat_raw", "esm2_score", "lamar_score")):
        warnings.append("Saved model scores and ranks are ignored; the local run computes new results.")
    if target_id.startswith("'"):
        warnings.append("The target identifier's leading spreadsheet apostrophe is preserved; identifiers are never automatically unescaped.")
    target: TargetInput = {
        "id": target_id, "sequence": sequence, "position": position, "motif": motif,
        "bindingStart": start, "bindingEnd": end, "designId": design_id,
        "scaffoldId": selected_row["scaffold_id"], "trmAssignments": selected_row["trm_assignments"],
        "libraryVersion": selected_row["library_version"],
        "selectedCandidateId": selected_candidates[0]["id"] if selected_candidates else None,
    }
    return {
        "schemaVersion": 1, "target": target, "candidates": candidates, "reference": reference,
        "source": {"path": source_path, "sha256": hashlib.sha256(data).hexdigest(),
                   "sizeBytes": len(data), "rowCount": len(rows)},
        "warnings": warnings,
    }


def load_design_csv(path: str | Path) -> DesignInput:
    """Read an existing file without writing or altering it."""
    source = Path(path).expanduser().resolve(strict=True)
    if not source.is_file():
        raise ValueError("The design CSV path must identify an existing file.")
    return parse_design_csv(source.read_bytes(), source_path=str(source))
