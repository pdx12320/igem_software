import argparse
import json
import os
from pathlib import Path
import sys

os.environ.update(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',
    HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from local_app.pipeline import run_analysis

parser=argparse.ArgumentParser(description='Run pinned PUF-ESM and LaMAR locally from website CSV + FASTA.')
for flag in ('root','csv','fasta','output'):parser.add_argument('--'+flag,required=True,type=Path)
parser.add_argument('--species',default='')
args=parser.parse_args()
try:
    result=run_analysis(args.root,args.csv,args.fasta,args.species,args.output)
    print(json.dumps({'status':result['status'],'counts':result['counts']},ensure_ascii=False),flush=True)
except Exception as error:
    print(str(error),file=sys.stderr,flush=True)
    raise SystemExit(1)
