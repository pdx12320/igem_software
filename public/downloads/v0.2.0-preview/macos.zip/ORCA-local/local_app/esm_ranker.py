"""The original PUF-ESM feature definition and frozen three-assay Ridge fits.

This scorer uses reference-masked log odds, never mean protein embeddings.
The original 493-aa reference context is retained even for a 492-aa candidate.
Fresh inference must pass an explicit numerical compatibility check before
feeding the frozen fits. That check concerns floating-point reproduction;
it is not an activity threshold or a new scientific model selection rule.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
from typing import Iterable, Mapping

AA = "ACDEFGHIKLMNPQRSTVWY"
ESM_MODEL_ID = "facebook/esm2_t12_35M_UR50D"
ESM_REVISION = "6fbf070e65b0b7291e7bbcd451118c216cff79d8"
ESM_CHECKPOINT_SHA256 = "e35647818e0e064351d4531ed480d225a002567b4b2b93ad3a9246d753150fc0"
FROZEN_CHECKPOINT_SHA256 = "c0fb39463be5468a2a20739a1838f4ed1a4405003b8914e71eec82984739c34e"
FROZEN_EXPORT_SHA256 = "43fc14d455484db005ef29721f81f86fec1af479e84c82f85cc08b9a84cdb378"
REFERENCE493_SHA256 = "62851bee43beb3484bec54ab7b5d0e78f2aea96cf6dd452d6f2ee65eec843142"
REFERENCE492_SHA256 = "2b981a33277b03de9a6542f27baf6c56626ec3f21c774f017cb5880ac05b32f9"
FEATURE_DEFINITION = "reference493-single-position-mask-full33-log-softmax-canonical20-v1"
ESM_ASSETS = {
    "README.md": (1705, "462a2f24724e19c6be0efab926315c294a863c9a9770e2c8b3d859b2d81a07de"),
    "config.json": (778, "ae07364efa51e0fa1d81da3fe608f6d948abdbbb69785ba6e1df379a458e58ee"),
    "special_tokens_map.json": (125, "3aedcd4211c0d43aec4e607ff60a63255f3174ead795e997350f09a5f8cd9ee1"),
    "tokenizer_config.json": (95, "7e9161ecdb548ec45a41cbc6b24aa4476fdd418461f491c4207baa99419a29ad"),
    "vocab.txt": (93, "0b82cc0a7c7cf9e567b1e5892d793285b9fbae822c964ca48696f7db44598e03"),
    "model.safetensors": (136008798, ESM_CHECKPOINT_SHA256),
}


def sha256_file(path: Path | str) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _number(value, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError("Invalid finite number: " + label)
    return float(value)


def _verify_reference(reference: str) -> None:
    if (not isinstance(reference, str) or len(reference) != 493 or
            hashlib.sha256(reference.encode()).hexdigest() != REFERENCE493_SHA256):
        raise ValueError("Expected the original pinned 493-aa reference context.")


class FrozenRanker:
    """Passive JSON export of the unchanged module-2 Ridge checkpoint."""

    def __init__(self, model_path: Path | str):
        self.model_path = Path(model_path)
        if sha256_file(self.model_path) != FROZEN_EXPORT_SHA256:
            raise ValueError("Frozen PUF model export checksum mismatch.")
        model = json.loads(self.model_path.read_text(encoding="utf-8"))
        if (model.get("sourceCheckpointSha256") != FROZEN_CHECKPOINT_SHA256 or
                model.get("compatibilityVersion") != "drop-fixed-terminal-g-v1" or
                model.get("aaAlphabet") != AA):
            raise ValueError("Frozen model provenance differs from the original checkpoint.")
        self.reference493 = model["originalReference493"]
        self.reference492 = model["reference492"]
        _verify_reference(self.reference493)
        if (self.reference492 != self.reference493[:-1] or
                hashlib.sha256(self.reference492.encode()).hexdigest() != REFERENCE492_SHA256 or
                self.reference493[-1] != "G"):
            raise ValueError("Unsupported fixed-terminal conversion.")
        logp = model["scoreLogp"]
        if logp.get("shape") != [492, 20] or logp.get("dtype") != "float64":
            raise ValueError("Unexpected frozen log-probability layout.")
        self.score_logp = _matrix(logp["values"], 492)
        fits = model["fits"]
        if len(fits) != 3 or [fit["assay"] for fit in fits] != ["C295", "C388", "C871"]:
            raise ValueError("Expected three original assay fits.")
        for fit in fits:
            if len(fit["oneHotCoefficients"]) != 9840 or any(fit["droppedTerminalCoefficients"]):
                raise ValueError("Fixed-terminal coefficients do not preserve the original model.")
            for key in ("mean", "std", "weight", "esmCoefficient", "intercept"):
                _number(fit[key], key)
            if fit["std"] <= 0:
                raise ValueError("Original standard deviation must be positive.")
        self.fits = fits
        self.model_version = model["modelVersion"]

    def rank(self, candidates: Iterable[Mapping]) -> dict:
        return rank_candidates(candidates, self)


# Public compatibility name for callers asking specifically for the cached fit.
cachedFrozenRanker = FrozenRanker


def verify_model_assets(model_dir: Path | str) -> dict:
    directory = Path(model_dir)
    verified = {}
    for filename, (size, digest) in ESM_ASSETS.items():
        path = directory / filename
        if not path.is_file() or path.stat().st_size != size or sha256_file(path) != digest:
            raise ValueError("Pinned ESM-2 model asset is missing or altered: " + filename)
        verified[filename] = {"bytes": size, "sha256": digest}
    return verified


def build_model(model_dir: Path | str):
    """Load only verified local weights; no remote code or network inference."""
    verify_model_assets(model_dir)
    import torch
    from transformers import AutoTokenizer, EsmForMaskedLM

    torch.set_num_threads(2)
    model = EsmForMaskedLM.from_pretrained(str(model_dir), local_files_only=True,
                                         use_safetensors=True).to("cpu").float().eval()
    model.requires_grad_(False)
    tokenizer = AutoTokenizer.from_pretrained(str(model_dir), local_files_only=True)
    config = model.config
    if (config.hidden_size != 480 or config.num_hidden_layers != 12 or
            config.num_attention_heads != 20 or config.vocab_size != 33 or
            config.mask_token_id != 32 or config.position_embedding_type != "rotary"):
        raise ValueError("Loaded model is incompatible with the pinned ESM-2 35M architecture.")
    return model, tokenizer


def _positions(positions) -> list[int]:
    values = list(range(493)) if positions is None else list(positions)
    if (not values or any(type(position) is not int or not 0 <= position < 493 for position in values)
            or len(set(values)) != len(values)):
        raise ValueError("Reference positions must be unique zero-based indices in [0, 492].")
    return sorted(values)


def generate_reference_logp(model, tokenizer, reference493: str, *, positions=None,
                            batch_size: int = 8, threads: int = 2,
                            progress=None, cancelled=None) -> dict:
    """Run the original masked-reference feature computation on bounded CPU batches.

    ``positions`` supports a small integration fixture, not a complete ranker.
    A complete cache contains every one of the original 493 masked positions.
    """
    _verify_reference(reference493)
    selected = _positions(positions)
    if type(batch_size) is not int or not 1 <= batch_size <= 8:
        raise ValueError("CPU batch size must be between 1 and the original batch size 8.")
    if type(threads) is not int or not 1 <= threads <= 2:
        raise ValueError("CPU inference is limited to at most two threads.")
    import torch

    torch.set_num_threads(threads)
    model = model.to("cpu").float().eval()
    model.requires_grad_(False)
    ids = tokenizer(reference493, return_tensors="pt")["input_ids"].to("cpu")
    if tuple(ids.shape) != (1, 495):
        raise ValueError("Tokenizer must retain 493 residues plus the two original special tokens.")
    aa_ids = tokenizer.convert_tokens_to_ids(list(AA))
    if len(set(aa_ids)) != 20 or any(type(value) is not int or not 0 <= value < 33 for value in aa_ids):
        raise ValueError("Canonical amino-acid tokenizer mapping is incompatible.")
    aa_ids = torch.tensor(aa_ids, device="cpu")
    values = []
    with torch.no_grad():
        for begin in range(0, len(selected), batch_size):
            if cancelled is not None and cancelled():
                raise InterruptedError("ESM-2 reference inference was cancelled.")
            chosen = selected[begin:begin + batch_size]
            pos = torch.tensor(chosen, device="cpu")
            batch = ids.repeat(len(chosen), 1)
            batch[torch.arange(len(chosen), device="cpu"), pos + 1] = tokenizer.mask_token_id
            logits = model(input_ids=batch).logits
            if logits.shape[-1] != 33:
                raise ValueError("ESM-2 logits must retain the full original 33-token vocabulary.")
            # Do not normalize a 20-AA subset: the original code normalizes
            # all 33 tokens first, then selects the canonical AA columns.
            rows = logits[torch.arange(len(chosen), device="cpu"), pos + 1].log_softmax(-1)[:, aa_ids]
            values.extend(rows.cpu().numpy().tolist())
            if progress is not None:
                progress(min(begin + len(chosen), len(selected)), len(selected))
    result = {
        "schemaVersion": 1, "complete": selected == list(range(493)),
        "positions": selected, "values": values,
        "metadata": {
            "featureDefinition": FEATURE_DEFINITION, "modelId": ESM_MODEL_ID,
            "revision": ESM_REVISION, "checkpointSha256": ESM_CHECKPOINT_SHA256,
            "referenceSha256": REFERENCE493_SHA256, "aaAlphabet": AA,
            "device": "cpu", "dtype": "float32", "storedDtype": "float64",
            "batchSize": batch_size, "threads": threads,
            "torch": importlib.metadata.version("torch"),
            "transformers": importlib.metadata.version("transformers"),
        },
    }
    _validate_reference_logp(result, require_complete=False)
    return result


def _matrix(values, rows: int) -> list[list[float]]:
    if not isinstance(values, list) or len(values) != rows:
        raise ValueError("Log-probability row count does not match the reference positions.")
    result = []
    for row in values:
        if not isinstance(row, list) or len(row) != 20:
            raise ValueError("Each log-probability row must contain 20 canonical amino acids.")
        result.append([_number(value, "log probability") for value in row])
    return result


def _validate_reference_logp(value: dict, *, require_complete: bool) -> list[list[float]]:
    if not isinstance(value, dict) or value.get("schemaVersion") != 1:
        raise ValueError("Unexpected reference feature cache schema.")
    selected = _positions(value.get("positions", []))
    if selected != value["positions"]:
        raise ValueError("Reference feature positions must be sorted.")
    complete = selected == list(range(493))
    if type(value.get("complete")) is not bool or value["complete"] != complete:
        raise ValueError("Reference feature cache falsely claims completeness.")
    if require_complete and not complete:
        raise ValueError("A subset fixture cannot be used as a complete ESM-2 ranker.")
    meta = value.get("metadata", {})
    expected = {"featureDefinition": FEATURE_DEFINITION, "modelId": ESM_MODEL_ID,
                "revision": ESM_REVISION, "checkpointSha256": ESM_CHECKPOINT_SHA256,
                "referenceSha256": REFERENCE493_SHA256, "aaAlphabet": AA}
    if any(meta.get(key) != expected_value for key, expected_value in expected.items()):
        raise ValueError("Reference feature cache has incompatible checkpoint or feature provenance.")
    return _matrix(value.get("values"), len(selected))


def compare_reference_logp(reference_logp: dict, frozen_ranker: FrozenRanker) -> dict:
    """Measure floating-point differences without defining a biological cutoff."""
    values = _validate_reference_logp(reference_logp, require_complete=False)
    differences = []
    worst = {"position0Based": None, "aminoAcid": None, "absoluteDifference": 0.0}
    for position, row in zip(reference_logp["positions"], values):
        if position == 492:  # The removed terminal residue never changes.
            continue
        for column, actual in enumerate(row):
            delta = abs(actual - frozen_ranker.score_logp[position][column])
            differences.append(delta)
            if delta > worst["absoluteDifference"]:
                worst = {"position0Based": position, "aminoAcid": AA[column], "absoluteDifference": delta}
    return {"complete": reference_logp["complete"], "comparedValues": len(differences),
            "maxAbsoluteDifference": max(differences, default=0.0),
            "rmsDifference": math.sqrt(sum(delta * delta for delta in differences) / len(differences))
                             if differences else 0.0,
            "worst": worst,
            "scope": "reference masked log probabilities; original terminal-G row excluded"}


class NumericalCompatibilityError(ValueError):
    def __init__(self, comparison: dict, message: str):
        self.comparison = comparison
        super().__init__(message)


def _candidate(candidate: Mapping) -> tuple[str, str, str]:
    if not isinstance(candidate, Mapping):
        raise ValueError("Each PUF candidate must be a mapping.")
    identifier = candidate.get("id", candidate.get("candidate_id"))
    protein = candidate.get("protein", candidate.get("protein_sequence"))
    if not isinstance(identifier, str) or not identifier or len(identifier) > 300:
        raise ValueError("Each PUF candidate needs a unique nonempty ID.")
    if not isinstance(protein, str) or set(protein) - set(AA):
        raise ValueError("PUF candidates must use uppercase canonical amino acids.")
    if len(protein) == 492:
        return identifier, protein, protein + "G"
    if len(protein) == 493 and protein[-1] == "G":
        return identifier, protein, protein
    raise ValueError("PUF-ESM supports the fixed 492-aa scaffold or its original 493-aa terminal-G form.")


def rank_candidates(candidates: Iterable[Mapping], frozen_ranker: FrozenRanker,
                    reference_logp: dict | None = None, *, numerical_tolerance: float | None = None) -> dict:
    """Rank by the original S expression, with unchanged frozen feature scaling.

    A fresh cache requires a caller-approved, explicit numerical reproduction
    tolerance. Failure preserves measured differences in the exception and
    never falls back silently to the frozen cache.
    """
    parsed = [_candidate(candidate) for candidate in candidates]
    if not parsed or len({item[0] for item in parsed}) != len(parsed):
        raise ValueError("Provide a nonempty PUF batch with unique candidate IDs.")
    comparison = None
    if reference_logp is None:
        logp = frozen_ranker.score_logp
        source = "original-frozen-reference-cache"
    else:
        logp = _validate_reference_logp(reference_logp, require_complete=True)
        comparison = compare_reference_logp(reference_logp, frozen_ranker)
        if numerical_tolerance is None:
            raise NumericalCompatibilityError(comparison, "Fresh reference features need an explicit numerical compatibility tolerance.")
        tolerance = _number(numerical_tolerance, "numerical compatibility tolerance")
        if tolerance < 0 or comparison["maxAbsoluteDifference"] > tolerance:
            raise NumericalCompatibilityError(comparison, "Fresh ESM-2 reference features exceed the explicit numerical compatibility tolerance.")
        comparison["acceptedNumericalTolerance"] = tolerance
        source = "recomputed-pinned-esm2-reference493"
    output = []
    for identifier, original_protein, protein in parsed:
        columns = []
        score = 0.0
        for position, (wild, mutant) in enumerate(zip(frozen_ranker.reference493, protein)):
            if wild == mutant:
                continue
            # Last position is the original fixed G, enforced in _candidate.
            a, b = AA.index(wild), AA.index(mutant)
            score += logp[position][b] - logp[position][a]
            columns.extend(sorted(((position * 20 + a, -1.0), (position * 20 + b, 1.0))))
        row = {"candidate_id": identifier, "id": identifier, "protein": original_protein,
               "ESM2_score": score, "classifier_status": "untrained: no negative class"}
        for fit in frozen_ranker.fits:
            linear = 0.0
            for column, feature in columns:
                linear += feature * fit["oneHotCoefficients"][column]
            standardized = (score - fit["mean"]) / fit["std"] * fit["weight"]
            row[fit["assay"] + "_hat"] = linear + standardized * fit["esmCoefficient"] + fit["intercept"]
        row["S_hat"] = row["C388_hat"] - (row["C295_hat"] + row["C871_hat"]) / 2
        output.append(row)
    output.sort(key=lambda row: (-row["S_hat"], row["candidate_id"]))
    for rank, row in enumerate(output, 1):
        row["predicted_rank"] = rank
        row["rank"] = rank
    return {"rows": output, "modelVersion": frozen_ranker.model_version,
            "sourceCheckpointSha256": FROZEN_CHECKPOINT_SHA256,
            "referenceSha256": REFERENCE492_SHA256,
            "featureSource": source, "numericalComparison": comparison,
            "esmModelId": ESM_MODEL_ID, "esmRevision": ESM_REVISION,
            "esmCheckpointSha256": ESM_CHECKPOINT_SHA256}


def _cache_digest(value: dict) -> str:
    data = json.dumps({key: item for key, item in value.items() if key != "cacheSha256"},
                      sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(data).hexdigest()


def save_reference_logp(path: Path | str, value: dict) -> dict:
    """Write a new immutable cache; refuse to overwrite any existing input."""
    _validate_reference_logp(value, require_complete=False)
    stored = dict(value)
    stored["cacheSha256"] = _cache_digest(stored)
    path = Path(path)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(stored, handle, allow_nan=False, sort_keys=True, indent=2)
        handle.write("\n")
    return {"path": str(path), "cacheSha256": stored["cacheSha256"],
            "fileSha256": sha256_file(path), "complete": stored["complete"]}


def load_reference_logp(path: Path | str) -> dict:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if value.get("cacheSha256") != _cache_digest(value):
        raise ValueError("Reference feature cache checksum mismatch.")
    _validate_reference_logp(value, require_complete=False)
    return value
