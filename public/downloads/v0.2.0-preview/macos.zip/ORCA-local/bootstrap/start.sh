#!/bin/bash
# Uses only macOS-provided curl, tar and shasum; installs nothing system-wide.
set -eu
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PACKAGE_ROOT"
WEB_ONLY=0
for OPTION in "$@"; do
  case "$OPTION" in
    --web-only) WEB_ONLY=1 ;;
    *) printf 'Unknown option: %s. Supported: --web-only\n' "$OPTION" >&2; exit 2 ;;
  esac
done
if [ "$(uname -s)" != Darwin ]; then
  printf 'This launcher supports macOS. Use Start-Windows.cmd on Windows.\n' >&2
  exit 2
fi
RUNTIME_DIR="$PACKAGE_ROOT/.runtime"
mkdir -p "$RUNTIME_DIR/cache" "$RUNTIME_DIR/logs"
LOCK_DIR="$RUNTIME_DIR/bootstrap.lock"
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  printf 'Another bootstrap is running, or a previous bootstrap was interrupted.\nInspect %s before manually removing its bootstrap.lock directory.\n' "$RUNTIME_DIR" >&2
  exit 3
fi
OWNS_LOCK=1
release_lock() {
  if [ "$OWNS_LOCK" -eq 1 ]; then
    rmdir "$LOCK_DIR" 2>/dev/null || true
    OWNS_LOCK=0
  fi
}
trap release_lock EXIT
RUN_ID="$(date -u '+%Y%m%dT%H%M%SZ')-$$"
BOOTSTRAP_LOG="$RUNTIME_DIR/logs/bootstrap-$RUN_ID.log"
if [ -n "${ORCA_PYTHON:-}" ]; then
  PYTHON_EXE="$ORCA_PYTHON"
  if [ ! -x "$PYTHON_EXE" ]; then
    printf 'ORCA_PYTHON must name an executable Python 3.10 file.\n' >&2
    exit 2
  fi
  "$PYTHON_EXE" -I -X utf8 -c 'import sys; assert sys.version_info[:2] == (3,10), "ORCA_PYTHON requires Python 3.10"'
else
  case "$(uname -m)" in
    arm64)
      PLATFORM=aarch64-apple-darwin
      EXPECTED_SHA=37931bdcd24496bf57415e34f93dcf360f80b6a2b5bf91d32ceecde14fe9f29f ;;
    x86_64)
      PLATFORM=x86_64-apple-darwin
      EXPECTED_SHA=82703c1d9de3b6b686269361dd61c29aa65f52d04dbf0c4f53fc6fd8faf38dfd ;;
    *) printf 'Unsupported macOS CPU architecture.\n' >&2; exit 2 ;;
  esac
  PYTHON_EXE=""
  for CANDIDATE in "$RUNTIME_DIR"/python-"$PLATFORM"-*; do
    [ -d "$CANDIDATE" ] || continue
    [ -f "$CANDIDATE/archive.sha256" ] || continue
    [ "$(cat "$CANDIDATE/archive.sha256")" = "$EXPECTED_SHA" ] || continue
    if [ -x "$CANDIDATE/python/bin/python3" ] && "$CANDIDATE/python/bin/python3" -I -X utf8 -c 'import sys; assert sys.version_info[:3] == (3,10,19)' >>"$BOOTSTRAP_LOG" 2>&1; then
      PYTHON_EXE="$CANDIDATE/python/bin/python3"
      break
    fi
  done
  if [ -z "$PYTHON_EXE" ]; then
    ASSET="cpython-3.10.19+20251014-$PLATFORM-install_only_stripped.tar.gz"
    URL="https://github.com/astral-sh/python-build-standalone/releases/download/20251014/cpython-3.10.19%2B20251014-$PLATFORM-install_only_stripped.tar.gz"
    ARCHIVE="$RUNTIME_DIR/cache/$ASSET"
    PARTIAL="$ARCHIVE.part"
    if [ -f "$ARCHIVE" ]; then
      ACTUAL_SHA="$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')"
      if [ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]; then
        printf 'Cached Python checksum is incorrect; preserved the file at %s.\nMove it aside manually, then retry.\n' "$ARCHIVE" >&2
        exit 4
      fi
    else
      printf 'Downloading isolated Python 3.10.19 (first run only)...\n'
      if ! curl --fail --location --retry 3 --connect-timeout 30 --continue-at - --output "$PARTIAL" "$URL" 2> >(tee -a "$BOOTSTRAP_LOG" >&2); then
        printf 'Python download failed. Retry this launcher to resume the download.\n' >&2
        exit 4
      fi
      ACTUAL_SHA="$(shasum -a 256 "$PARTIAL" | awk '{print $1}')"
      if [ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]; then
        printf 'Downloaded Python checksum is incorrect; preserved %s.\nMove this partial file aside manually, then retry.\n' "$PARTIAL" >&2
        exit 4
      fi
      mv "$PARTIAL" "$ARCHIVE"
    fi
    EXTRACT_DIR="$RUNTIME_DIR/python-$PLATFORM-$RUN_ID"
    mkdir "$EXTRACT_DIR"
    tar -xzf "$ARCHIVE" -C "$EXTRACT_DIR" >>"$BOOTSTRAP_LOG" 2>&1
    PYTHON_EXE="$EXTRACT_DIR/python/bin/python3"
    "$PYTHON_EXE" -I -X utf8 -c 'import sys; assert sys.version_info[:3] == (3,10,19)' >>"$BOOTSTRAP_LOG" 2>&1
    printf '%s\n' "$EXPECTED_SHA" >"$EXTRACT_DIR/archive.sha256"
  fi
fi
release_lock
if [ "$WEB_ONLY" -eq 1 ]; then
  exec "$PYTHON_EXE" -I -X utf8 "$PACKAGE_ROOT/bootstrap/setup.py" --web-only
else
  exec "$PYTHON_EXE" -I -X utf8 "$PACKAGE_ROOT/bootstrap/setup.py"
fi
