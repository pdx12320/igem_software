"""Prepare an isolated, verified ORCA environment, then run the local server.

Only Python's standard library is required to execute this bootstrap helper.
All generated environments, logs and download caches stay inside .runtime/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import uuid

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
RUNTIME_ROOT = PACKAGE_ROOT / ".runtime"
SERVER = PACKAGE_ROOT / "local_app" / "server.py"
MODEL = PACKAGE_ROOT / "models" / "model_101_classifier" / "best_model" / "model.safetensors"
MODEL_SIZE = 345806960
MODEL_SHA256 = "489eed13a9e7519f0b8250350c0af1fe7ffbe17c845381637dcc18dc566bc3de"


class BootstrapError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def python_in(venv: Path) -> Path:
    return venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def isolated_environment(venv: Path | None = None, web_only: bool = False) -> dict[str, str]:
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env.pop("PYTHONHOME", None)
    for key in ("PIP_EXTRA_INDEX_URL", "PIP_TRUSTED_HOST", "PIP_TARGET", "PIP_PREFIX",
                "PIP_ROOT", "PIP_USER", "PIP_FIND_LINKS", "PIP_NO_INDEX"):
        env.pop(key, None)
    cache = RUNTIME_ROOT / "cache"
    temporary = RUNTIME_ROOT / "tmp"
    temporary.mkdir(parents=True, exist_ok=True)
    env["PYTHONNOUSERSITE"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["PIP_CONFIG_FILE"] = os.devnull
    env["PIP_CACHE_DIR"] = str(cache / "pip")
    env["PIP_INDEX_URL"] = "https://pypi.org/simple"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    env["PIP_NO_INPUT"] = "1"
    env["TMPDIR"] = str(temporary)
    env["TMP"] = str(temporary)
    env["TEMP"] = str(temporary)
    env["XDG_CACHE_HOME"] = str(cache)
    env["HF_HOME"] = str(cache / "huggingface")
    env["TRANSFORMERS_CACHE"] = str(cache / "transformers")
    env["TORCH_HOME"] = str(cache / "torch")
    env["ORCA_WEB_ONLY"] = "1" if web_only else "0"
    if venv is not None:
        env["VIRTUAL_ENV"] = str(venv)
        env["PIP_REQUIRE_VIRTUALENV"] = "1"
        env["PATH"] = str(python_in(venv).parent) + os.pathsep + env.get("PATH", "")
    return env


def run_checked(command: list[str], log, env: dict[str, str]) -> None:
    printable = subprocess.list2cmdline(command)
    print(f"Running: {printable}", flush=True)
    log.write(f"\n$ {printable}\n")
    log.flush()
    process = subprocess.Popen(command, cwd=PACKAGE_ROOT, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    try:
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            log.write(line)
            log.flush()
        status = process.wait()
    except KeyboardInterrupt:
        # The foreground child receives the same console Ctrl+C. Give its own
        # finally block time to cancel and reap the model worker before fallback.
        print("\nStopping ORCA; allowing the server to finish worker cleanup...", flush=True)
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill()  # Only the child started by this invocation.
                process.wait()
        raise
    if status:
        raise BootstrapError(f"Command exited with code {status}. See {log.name}")


def validate_model() -> None:
    if not MODEL.is_file():
        raise BootstrapError(f"Installed LaMAR weights are missing: {MODEL}. Run the launcher again to resume model installation, or use --web-only.")
    if MODEL.stat().st_size != MODEL_SIZE or sha256_file(MODEL) != MODEL_SHA256:
        raise BootstrapError("Installed LaMAR weights failed the size/SHA256 check. Preserve the file and extract a fresh package, or use --web-only.")


def signature_for(requirements: Path) -> dict[str, str]:
    signature = {
        "requirements_sha256": sha256_file(requirements),
        "base_python": str(Path(sys.executable).resolve()),
        "python_version": platform.python_version(),
        "platform": platform.system(),
        "machine": platform.machine(),
        "model_sha256": MODEL_SHA256,
    }
    for relative in ("bootstrap/setup.py", "bootstrap/model_assets.py", "local_app/server.py", "local_app/run_analysis.py", "local_app/pipeline.py", "local_app/esm_ranker.py", "local_app/csv_input.py", "runtime/model_runner.py", "runtime/contracts.py",
                     "asset-manifest.json", "ui/index.html"):
        signature[relative + "_sha256"] = sha256_file(PACKAGE_ROOT / relative)
    return signature


def find_ready_environment(signature: dict[str, str]) -> Path | None:
    for candidate in sorted(RUNTIME_ROOT.glob("venv-*")):
        marker = candidate / "ready.json"
        if not marker.is_file() or not python_in(candidate).is_file():
            continue
        try:
            data = json.loads(marker.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if data.get("signature") == signature:
            return candidate
    return None


def verify_environment(python: Path, env: dict[str, str], log, web_only: bool = False) -> None:
    run_checked([str(python), "-I", "-X", "utf8", "-c", "import sys; assert sys.version_info[:2] == (3,10)"], log, env)
    if not web_only:
        run_checked([str(python), "-I", "-X", "utf8", "-m", "pip", "check"], log, env)
    command = [str(python), "-I", "-X", "utf8", str(SERVER), "--self-check", "--no-browser"]
    if web_only:
        command.append("--web-only")
    run_checked(command, log, env)


def record_versions(python: Path, env: dict[str, str], destination: Path) -> None:
    script = (
        "import importlib.metadata as m,json,platform,sys;"
        "print(json.dumps({'python':sys.version,'platform':platform.platform(),"
        "'packages':{d.metadata['Name']:d.version for d in m.distributions()}},"
        "ensure_ascii=False,indent=2,sort_keys=True))"
    )
    result = subprocess.run([str(python), "-I", "-X", "utf8", "-c", script], cwd=PACKAGE_ROOT, env=env,
                            capture_output=True, text=True, encoding="utf-8", check=True)
    json.loads(result.stdout)
    with destination.open("x", encoding="utf-8") as stream:
        stream.write(result.stdout)


def prepare_environment(web_only: bool, run_id: str, log) -> tuple[Path, dict[str, str]]:
    if not SERVER.is_file():
        raise BootstrapError("local_app/server.py is missing. Extract the complete ZIP before launching.")
    if web_only:
        python = Path(sys.executable)
        env = isolated_environment(web_only=True)
        verify_environment(python, env, log, web_only=True)
        record_versions(python, env, RUNTIME_ROOT / "logs" / f"versions-{run_id}.json")
        return python, env

    # Dependencies and model files are installed only inside this extraction.
    system = platform.system()
    if system not in ("Darwin", "Windows"):
        raise BootstrapError("Full model mode supports macOS and 64-bit Windows. Use --web-only for a local UI preview.")
    requirements = PACKAGE_ROOT / "requirements" / ("windows.lock.txt" if system == "Windows" else "macos.lock.txt")
    if not requirements.is_file():
        raise BootstrapError(f"Dependency lock file is missing: {requirements}")
    signature = signature_for(requirements)
    venv = find_ready_environment(signature)
    is_new = venv is None
    if is_new:
        venv = RUNTIME_ROOT / f"venv-{run_id}"
        # New directory per attempt: incomplete or older environments stay intact.
        venv.mkdir()
        run_checked([sys.executable, "-I", "-X", "utf8", "-m", "venv", str(venv)], log, isolated_environment())
    assert venv is not None
    python = python_in(venv)
    env = isolated_environment(venv)
    if is_new:
        print("Installing pinned model dependencies into the package's isolated environment...", flush=True)
        run_checked([str(python), "-I", "-X", "utf8", "-m", "pip", "install", "--disable-pip-version-check",
                     "--no-input", "--only-binary=:all:", "-r", str(requirements)], log, env)
    else:
        print("Reusing the verified isolated environment.", flush=True)
    run_checked([str(python), "-I", "-B", "-X", "utf8", str(PACKAGE_ROOT / "bootstrap/model_assets.py"), "--root", str(PACKAGE_ROOT)], log, env)
    validate_model()
    verify_environment(python, env, log)
    record_versions(python, env, RUNTIME_ROOT / "logs" / f"versions-{run_id}.json")
    if is_new:
        with (venv / "ready.json").open("x", encoding="utf-8") as stream:
            json.dump({"signature": signature, "verified_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, stream, indent=2)
            stream.write("\n")
    return python, env


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--web-only", action="store_true", help="preview the local interface without installing model dependencies or weights")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 10):
        raise BootstrapError("The bootstrap requires Python 3.10. Use the platform launcher to download the pinned isolated runtime.")
    logs = RUNTIME_ROOT / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    run_id = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()) + "-" + uuid.uuid4().hex[:10]
    lock = RUNTIME_ROOT / "setup.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        raise BootstrapError(f"Another setup is running, or setup was interrupted. Inspect {lock} before manually removing a stale lock.")
    try:
        with (logs / f"setup-{run_id}.log").open("x", encoding="utf-8") as log:
            python, env = prepare_environment(args.web_only, run_id, log)
    finally:
        lock.rmdir()  # Only the empty lock created by this invocation is removed.
    try:
        port = int(os.environ.get("ORCA_PORT", "8765"))
    except ValueError:
        raise BootstrapError("ORCA_PORT must be an integer from 1 to 65535.")
    if not 1 <= port <= 65535:
        raise BootstrapError("ORCA_PORT must be an integer from 1 to 65535.")
    command = [str(python), "-I", "-X", "utf8", str(SERVER), "--port", str(port)]
    if args.web_only:
        command.append("--web-only")
    if os.environ.get("ORCA_NO_BROWSER") == "1":
        command.append("--no-browser")
    print(f"ORCA is starting at http://127.0.0.1:{port}/. Keep this console open; Ctrl+C stops the server.", flush=True)
    with (logs / f"server-{run_id}.log").open("x", encoding="utf-8") as log:
        run_checked(command, log, env)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nORCA stopped.", flush=True)
        raise SystemExit(0)
    except (BootstrapError, OSError, subprocess.SubprocessError) as error:
        print(f"\nORCA setup failed: {error}\nSee .runtime/logs. After fixing the issue, run the launcher again.\nFor a website-only preview, launch with --web-only.", file=sys.stderr, flush=True)
        raise SystemExit(1)
