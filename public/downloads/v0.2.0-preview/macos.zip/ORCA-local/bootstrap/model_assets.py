"""Install pinned model files using verified, resumable HTTPS downloads.

This module needs only the standard library. Existing files are immutable:
matching files are reused and mismatches are reported without replacing them.
Interrupted downloads and failed checks remain in the local runtime cache.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

ESM_REVISION = "6fbf070e65b0b7291e7bbcd451118c216cff79d8"
ESM_BASE = "https://huggingface.co/facebook/esm2_t12_35M_UR50D/resolve/" + ESM_REVISION + "/"
ESM_ASSETS = {
    "README.md": (1705, "462a2f24724e19c6be0efab926315c294a863c9a9770e2c8b3d859b2d81a07de"),
    "config.json": (778, "ae07364efa51e0fa1d81da3fe608f6d948abdbbb69785ba6e1df379a458e58ee"),
    "special_tokens_map.json": (125, "3aedcd4211c0d43aec4e607ff60a63255f3174ead795e997350f09a5f8cd9ee1"),
    "tokenizer_config.json": (95, "7e9161ecdb548ec45a41cbc6b24aa4476fdd418461f491c4207baa99419a29ad"),
    "vocab.txt": (93, "0b82cc0a7c7cf9e567b1e5892d793285b9fbae822c964ca48696f7db44598e03"),
    "model.safetensors": (136008798, "e35647818e0e064351d4531ed480d225a002567b4b2b93ad3a9246d753150fc0"),
}
LAMAR_URL = "https://sustech-bio2026-software.pdx12320.chatgpt.site/downloads/v0.1.0-preview/windows.zip"
LAMAR_ARCHIVE_SIZE = 323755994
LAMAR_ARCHIVE_SHA256 = "5911bf4d9cf16f8f7411eb18b1c07794ea92e3e7ea594c383c5389ee2cc8643f"
LAMAR_MEMBER = "ORCA-local/models/model_101_classifier/best_model/model.safetensors"
LAMAR_SIZE = 345806960
LAMAR_SHA256 = "489eed13a9e7519f0b8250350c0af1fe7ffbe17c845381637dcc18dc566bc3de"
BLOCK_SIZE = 1024 * 1024


class ModelAssetError(RuntimeError):
    pass


@dataclass(frozen=True)
class Asset:
    name: str
    url: str
    bytes: int
    sha256: str


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(BLOCK_SIZE), b""):
            digest.update(block)
    return digest.hexdigest()


def _check_existing(path: Path, size: int, digest: str) -> bool:
    if not path.exists() and not path.is_symlink():
        return False
    if path.is_symlink() or not path.is_file():
        raise ModelAssetError(f"Expected a regular model file; preserved existing path: {path}")
    if path.stat().st_size != size or sha256_file(path) != digest:
        raise ModelAssetError(f"Size/SHA256 mismatch; preserved existing file: {path}. Use a fresh extraction directory.")
    return True


def _ssl_context() -> ssl.SSLContext:
    try:
        import certifi
    except ImportError:
        return ssl.create_default_context()
    return ssl.create_default_context(cafile=certifi.where())


def _publish(source: Path, destination: Path, size: int, digest: str) -> None:
    """Create the final path atomically without replacing another file."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if _check_existing(destination, size, digest):
        return
    try:
        os.link(source, destination)
    except FileExistsError:
        _check_existing(destination, size, digest)
    except OSError as error:
        raise ModelAssetError(f"Cannot safely create {destination}; verified cache retained: {source}. {error}") from error


def _download_asset(asset: Asset, destination: Path, cache: Path) -> Path:
    if _check_existing(destination, asset.bytes, asset.sha256):
        print(f"Reusing verified {asset.name}", flush=True)
        return destination
    cache.mkdir(parents=True, exist_ok=True)
    key = asset.sha256 + "-" + Path(asset.name).name
    complete = cache / key
    if _check_existing(complete, asset.bytes, asset.sha256):
        _publish(complete, destination, asset.bytes, asset.sha256)
        return destination
    parts = list(cache.glob(key + "*.part"))
    if any(path.is_symlink() or not path.is_file() for path in parts):
        raise ModelAssetError(f"Unexpected partial download path for {asset.name}; preserved cache.")
    partial = max(parts, key=lambda path: path.stat().st_size) if parts else cache / (key + ".part")
    offset = partial.stat().st_size if partial.exists() else 0
    if offset > asset.bytes:
        raise ModelAssetError(f"Partial download is larger than pinned asset; preserved: {partial}")
    if offset == asset.bytes:
        if sha256_file(partial) != asset.sha256:
            raise ModelAssetError(f"Partial download failed SHA256; preserved: {partial}")
        _publish(partial, complete, asset.bytes, asset.sha256)
        _publish(complete, destination, asset.bytes, asset.sha256)
        return destination
    headers = {"User-Agent": "Mozilla/5.0 (ORCA local model installer)", "Accept-Encoding": "identity"}
    if offset:
        headers["Range"] = f"bytes={offset}-"
    request = urllib.request.Request(asset.url, headers=headers)
    print(f"Downloading {asset.name}: {offset:,}/{asset.bytes:,} bytes", flush=True)
    try:
        with urllib.request.urlopen(request, timeout=60, context=_ssl_context()) as response:
            if asset.url.startswith("https:") and urllib.parse.urlparse(response.geturl()).scheme != "https":
                raise ModelAssetError("Refusing an HTTPS download redirected to an insecure URL.")
            status = response.status
            if status not in (200, 206):
                raise ModelAssetError(f"Unexpected HTTP status {status} for {asset.name}")
            encoding = response.headers.get("Content-Encoding", "identity").lower()
            if encoding not in ("", "identity") or "text/html" in response.headers.get("Content-Type", "").lower():
                raise ModelAssetError(f"Unexpected encoded/HTML response for {asset.name}")
            if status == 206:
                match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", response.headers.get("Content-Range", ""))
                if not match:
                    raise ModelAssetError(f"Missing or invalid Content-Range for {asset.name}")
                start, end, total = map(int, match.groups())
                if start != offset or total != asset.bytes or not start <= end < total:
                    raise ModelAssetError(f"Content-Range does not match pinned asset/resume offset for {asset.name}")
                expected_body = end - start + 1
            else:
                expected_body = asset.bytes
                if offset:
                    # Never truncate an interrupted download when a server ignores Range.
                    partial = cache / (key + "-restart-" + uuid.uuid4().hex + ".part")
                    offset = 0
                    print(f"Server ignored Range; starting a separate download for {asset.name}.", flush=True)
            length = response.headers.get("Content-Length")
            if length is not None and (not length.isdecimal() or int(length) != expected_body):
                raise ModelAssetError(f"Content-Length does not match pinned asset/range for {asset.name}")
            mode = "ab" if offset else "xb"
            # Existing zero-byte partials are safe to append; never truncate them.
            if partial.exists() and partial.stat().st_size == 0:
                mode = "ab"
            received = 0
            last_progress = time.monotonic()
            with partial.open(mode) as handle:
                for block in iter(lambda: response.read(BLOCK_SIZE), b""):
                    if received + len(block) > expected_body:
                        raise ModelAssetError(f"Response exceeded pinned size; preserved: {partial}")
                    handle.write(block)
                    received += len(block)
                    if time.monotonic() - last_progress >= 2:
                        print(f"{asset.name}: {offset + received:,}/{asset.bytes:,} bytes", flush=True)
                        last_progress = time.monotonic()
                handle.flush()
                os.fsync(handle.fileno())
            if received != expected_body or offset + received != asset.bytes:
                raise ModelAssetError(f"Download interrupted/incomplete; rerun to resume: {partial}")
    except (urllib.error.URLError, http.client.HTTPException, TimeoutError, OSError) as error:
        raise ModelAssetError(f"Download failed for {asset.name}; partial files retained in {cache}: {error}") from error
    if partial.stat().st_size != asset.bytes or sha256_file(partial) != asset.sha256:
        raise ModelAssetError(f"Downloaded file failed size/SHA256; preserved: {partial}")
    _publish(partial, complete, asset.bytes, asset.sha256)
    _publish(complete, destination, asset.bytes, asset.sha256)
    print(f"Verified {asset.name}: SHA256 {asset.sha256}", flush=True)
    return destination


def _extract_member(archive: Path, member: str, destination: Path, size: int, digest: str, cache: Path) -> Path:
    if _check_existing(destination, size, digest):
        return destination
    cache.mkdir(parents=True, exist_ok=True)
    partial = cache / (digest + "-extracted-" + uuid.uuid4().hex + ".part")
    print("Extracting verified LaMAR weights...", flush=True)
    try:
        with zipfile.ZipFile(archive) as package:
            entries = [entry for entry in package.infolist() if entry.filename == member]
            if len(entries) != 1 or entries[0].is_dir() or entries[0].file_size != size:
                raise ModelAssetError("LaMAR archive member is missing, duplicated or has the wrong size.")
            info = entries[0]
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ModelAssetError("Refusing a symbolic-link archive member.")
            received = 0
            checksum = hashlib.sha256()
            with package.open(info) as source, partial.open("xb") as output:
                for block in iter(lambda: source.read(BLOCK_SIZE), b""):
                    received += len(block)
                    if received > size:
                        raise ModelAssetError("LaMAR archive member exceeds pinned size.")
                    checksum.update(block)
                    output.write(block)
                output.flush()
                os.fsync(output.fileno())
            if received != size or checksum.hexdigest() != digest:
                raise ModelAssetError(f"Extracted LaMAR failed size/SHA256; preserved: {partial}")
    except (zipfile.BadZipFile, OSError) as error:
        raise ModelAssetError(f"Cannot extract LaMAR; partial files preserved: {error}") from error
    _publish(partial, destination, size, digest)
    return destination


def ensure_models(root: Path | str) -> dict:
    root = Path(root).resolve()
    esm = root / "models" / "esm2_t12_35M_UR50D"
    lamar = root / "models" / "model_101_classifier" / "best_model" / "model.safetensors"
    cache = root / ".runtime" / "cache" / "model-downloads"
    # Check all supplied model files before generating or fetching anything.
    for filename, (size, digest) in ESM_ASSETS.items():
        _check_existing(esm / filename, size, digest)
    lamar_ready = _check_existing(lamar, LAMAR_SIZE, LAMAR_SHA256)
    cache.mkdir(parents=True, exist_ok=True)
    lock = cache / "install.lock"
    try:
        handle = lock.open("x", encoding="utf-8")
    except FileExistsError as error:
        raise ModelAssetError(f"Another installation or retained lock exists: {lock}. Close the active installer first; locks are never removed automatically.") from error
    checks = {}
    try:
        with handle:
            handle.write(str(os.getpid()) + "\n")
        for filename, (size, digest) in ESM_ASSETS.items():
            asset = Asset("ESM-2/" + filename, ESM_BASE + filename, size, digest)
            _download_asset(asset, esm / filename, cache)
            checks["esm2/" + filename] = {"bytes": size, "sha256": digest}
        if not lamar_ready:
            asset = Asset("LaMAR-preview.zip", LAMAR_URL, LAMAR_ARCHIVE_SIZE, LAMAR_ARCHIVE_SHA256)
            archive = _download_asset(asset, cache / "orca-v0.1.0-preview.zip", cache)
            _extract_member(archive, LAMAR_MEMBER, lamar, LAMAR_SIZE, LAMAR_SHA256, cache)
        checks["lamar/model.safetensors"] = {"bytes": LAMAR_SIZE, "sha256": LAMAR_SHA256}
        return checks
    finally:
        # This process owns this newly created lock; never delete another lock.
        lock.unlink()


def main() -> int:
    parser = argparse.ArgumentParser(description="Install the pinned ORCA local models.")
    parser.add_argument("--root", required=True, type=Path)
    arguments = parser.parse_args()
    try:
        checks = ensure_models(arguments.root)
    except (ModelAssetError, KeyboardInterrupt) as error:
        print(f"Model installation stopped: {error}", file=sys.stderr, flush=True)
        return 130 if isinstance(error, KeyboardInterrupt) else 1
    print(json.dumps({"verified_model_assets": checks}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
