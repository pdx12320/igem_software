# Deliberately does not change or bypass the user's PowerShell execution policy.
$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $PackageRoot
$WebOnly = $false
foreach ($Option in $args) {
    if ($Option -eq '--web-only' -or $Option -eq '-WebOnly') { $WebOnly = $true }
    else { Write-Error "Unknown option: $Option. Supported: --web-only"; exit 2 }
}
$RuntimeDir = Join-Path $PackageRoot '.runtime'
$CacheDir = Join-Path $RuntimeDir 'cache'
$LogsDir = Join-Path $RuntimeDir 'logs'
New-Item -ItemType Directory -Path $CacheDir, $LogsDir -Force | Out-Null
$LockDir = Join-Path $RuntimeDir 'bootstrap.lock'
$OwnsLock = $false
$RunId = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + $PID
$BootstrapLog = Join-Path $LogsDir "bootstrap-$RunId.log"
$PythonExe = $null
try {
    # CreateDirectory alone is not an exclusive lock; New-Item without -Force is.
    New-Item -ItemType Directory -Path $LockDir -ErrorAction Stop | Out-Null
    $OwnsLock = $true
    if ($env:ORCA_PYTHON) {
        $PythonExe = $env:ORCA_PYTHON
        if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {
            throw 'ORCA_PYTHON must name a Python 3.10 executable file.'
        }
        & $PythonExe -I -X utf8 -c 'import sys; assert sys.version_info[:2] == (3,10)'
        if ($LASTEXITCODE -ne 0) { throw 'ORCA_PYTHON requires Python 3.10.' }
    }
    else {
        $Architecture = $env:PROCESSOR_ARCHITECTURE
        if ($env:PROCESSOR_ARCHITEW6432) { $Architecture = $env:PROCESSOR_ARCHITEW6432 }
        if ($Architecture -ne 'AMD64') { throw 'This package supports 64-bit x86 Windows (AMD64).' }
        $Platform = 'x86_64-pc-windows-msvc'
        $ExpectedSha = '47ffefa9240d7354c086e9eb84e917d2460c6ae2a719281337218a2a3c83e4cf'
        $Candidates = Get-ChildItem -LiteralPath $RuntimeDir -Directory -Filter "python-$Platform-*"
        foreach ($Candidate in $Candidates) {
            $Marker = Join-Path $Candidate.FullName 'archive.sha256'
            $CandidatePython = Join-Path $Candidate.FullName 'python\python.exe'
            if ((Test-Path -LiteralPath $Marker -PathType Leaf) -and (Test-Path -LiteralPath $CandidatePython -PathType Leaf)) {
                if ((Get-Content -LiteralPath $Marker -Raw).Trim() -eq $ExpectedSha) {
                    & $CandidatePython -I -X utf8 -c 'import sys; assert sys.version_info[:3] == (3,10,19)' 2>&1 | Out-File -LiteralPath $BootstrapLog -Append
                    if ($LASTEXITCODE -eq 0) { $PythonExe = $CandidatePython; break }
                }
            }
        }
        if (-not $PythonExe) {
            $Asset = "cpython-3.10.19+20251014-$Platform-install_only_stripped.tar.gz"
            $Url = "https://github.com/astral-sh/python-build-standalone/releases/download/20251014/cpython-3.10.19%2B20251014-$Platform-install_only_stripped.tar.gz"
            $Archive = Join-Path $CacheDir $Asset
            $Partial = "$Archive.part"
            if (Test-Path -LiteralPath $Archive -PathType Leaf) {
                if ((Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ExpectedSha) {
                    throw "Cached Python checksum is incorrect. File preserved: $Archive. Move it aside manually and retry."
                }
            }
            else {
                if (-not (Get-Command curl.exe -ErrorAction SilentlyContinue)) { throw 'curl.exe is required (included in current Windows 10/11).' }
                Write-Host 'Downloading isolated Python 3.10.19 (first run only)...'
                & curl.exe --silent --show-error --fail --location --retry 3 --connect-timeout 30 --continue-at - --output $Partial $Url 2>&1 | Tee-Object -FilePath $BootstrapLog -Append
                if ($LASTEXITCODE -ne 0) { throw 'Python download failed. Retry the launcher to resume.' }
                if ((Get-FileHash -LiteralPath $Partial -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ExpectedSha) {
                    throw "Downloaded Python checksum is incorrect. File preserved: $Partial. Move it aside manually and retry."
                }
                Move-Item -LiteralPath $Partial -Destination $Archive
            }
            if (-not (Get-Command tar.exe -ErrorAction SilentlyContinue)) { throw 'tar.exe is required (included in current Windows 10/11).' }
            $ExtractDir = Join-Path $RuntimeDir "python-$Platform-$RunId"
            New-Item -ItemType Directory -Path $ExtractDir | Out-Null
            & tar.exe -xzf $Archive -C $ExtractDir 2>&1 | Out-File -LiteralPath $BootstrapLog -Append
            if ($LASTEXITCODE -ne 0) { throw "Python extraction failed. See $BootstrapLog" }
            $PythonExe = Join-Path $ExtractDir 'python\python.exe'
            & $PythonExe -I -X utf8 -c 'import sys; assert sys.version_info[:3] == (3,10,19)' 2>&1 | Out-File -LiteralPath $BootstrapLog -Append
            if ($LASTEXITCODE -ne 0) { throw "Isolated Python could not run. See $BootstrapLog" }
            Set-Content -LiteralPath (Join-Path $ExtractDir 'archive.sha256') -Value $ExpectedSha -Encoding ASCII
        }
    }
}
catch {
    Write-Host "ORCA bootstrap failed: $($_.Exception.Message)" -ForegroundColor Red
    if (-not $OwnsLock -and (Test-Path -LiteralPath $LockDir)) {
        Write-Host "Another bootstrap may be running. Inspect $LockDir before removing a stale lock manually."
    }
    exit 3
}
finally {
    if ($OwnsLock) { [System.IO.Directory]::Delete($LockDir) }
}
try {
    $SetupScript = Join-Path $PackageRoot 'bootstrap\setup.py'
    if ($WebOnly) { & $PythonExe -I -X utf8 $SetupScript --web-only }
    else { & $PythonExe -I -X utf8 $SetupScript }
    exit $LASTEXITCODE
}
catch {
    Write-Host "ORCA could not start: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
