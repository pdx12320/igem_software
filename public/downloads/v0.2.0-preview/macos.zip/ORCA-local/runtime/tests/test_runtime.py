"""Standard-library contract tests; worker scores are explicitly mocked.

Run: python -I -B runtime/tests/test_runtime.py
No Torch import, checkpoint load, dependency installation or biological
performance evaluation is performed. Only this suite's temporary fixtures
under .runtime/test-runs are cleaned up.
"""

from contextlib import ExitStack
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

sys.dont_write_bytecode = True
RUNTIME = Path(__file__).resolve().parent.parent
PACKAGE = RUNTIME.parent
sys.path.insert(0, str(RUNTIME))

import contracts
import model_runner
import server


class Fixtures:
    def setUp(self):
        directory = PACKAGE / ".runtime/test-runs"
        directory.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(prefix="stdlib-tests-", dir=str(directory))
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.sequence = "A" * 50 + "C" + "A" * 50

    def fasta(self, content, name="input.fasta"):
        path = self.directory / name
        path.write_bytes(content.encode("utf-8"))
        return path

    def request(self, path, sequence=None, transcript="target", position=51):
        sequence = self.sequence if sequence is None else sequence
        return {
            "schemaVersion": 1, "requestId": "stdlib-test-request",
            "modelId": "module4-lamar-101", "scoreType": "raw_ranking_score",
            "reference": {"name": path.name, "species": "synthetic-fixture", "kind": "transcript",
                          "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "sizeBytes": path.stat().st_size},
            "target": {"id": transcript, "sequence": sequence.replace("T", "U"), "position": position,
                       "motif": sequence[:8].replace("T", "U"), "bindingStart": 1},
        }

    def job(self, content, sequence=None, transcript="target", position=51, name="job"):
        job = self.directory / name
        job.mkdir()
        path = job / "input.fasta"
        path.write_bytes(content.encode("utf-8"))
        request = self.request(path, sequence=sequence, transcript=transcript, position=position)
        with (job / "request.json").open("x", encoding="utf-8") as output:
            json.dump(request, output)
        return job, request

    def mocked_model(self, score=-2.5):
        patches = ExitStack()
        patches.enter_context(mock.patch.object(model_runner, "verify_assets", return_value={"testOnly": "stub"}))
        patches.enter_context(mock.patch.object(model_runner, "build_model", return_value=(None, None, {"testOnly": "no inference"})))
        scorer = patches.enter_context(mock.patch.object(model_runner, "score_window", return_value=score))
        return patches, scorer


class ContractTests(Fixtures, unittest.TestCase):
    def test_exact_original_bytes_and_full_target(self):
        path = self.fasta(">target full header\r\n" + self.sequence.lower() + "\r\n")
        original = path.read_bytes()
        request = contracts.validate_request(self.request(path))
        summary = contracts.validate_fasta(path, request)
        self.assertEqual(summary, {"transcripts": 1, "bases": 101, "totalSites": 1})
        self.assertEqual(path.read_bytes(), original)

    def test_hash_and_byte_size_mismatches_are_rejected(self):
        path = self.fasta(">target\n" + self.sequence + "\n")
        request = self.request(path)
        wrong_hash = copy.deepcopy(request)
        wrong_hash["reference"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "checksum"):
            contracts.validate_fasta(path, wrong_hash)
        wrong_size = copy.deepcopy(request)
        wrong_size["reference"]["sizeBytes"] += 1
        with self.assertRaisesRegex(ValueError, "byte count"):
            contracts.validate_fasta(path, wrong_size)

    def test_duplicate_transcript_ids_are_rejected(self):
        path = self.fasta(">same description\nC\n>same another description\nA\n")
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            list(contracts.iter_fasta(path))

    def test_reference_iupac_is_preserved_and_u_normalized(self):
        path = self.fasta(">reference\na c g u r y s w k m b d h v n\n")
        self.assertEqual(list(contracts.iter_fasta(path)), [("reference", "ACGTRYSWKMBDHVN")])
        summary = contracts.validate_fasta(path, self.request(path, transcript="absent"))
        self.assertEqual(summary["totalSites"], 1)

    def test_invalid_or_empty_fasta_is_rejected(self):
        cases = ["ACGT\n", ">id\nACGZ\n", ">id\nAC-G\n", ">id\n", "\n"]
        for index, content in enumerate(cases):
            with self.subTest(content=content):
                path = self.fasta(content, "invalid-{0}.fasta".format(index))
                with self.assertRaises(ValueError):
                    list(contracts.iter_fasta(path))

    def test_full_target_sequence_mismatch_is_rejected(self):
        path = self.fasta(">target\n" + self.sequence + "\n")
        request = self.request(path, sequence="G" + self.sequence[1:])
        with self.assertRaisesRegex(ValueError, "differs"):
            contracts.validate_fasta(path, request)

    def test_absent_target_id_allows_reference_context_scoring(self):
        path = self.fasta(">reference\n" + self.sequence + "\n")
        summary = contracts.validate_fasta(path, self.request(path, transcript="unknown-target"))
        self.assertEqual(summary["totalSites"], 1)

    def test_request_coordinate_and_motif_validation(self):
        path = self.fasta(">target\n" + self.sequence + "\n")
        original = self.request(path)
        for key, value in [("position", True), ("position", 1), ("motif", "CCCCCCCC")]:
            with self.subTest(key=key, value=value):
                request = copy.deepcopy(original)
                request["target"][key] = value
                with self.assertRaises(ValueError):
                    contracts.validate_request(request)


class ContextTests(unittest.TestCase):
    def test_left_boundary_padding_preserves_center(self):
        window, padded = model_runner.center_window("C" + "A" * 70, 0)
        self.assertEqual(window, "N" * 50 + "C" + "A" * 50)
        self.assertTrue(padded)

    def test_right_boundary_padding_preserves_center(self):
        window, padded = model_runner.center_window("A" * 70 + "C", 70)
        self.assertEqual(window, "A" * 50 + "C" + "N" * 50)
        self.assertTrue(padded)

    def test_interior_coordinate_is_not_padded(self):
        sequence = "A" * 50 + "C" + "T" * 50
        window, padded = model_runner.center_window(sequence, 50)
        self.assertEqual(window, sequence)
        self.assertFalse(padded)

    def test_projection_does_not_modify_true_raw_score(self):
        row = {"transcript": "edge", "position": 1, "context": "N" * 50 + "C" + "N" * 50,
               "score": -2.5, "status": "scored"}
        projected, differs = model_runner.website_projection(row, True)
        self.assertTrue(differs)
        self.assertEqual(projected["status"], "insufficient_context")
        self.assertIsNone(projected["score"])
        self.assertEqual(row["score"], -2.5)
        self.assertEqual(row["status"], "scored")


class WorkerTests(Fixtures, unittest.TestCase):
    def test_complete_1003_sites_and_exact_target_beyond_preview(self):
        sequence = "A" * 50 + "C" * 1001 + "A" * 50
        content = ">target\n" + sequence + "\n>edge\nC\n>ambiguity\nCR\n"
        job, request = self.job(content, sequence=sequence, position=1051)
        original = (job / "input.fasta").read_bytes()
        patches, scorer = self.mocked_model()
        with patches:
            report = model_runner.run_job(job, PACKAGE)
        full = json.loads((job / "full.json").read_text())
        preview = json.loads((job / "preview.json").read_text())
        rows = [json.loads(line) for line in (job / "sites.jsonl").read_text().splitlines()]
        self.assertEqual(len(rows), 1003)
        self.assertEqual(len(full["sites"]), 1003)
        self.assertEqual(full["counts"]["total"], 1003)
        self.assertEqual(full["counts"]["scored"], 1002)
        self.assertEqual(full["counts"]["unscored"], 1)
        self.assertEqual(scorer.call_count, 1002)
        self.assertEqual(rows[-2]["score"], -2.5)
        self.assertEqual(rows[-2]["context"], "N" * 50 + "C" + "N" * 50)
        self.assertEqual(rows[-1]["status"], "unscored")
        self.assertIn("R", rows[-1]["reason"])
        self.assertEqual(len(preview["sites"]), 1000)
        self.assertEqual(preview["sites"][-1]["position"], 1051)
        self.assertEqual(preview["sites"][-1]["transcript"], "target")
        self.assertTrue(preview["preview"])
        self.assertTrue(report["targetReferenceRecordFound"])
        self.assertTrue(report["preview"]["targetLocusIncluded"])
        self.assertEqual((job / "input.fasta").read_bytes(), original)
        self.assertEqual(report["outputFiles"]["full.json"]["sha256"], hashlib.sha256((job / "full.json").read_bytes()).hexdigest())
        self.assertEqual(full["target"], request["target"])

    def test_absent_target_has_no_target_locus_assignment(self):
        job, _ = self.job(">reference\n" + self.sequence + "\n", transcript="unknown-target")
        patches, _ = self.mocked_model(score=0.0)
        with patches:
            report = model_runner.run_job(job, PACKAGE)
        self.assertFalse(report["targetReferenceRecordFound"])
        self.assertFalse(report["preview"]["targetLocusIncluded"])
        self.assertEqual(json.loads((job / "full.json").read_text())["sites"][0]["score"], 0.0)

    def test_target_mismatch_fails_before_model_load(self):
        job, _ = self.job(">target\n" + self.sequence + "\n", sequence="G" + self.sequence[1:])
        patches, scorer = self.mocked_model()
        with patches:
            with self.assertRaisesRegex(ValueError, "does not equal"):
                model_runner.run_job(job, PACKAGE)
        self.assertEqual(scorer.call_count, 0)
        self.assertFalse((job / "full.json").exists())
        self.assertEqual(json.loads((job / "progress.json").read_text())["status"], "failed")

    def test_cancellation_preserves_inputs_and_request(self):
        job, _ = self.job(">target\n" + self.sequence + "\n")
        original = (job / "input.fasta").read_bytes()
        (job / "cancel.request").write_text("test cancellation", encoding="utf-8")
        patches, scorer = self.mocked_model()
        with patches:
            with self.assertRaises(model_runner.Cancelled):
                model_runner.run_job(job, PACKAGE)
        self.assertEqual(scorer.call_count, 0)
        self.assertEqual((job / "input.fasta").read_bytes(), original)
        self.assertTrue((job / "cancel.request").exists())
        self.assertFalse((job / "full.json").exists())
        self.assertEqual(json.loads((job / "manifest.json").read_text())["status"], "cancelled")

    def test_existing_output_folder_is_not_modified(self):
        job, _ = self.job(">target\n" + self.sequence + "\n")
        (job / "full.json").write_text('{"old":"result"}\n', encoding="utf-8")
        (job / "progress.json").write_text('{"status":"succeeded"}\n', encoding="utf-8")
        before = {path.name: path.read_bytes() for path in job.iterdir()}
        with self.assertRaisesRegex(ValueError, "already exists"):
            model_runner.run_job(job, PACKAGE)
        self.assertEqual({path.name: path.read_bytes() for path in job.iterdir()}, before)


class CsvTests(unittest.TestCase):
    def test_missing_zero_and_negative_keep_distinct_types(self):
        self.assertEqual(server.protected_cell(None), "")
        self.assertEqual(server.protected_cell(0.0), 0.0)
        self.assertIsInstance(server.protected_cell(0.0), float)
        self.assertEqual(server.protected_cell(-2.5), -2.5)
        self.assertIsInstance(server.protected_cell(-2.5), float)

    def test_formula_like_text_is_protected(self):
        for value in ("=SUM(A1:A2)", "+cmd", "@formula", "-text", " \t=hidden"):
            with self.subTest(value=value):
                self.assertEqual(server.protected_cell(value), "'" + value)
        self.assertEqual(server.protected_cell("transcript,quoted\"id"), 'transcript,quoted"id')


if __name__ == "__main__":
    unittest.main(verbosity=2)
