from pathlib import Path
import csv,hashlib,io,json,time,urllib.request,urllib.error,uuid
import argparse
parser=argparse.ArgumentParser(description='Bounded actual HTTP/CPU integration on the shipped synthetic fixture.')
parser.add_argument('--url', default='http://127.0.0.1:8765')
args=parser.parse_args()
base=args.url.rstrip('/'); package=Path(__file__).resolve().parents[2]
request=json.loads((package/'examples/request.json').read_text())
request['requestId']='test-'+uuid.uuid4().hex
fasta=(package/'examples/synthetic-transcripts.fasta').read_bytes()
def http(path,body=None,ctype='application/json',origin=True):
 headers={'Content-Type':ctype}
 if origin:headers['Origin']=base
 req=urllib.request.Request(base+path,data=body,headers=headers)
 try:
  with urllib.request.urlopen(req,timeout=20) as result:return result.status,result.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
def multipart(meta,content=fasta):
 boundary='orca-test-'+uuid.uuid4().hex
 payload=(('--'+boundary+'\r\nContent-Disposition: form-data; name="metadata"\r\n\r\n'+json.dumps(meta)+'\r\n--'+boundary+'\r\nContent-Disposition: form-data; name="fasta"; filename="example.fasta"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()+content+('\r\n--'+boundary+'--\r\n').encode())
 return payload,'multipart/form-data; boundary='+boundary
status,body=http('/api/workflow/health');health=json.loads(body);assert status==200 and health['models']['lamar']
body,ctype=multipart(request)
status,response=http('/api/workflow/jobs',body,ctype,origin=False);assert status==403
status,response=http('/api/workflow/jobs',body,ctype);assert status==202,(status,response)
receipt=json.loads(response);job=receipt['id'];assert receipt['runtime']=='local'
status,response=http('/api/workflow/jobs',*multipart(request));assert status==202 and json.loads(response)['id']==job
status,response=http('/api/workflow/jobs',*multipart(request,fasta.replace(b'AAAA',b'UUUU',1)));assert status==400,(status,response)
conflict=json.loads(json.dumps(request));conflict['reference']['species']='Different';status,response=http('/api/workflow/jobs',*multipart(conflict));assert status==409
for i in range(60):
 status,response=http('/api/workflow/jobs/'+job);receipt=json.loads(response)
 if receipt['status'] in ['succeeded','failed','cancelled']:break
 time.sleep(.25)
assert receipt['status']=='succeeded',receipt
status,response=http('/api/workflow/jobs/'+job+'/result');preview=json.loads(response);assert len(preview['sites'])==4 and preview['preview']
status,response=http('/api/local/jobs/'+job+'/full.json');full=json.loads(response);assert full['schemaVersion']==2 and len(full['sites'])==4
assert full['counts']['total']==4 and full['counts']['scored']==3 and full['counts']['unscored']==1
assert full['sites'][0]['context'].startswith('N'*50) and full['sites'][0]['score'] is not None
assert full['sites'][1]['position']==51 and full['sites'][1]['score'] is not None and len(full['sites'][1]['context'])==101
assert full['sites'][-1]['score'] is None and 'R' in full['sites'][-1]['reason']
assert sum(s['score'] is not None for s in preview['sites'])==1
status,response=http('/api/local/jobs/'+job+'/full.csv');rows=list(csv.DictReader(io.StringIO(response.decode('utf-8-sig'))));assert len(rows)==4 and float(rows[0]['lamar_score'])==full['sites'][0]['score']
columns=json.loads((package/'runtime/scientist-columns.json').read_text())
chosen={k:'' for k in columns};chosen.update(record_type='target',target_id=request['target']['id'],target_position_1based=51,target_sequence=request['target']['sequence'],design_id='fixture',recognition_rna=request['target']['motif'],transcript_id=request['target']['id'],site_position_1based=51,reference_name=request['reference']['name'],reference_species=request['reference']['species'],reference_kind='transcript',reference_sha256=request['reference']['sha256'])
protein=dict(chosen,record_type='protein_candidate',protein_candidate_id='=formula-id',s_hat_raw=0,esm2_score=-77.34558942168951)
# Mimic shared serializer protection for text.
protein['protein_candidate_id']="'=formula-id"
s=io.StringIO();w=csv.DictWriter(s,columns,lineterminator='\r\n');w.writeheader();w.writerows([chosen,protein])
payload={'baseCsv':s.getvalue(),'referenceSha256':request['reference']['sha256'],'target':request['target']}
status,response=http('/api/local/jobs/'+job+'/scientist-export',json.dumps(payload).encode());assert status==201,(status,response)
url=json.loads(response)['url'];status,response=http(url);combined=list(csv.DictReader(io.StringIO(response.decode('utf-8-sig'))))
assert len(combined)==6 and sum(r['record_type']=='external_site' for r in combined)==4
assert float(combined[0]['lamar_score'])==full['sites'][1]['score'] and combined[1]['s_hat_raw']=='0' and float(combined[1]['esm2_score'])==-77.34558942168951
assert combined[1]['protein_candidate_id'].startswith("'") and combined[-1]['lamar_score']==''
bad=dict(payload,referenceSha256='0'*64);status,response=http('/api/local/jobs/'+job+'/scientist-export',json.dumps(bad).encode());assert status==400
status,response=http('/api/local/jobs/'+job+'/cancel',b'');assert status==200 and json.loads(response)['status']=='succeeded'
status,response=http('/../../asset-manifest.json');assert status==403
status,response=http('/runtime/server.py');assert status==404
# Invalid checksum/target/duplicate IDs rejected without inference.
for kind in ['checksum','target','duplicate']:
 bad=json.loads(json.dumps(request));bad['requestId']='bad-'+uuid.uuid4().hex;content=fasta
 if kind=='checksum':bad['reference']['sha256']='0'*64
 if kind=='target':bad['target']['sequence']='A'+bad['target']['sequence'][1:]
 if kind=='duplicate':
  content=fasta+b'>ORCA_SYNTHETIC_TARGET\nC\n';bad['reference'].update(sha256=hashlib.sha256(content).hexdigest(),sizeBytes=len(content))
 status,response=http('/api/workflow/jobs',*multipart(bad,content));assert status==400,(kind,status,response)
report={'status':'passed','scope':'actual loopback HTTP+CPU synthetic FASTA integration','jobId':job,'counts':full['counts'],'checks':['health','same-origin upload rejection','multipart job','idempotence','altered repeated file rejection','conflicting request ID','real CPU 4-C-site run','N boundary scoring preserved','unsupported IUPAC retained unscored','v1 projected preview','full JSON2','complete site CSV','combined scientist CSV','zeros and negative raw score preservation','exact target locus score','mismatched export rejection','path isolation','invalid checksum/target/duplicate rejection'],'fullRawScores':[s['score'] for s in full['sites']]}
report_dir=package/'.runtime'/'test-runs'/('integration-'+uuid.uuid4().hex)
report_dir.mkdir(parents=True)
(report_dir/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
print('Report saved:',report_dir/'report.json')
