"""Loopback-only ORCA UI, job transport and complete result exports.

Uses the Python standard library; model code executes in one separate CPU worker.
Every submission and export gets a new folder/file. Original inputs are retained.
"""
import argparse
import cgi
import csv
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import math
import mimetypes
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import unquote, urlsplit
import uuid
import webbrowser

sys.path.insert(0, str(Path(__file__).resolve().parent))
from contracts import MAX_FASTA_BYTES, MAX_METADATA_BYTES, validate_request, validate_fasta, request_fingerprint
from model_runner import MODEL_VERSION, atomic_json, self_check, sha256_file

ROOT = Path(__file__).resolve().parent.parent
TERMINAL = {"succeeded", "failed", "cancelled"}
CSV_COLUMNS = json.loads((ROOT / "runtime/scientist-columns.json").read_text(encoding="utf-8"))


class HTTPError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def protected_cell(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return value if math.isfinite(value) else ""
    value = str(value)
    if re.match(r"^[\s\x00-\x1f]*[=+@-]", value):
        value = "'" + value
    return value


class Jobs:
    def __init__(self, root, ready):
        self.root, self.ready = root, ready
        self.runs = root / ".runtime/runs"
        self.runs.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.process = None
        self.active = None
        self.process_log = None
        self.requests = {}
        self.directories = {}
        for directory in self.runs.glob("run_*"):
            try:
                request = validate_request(read_json(directory / "request.json"))
                self.requests[request["requestId"]] = directory.name
                self.directories[directory.name] = directory
                progress = read_json(directory / "progress.json")
                if progress.get("status") not in TERMINAL:
                    atomic_json(directory / "progress.json", {**progress, "status": "failed", "message": "Local server was interrupted. Partial files are retained; start a new job."})
            except (ValueError, KeyError, OSError):
                continue

    def directory(self, job_id):
        if not re.fullmatch(r"run_[a-f0-9]{32}", job_id) or job_id not in self.directories:
            raise HTTPError(404, "Local job does not exist in this extracted package.")
        return self.directories[job_id]

    def update(self):
        if self.process is not None and self.process.poll() is not None:
            directory = self.directory(self.active)
            progress = read_json(directory / "progress.json")
            if progress.get("status") not in TERMINAL:
                atomic_json(directory / "progress.json", {**progress, "status": "failed", "message": "Model worker stopped unexpectedly. Inspect the saved worker log."})
            self.process_log.close()
            self.process, self.active, self.process_log = None, None, None

    def receipt(self, job_id):
        with self.lock:
            self.update()
            directory = self.directory(job_id)
            request = read_json(directory / "request.json")
            progress = read_json(directory / "progress.json")
            return {"id": job_id, "requestId": request["requestId"], "referenceSha256": request["reference"]["sha256"],
                    "runtime": "local", **{k: progress[k] for k in ("status", "message", "completedSites", "totalSites", "counts") if k in progress}}

    def submit(self, request, upload):
        if not self.ready:
            raise HTTPError(503, "Local LaMAR did not pass the startup check. Use the full launcher and inspect its log.")
        with self.lock:
            self.update()
            previous = self.requests.get(request["requestId"])
            if previous:
                if request_fingerprint(read_json(self.directory(previous) / "request.json")) != request_fingerprint(request):
                    raise HTTPError(409, "Request ID was already used with different inputs.")
                digest, copied = hashlib.sha256(), 0
                while True:
                    block = upload.read(1024*1024)
                    if not block:
                        break
                    digest.update(block)
                    copied += len(block)
                    if copied > MAX_FASTA_BYTES:
                        raise HTTPError(413, "FASTA part exceeds 100 MiB.")
                if copied != request["reference"]["sizeBytes"] or digest.hexdigest() != request["reference"]["sha256"]:
                    raise HTTPError(400, "Repeated upload differs from the original FASTA bytes.")
                return self.receipt(previous)
            if self.process is not None:
                raise HTTPError(409, "One local model job is already running. Complete or cancel it before submitting another.")
            job_id = "run_" + uuid.uuid4().hex
            directory = self.runs / job_id
            directory.mkdir()
            fasta = directory / "input.fasta"
            with fasta.open("xb") as output:
                copied = 0
                while True:
                    block = upload.read(1024*1024)
                    if not block:
                        break
                    copied += len(block)
                    if copied > MAX_FASTA_BYTES:
                        raise HTTPError(413, "FASTA part exceeds 100 MiB.")
                    output.write(block)
            with (directory / "request.json").open("x", encoding="utf-8") as output:
                json.dump(request, output, ensure_ascii=False, allow_nan=False, indent=2)
            try:
                summary = validate_fasta(fasta, request)
            except (ValueError, UnicodeError) as error:
                atomic_json(directory / "progress.json", {"status": "failed", "message": str(error)})
                raise HTTPError(400, str(error))
            atomic_json(directory / "progress.json", {"status": "queued", "message": "Starting the local CPU worker.", "completedSites": 0, "totalSites": summary["totalSites"]})
            self.directories[job_id] = directory
            self.requests[request["requestId"]] = job_id
            env = dict(os.environ)
            env.update(PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2")
            self.process_log = (directory / "worker.log").open("x", encoding="utf-8")
            try:
                self.process = subprocess.Popen([sys.executable, "-I", "-B", "-X", "utf8", str(self.root / "runtime/model_runner.py"), "--package-root", str(self.root), "--job-dir", str(directory)],
                                                cwd=self.root, env=env, stdin=subprocess.DEVNULL, stdout=self.process_log, stderr=subprocess.STDOUT)
                self.active = job_id
            except OSError as error:
                self.process_log.close()
                self.process_log = None
                atomic_json(directory / "progress.json", {"status": "failed", "message": "Could not start CPU worker: " + str(error)})
                raise HTTPError(500, "Could not start the local model worker.")
            return self.receipt(job_id)

    def completed(self, job_id):
        if self.receipt(job_id)["status"] != "succeeded":
            raise HTTPError(409, "Complete downloads are available only after a successful run.")
        return self.directory(job_id)

    def cancel(self, job_id):
        with self.lock:
            directory = self.directory(job_id)
            if self.receipt(job_id)["status"] not in TERMINAL and not (directory / "cancel.request").exists():
                with (directory / "cancel.request").open("x", encoding="utf-8") as output:
                    output.write("Cancellation requested by the user.\n")
            return self.receipt(job_id)

    def close(self):
        with self.lock:
            if self.process is not None:
                self.cancel(self.active)
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    # Only terminate this server's own CPU worker.
                    self.process.terminate()
                    self.process.wait(timeout=10)
                self.update()

    def site_csv(self, job_id):
        directory = self.completed(job_id)
        dest = directory / "full-sites.csv"
        with self.lock:
            if dest.exists():
                return dest
            columns = ["transcript_id", "site_position_1based", "context_101nt", "lamar_score", "status", "reason", "boundary_padded", "model_version", "reference_sha256"]
            temporary = directory / ("sites-export-" + uuid.uuid4().hex + ".csv")
            writer_stream = temporary.open("x", encoding="utf-8-sig", newline="")
            with writer_stream as output:
                writer = csv.writer(output, lineterminator="\r\n")
                writer.writerow(columns)
                reference = read_json(directory / "request.json")["reference"]["sha256"]
                with (directory / "sites.jsonl").open(encoding="utf-8") as source:
                    for line in source:
                        row = json.loads(line)
                        writer.writerow([protected_cell(v) for v in [row["transcript"], row["position"], row["context"], row["score"], row["status"], row.get("reason"), row.get("boundaryPadded", False), MODEL_VERSION, reference]])
            os.rename(temporary, dest)
        return dest

    def scientist_export(self, job_id, data):
        directory = self.completed(job_id)
        request = read_json(directory / "request.json")
        if not isinstance(data, dict) or data.get("target") != request["target"] or data.get("referenceSha256") != request["reference"]["sha256"]:
            raise HTTPError(400, "Export target or reference does not match the completed run.")
        base = data.get("baseCsv")
        if not isinstance(base, str) or len(base.encode("utf-8")) > 2*1024*1024:
            raise HTTPError(413, "Design and protein CSV prefix exceeds 2 MiB.")
        reader = csv.DictReader(io.StringIO(base.lstrip("\ufeff"), newline=""))
        if reader.fieldnames != CSV_COLUMNS:
            raise HTTPError(400, "Export columns differ from the shared scientist CSV schema.")
        rows = list(reader)
        if not rows or rows[0].get("record_type") != "target" or any(None in row or row["record_type"] == "external_site" for row in rows):
            raise HTTPError(400, "Expected design/protein rows followed by backend site rows.")
        chosen = rows[0]
        if chosen["target_sequence"] != request["target"]["sequence"] or chosen["target_position_1based"] != str(request["target"]["position"]) or chosen["reference_sha256"] != request["reference"]["sha256"]:
            raise HTTPError(400, "CSV prefix differs from the verified target/reference.")
        exact_target = None
        with (directory / "sites.jsonl").open(encoding="utf-8") as source:
            for line in source:
                site = json.loads(line)
                if site["transcript"] == request["target"]["id"] and site["position"] == request["target"]["position"]:
                    exact_target = site
                    break
        def score_columns(site):
            return {"context_101nt": protected_cell(site["context"]) if site else "", "lamar_score": site["score"] if site and site["score"] is not None else "",
                    "lamar_score_available": "true" if site and site["score"] is not None else "false",
                    "lamar_score_type": "raw_ranking_score", "lamar_status": site["status"] if site else "site_unreported",
                    "lamar_model_version": MODEL_VERSION, "lamar_scope": "uploaded-transcript-fasta", "lamar_reference_sha256": request["reference"]["sha256"], "lamar_reference_set": ""}
        chosen.update(score_columns(exact_target))
        exports = directory / "exports"
        exports.mkdir(exist_ok=True)
        export_id = uuid.uuid4().hex
        destination = exports / (export_id + ".csv")
        with destination.open("x", encoding="utf-8-sig", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS, lineterminator="\r\n")
            writer.writeheader()
            # Prefix was already escaped by the shared browser serializer. Preserve
            # its numeric/text distinction, so a negative raw score stays numeric.
            writer.writerows(rows)
            with (directory / "sites.jsonl").open(encoding="utf-8") as source:
                for line in source:
                    site = json.loads(line)
                    result = dict(chosen)
                    for key in ("binding_rna", "binding_start_1based", "binding_end_1based", "site_offset_nt", "binding_mismatches"):
                        result[key] = ""
                    result.update(record_type="external_site", transcript_id=protected_cell(site["transcript"]), site_position_1based=site["position"], **score_columns(site))
                    writer.writerow(result)
        with (exports / (export_id + ".manifest.json")).open("x", encoding="utf-8") as output:
            json.dump({"kind": "orca-scientist-export", "schemaVersion": 2, "csvColumnsVersion": 1, "contextAlphabet": "ACGUN",
                       "jobId": job_id, "counts": read_json(directory / "manifest.json")["counts"], "referenceSha256": request["reference"]["sha256"],
                       "sha256": sha256_file(destination)}, output, indent=2)
        return {"url": "/api/local/jobs/" + job_id + "/exports/" + export_id + ".csv", "counts": read_json(directory / "manifest.json")["counts"]}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def json_response(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def guard(self, mutation=False):
        if self.headers.get("Host") != self.server.authority:
            raise HTTPError(403, "Use the printed 127.0.0.1 URL.")
        if self.headers.get("Sec-Fetch-Site") == "cross-site":
            raise HTTPError(403, "Cross-site requests are rejected.")
        if mutation and self.headers.get("Origin") != "http://" + self.server.authority:
            raise HTTPError(403, "Local jobs require the same browser origin.")
        url = urlsplit(self.path)
        if url.query or url.fragment:
            raise HTTPError(400, "Query parameters are not supported.")
        return unquote(url.path)

    def file_response(self, path, download_name=None):
        if not path.is_file():
            raise HTTPError(404, "File is unavailable.")
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(path.stat().st_size))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if download_name:
            self.send_header("Content-Disposition", 'attachment; filename="' + download_name + '"')
        self.end_headers()
        with path.open("rb") as source:
            shutil.copyfileobj(source, self.wfile, length=1024*1024)

    def do_GET(self):
        try:
            path = self.guard()
            jobs = self.server.jobs
            if path == "/api/workflow/health":
                return self.json_response({"available": jobs.ready, "runtime": "local", "models": {"esm2": False, "lamar": jobs.ready},
                                           "reason": "PUF ranking uses bundled cached ESM-2 features. " + self.server.reason})
            match = re.fullmatch(r"/api/(workflow|local)/jobs/(run_[a-f0-9]{32})(?:/(.*))?", path)
            if match:
                area, job_id, tail = match.groups()
                if area == "workflow" and tail is None:
                    return self.json_response(jobs.receipt(job_id))
                directory = jobs.completed(job_id)
                if area == "workflow" and tail == "result":
                    return self.file_response(directory / "preview.json")
                if area == "local" and tail == "full.json":
                    return self.file_response(directory / "full.json", "orca-results-full-v2.json")
                if area == "local" and tail == "full.csv":
                    return self.file_response(jobs.site_csv(job_id), "orca-lamar-all-sites.csv")
                if area == "local" and tail == "manifest.json":
                    return self.file_response(directory / "manifest.json", "orca-run-manifest.json")
                if area == "local" and re.fullmatch(r"exports/[a-f0-9]{32}\.csv", tail or ""):
                    return self.file_response(directory / tail, "orca-scientist-full.csv")
                raise HTTPError(404, "Unknown job endpoint.")
            if path.startswith("/api/"):
                raise HTTPError(404, "Unknown API endpoint.")
            if path.startswith("/examples/"):
                candidate = (ROOT / path.lstrip("/")).resolve()
                if ROOT / "examples" not in candidate.parents:
                    raise HTTPError(403, "Invalid example path.")
                return self.file_response(candidate)
            ui = ROOT / "ui"
            candidate = (ui / path.lstrip("/")).resolve()
            if candidate != ui and ui not in candidate.parents:
                raise HTTPError(403, "Invalid UI path.")
            if path in ("/", "/index.html"):
                candidate = ui / "index.html"
            return self.file_response(candidate)
        except (HTTPError, ValueError, OSError) as error:
            self.json_response({"error": str(error)}, getattr(error, "status", 500))
        except (BrokenPipeError, ConnectionResetError):
            pass

    def content_length(self, limit):
        if self.headers.get("Transfer-Encoding"):
            raise HTTPError(400, "Chunked uploads are not accepted.")
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            raise HTTPError(400, "Invalid content length.")
        if not 0 <= length <= limit:
            raise HTTPError(413, "Request body exceeds its local limit.")
        return length

    def do_POST(self):
        try:
            path = self.guard(mutation=True)
            self.connection.settimeout(60)
            if path == "/api/workflow/jobs":
                length = self.content_length(MAX_FASTA_BYTES + MAX_METADATA_BYTES)
                if not self.headers.get("Content-Type", "").startswith("multipart/form-data;"):
                    raise HTTPError(400, "Use metadata and fasta multipart fields.")
                form = cgi.FieldStorage(fp=self.rfile, headers=self.headers, environ={"REQUEST_METHOD": "POST", "CONTENT_TYPE": self.headers["Content-Type"], "CONTENT_LENGTH": str(length)},
                                        limit=length, keep_blank_values=True, max_num_fields=2)
                try:
                    if set(form.keys()) != {"metadata", "fasta"} or isinstance(form["metadata"], list) or isinstance(form["fasta"], list):
                        raise HTTPError(400, "Expected exactly one metadata field and one FASTA file.")
                    metadata, fasta = form["metadata"], form["fasta"]
                    if metadata.filename is not None or not isinstance(metadata.value, str) or len(metadata.value.encode("utf-8")) > MAX_METADATA_BYTES or fasta.filename is None:
                        raise HTTPError(400, "Invalid metadata or FASTA form fields.")
                    request = validate_request(json.loads(metadata.value))
                    return self.json_response(self.server.jobs.submit(request, fasta.file), 202)
                finally:
                    for part in form.list or []:
                        if part.file is not None:
                            part.file.close()
            match = re.fullmatch(r"/api/local/jobs/(run_[a-f0-9]{32})/(cancel|scientist-export)", path)
            if match:
                job_id, action = match.groups()
                length = self.content_length(2*1024*1024 + MAX_METADATA_BYTES)
                if action == "cancel":
                    if length:
                        self.rfile.read(length)
                    return self.json_response(self.server.jobs.cancel(job_id))
                if self.headers.get_content_type() != "application/json":
                    raise HTTPError(400, "Use JSON for the scientist export request.")
                data = json.loads(self.rfile.read(length))
                return self.json_response(self.server.jobs.scientist_export(job_id, data), 201)
            raise HTTPError(404, "Unknown API endpoint.")
        except (HTTPError, ValueError, UnicodeError, OSError) as error:
            self.json_response({"error": str(error)}, getattr(error, "status", 400))

    def log_message(self, fmt, *args):
        print(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), fmt % args, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--web-only", action="store_true")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args()
    if not (ROOT / "ui/index.html").is_file():
        raise SystemExit("Prebuilt UI is missing. Extract the complete ZIP.")
    runtime = ROOT / ".runtime"
    (runtime / "tmp").mkdir(parents=True, exist_ok=True)
    os.environ["TMPDIR"] = str(runtime / "tmp")
    import tempfile
    tempfile.tempdir = str(runtime / "tmp")
    ready, reason = False, "LaMAR is unavailable in website-only mode."
    report = {"status": "passed", "scope": "static UI and standard-library local server", "lamar": False}
    if not args.web_only:
        try:
            report = self_check(ROOT)
            ready, reason = True, "The bounded synthetic startup check passed."
        except Exception as error:
            report = {"status": "failed", "error": str(error)}
            reason = "LaMAR startup check failed; inspect the console log."
            print(reason, error, file=sys.stderr, flush=True)
    if args.self_check:
        print(json.dumps(report, ensure_ascii=False, allow_nan=False, indent=2))
        return 0 if report["status"] == "passed" else 1
    if not 1 <= args.port <= 65535:
        raise SystemExit("Port must be between 1 and 65535.")
    lock = runtime / "server.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        raise SystemExit("An ORCA server is already running in this package, or was interrupted. Inspect .runtime/server.lock and the earlier console before removing a stale lock.")
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    except OSError as error:
        lock.rmdir()
        raise SystemExit("Cannot bind the loopback port. Close your earlier ORCA console or choose ORCA_PORT. " + str(error))
    try:
        jobs = Jobs(ROOT, ready)
    except Exception:
        server.server_close()
        lock.rmdir()
        raise
    server.daemon_threads = True
    server.authority, server.jobs, server.reason = "127.0.0.1:" + str(args.port), jobs, reason
    url = "http://" + server.authority + "/"
    print("ORCA local: " + url + " Keep the console open; Ctrl+C stops this server.", flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        def stop(signum, frame):
            raise KeyboardInterrupt()
        signal.signal(signal.SIGTERM, stop)
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        jobs.close()
        server.server_close()
        lock.rmdir()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
