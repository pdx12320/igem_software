"""Validate transport inputs without changing trained model methods."""
import hashlib
import json
from pathlib import Path
import re

MAX_FASTA_BYTES = 100 * 1024 * 1024
MAX_METADATA_BYTES = 64 * 1024
MODEL_ID = "module4-lamar-101"


def iter_fasta(path):
    """Yield unique transcript IDs and uppercase DNA spelling, one record at a time."""
    seen, name, parts = set(), None, []
    with Path(path).open("r", encoding="utf-8-sig", newline=None) as source:
        for raw in source:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    if not parts:
                        raise ValueError("Empty reference transcript: " + name)
                    yield name, "".join(parts)
                header = line[1:].strip().split()
                name = header[0] if header else ""
                if not name or len(name) > 300 or ">" in name:
                    raise ValueError("FASTA transcript IDs must contain 1 to 300 characters.")
                if name in seen:
                    raise ValueError("Duplicate FASTA transcript ID: " + name)
                seen.add(name)
                parts = []
            else:
                if name is None:
                    raise ValueError("Reference FASTA must begin with a transcript header.")
                bases = re.sub(r"\s+", "", line).upper().replace("U", "T")
                if not re.fullmatch(r"[ACGTRYSWKMBDHVN]+", bases):
                    raise ValueError("Invalid nucleotide characters in transcript " + name)
                parts.append(bases)
    if name is None:
        raise ValueError("Reference FASTA has no transcripts.")
    if not parts:
        raise ValueError("Empty reference transcript: " + name)
    yield name, "".join(parts)


def text(value, limit):
    return isinstance(value, str) and 0 < len(value.strip()) <= limit and len(value) <= limit


def integer(value, minimum=1, maximum=2**53-1):
    return isinstance(value, int) and not isinstance(value, bool) and minimum <= value <= maximum


def validate_request(value):
    if not isinstance(value, dict):
        raise ValueError("Expected a request object.")
    if value.get("schemaVersion") != 1 or value.get("modelId") != MODEL_ID or value.get("scoreType") != "raw_ranking_score":
        raise ValueError("Unsupported workflow request schema or model.")
    if not isinstance(value.get("requestId"), str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", value["requestId"]):
        raise ValueError("Invalid request ID.")
    target, reference = value.get("target"), value.get("reference")
    if not isinstance(target, dict) or not isinstance(reference, dict):
        raise ValueError("Request needs a target and reference.")
    if not text(target.get("id"), 300) or not isinstance(target.get("sequence"), str) or not re.fullmatch(r"[ACGU]+", target["sequence"]):
        raise ValueError("Target must have an ID and uppercase ACGU sequence.")
    if not integer(target.get("position"), maximum=len(target["sequence"])) or target["sequence"][target["position"]-1] != "C":
        raise ValueError("Target position must identify C using 1-based coordinates.")
    motif = target.get("motif")
    if not isinstance(motif, str) or not re.fullmatch(r"[ACGU]{8,12}", motif) or not integer(target.get("bindingStart"), maximum=len(target["sequence"])-len(motif)+1):
        raise ValueError("Target recognition interval must contain 8 to 12 RNA bases.")
    start = target["bindingStart"]-1
    if target["sequence"][start:start+len(motif)] != motif:
        raise ValueError("Recognition RNA differs from the target interval.")
    if reference.get("kind") != "transcript" or not text(reference.get("name"), 300) or not text(reference.get("species"), 200):
        raise ValueError("A named transcript FASTA and explicit species label are required.")
    if not isinstance(reference.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", reference["sha256"]):
        raise ValueError("Expected the exact FASTA SHA-256.")
    if not integer(reference.get("sizeBytes"), maximum=MAX_FASTA_BYTES):
        raise ValueError("Reference FASTA must contain 1 byte to 100 MiB.")
    # Discard extra fields; preserve every documented target/reference field exactly.
    return {"schemaVersion": 1, "requestId": value["requestId"], "modelId": MODEL_ID,
            "scoreType": "raw_ranking_score", "target": {k: target[k] for k in ("id", "sequence", "position", "motif", "bindingStart")},
            "reference": {k: reference[k] for k in ("name", "species", "kind", "sha256", "sizeBytes")}}


def validate_fasta(path, request):
    path = Path(path)
    if path.stat().st_size != request["reference"]["sizeBytes"]:
        raise ValueError("Uploaded FASTA byte count differs from request metadata.")
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024*1024), b""):
            digest.update(block)
    if digest.hexdigest() != request["reference"]["sha256"]:
        raise ValueError("Uploaded FASTA checksum differs from request metadata.")
    records = bases = sites = 0
    for transcript, sequence in iter_fasta(path):
        if transcript == request["target"]["id"] and sequence != request["target"]["sequence"].replace("U", "T"):
            raise ValueError("The reference transcript with the target ID differs from the complete target RNA.")
        records += 1
        bases += len(sequence)
        sites += sequence.count("C")
    return {"transcripts": records, "bases": bases, "totalSites": sites}


def request_fingerprint(request):
    return hashlib.sha256(json.dumps(request, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
