"""CPU runner preserving the supplied 101-nt LaMAR evaluator.

The complete JSONL/JSON results retain N-padded scores. The schema-1 preview
projects rows into the older website alphabet contract, recording every loss.
No motif filter, threshold, top-K score selection, or probability conversion
is applied. This module only reads the original request and FASTA inputs.
"""

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import sys
import time
import uuid


UPSTREAM_COMMIT = "d651d00be2f5087915dc1a1233958dca9f93ea48"
CHECKPOINT_SHA256 = "489eed13a9e7519f0b8250350c0af1fe7ffbe17c845381637dcc18dc566bc3de"
MODEL_VERSION = "orca-lamar-101-" + CHECKPOINT_SHA256[:16] + "-upstream-" + UPSTREAM_COMMIT[:12]
EXPECTED_FIXTURE_SCORE = -1.1762536764144897
CORE_VERSIONS = {
    "torch": "2.0.1", "transformers": "4.32.1", "tokenizers": "0.13.3",
    "safetensors": "0.4.0", "numpy": "1.24.3",
}
ASSET_HASHES = {
    "runtime/vendor/LAMAR/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "runtime/vendor/LAMAR/modeling_nucESM2.py": "b9b1e78b03e7991385e684203483c3f7114dbc9455e4a587ac1d7d415adae5b6",
    "runtime/vendor/LAMAR/sequence_classification_patch.py": "9dcc686bffb3a896d7e21bc2759976e70d72954c3283eae2cd22124538159f1c",
    "runtime/vendor/LAMAR/LossFunctions.py": "503e9d2369b002478da3569c80d3f229a6e1d6ffa79956853b7f7b9bea96bbbb",
    "models/config_150M.json": "e512f68ec444d99477703a9806639ca83da3dbc19f6c5fe428d6e5b7460972dc",
    "models/tokenizer/vocab.txt": "6e2533a6a62d7832f4de311c5829d353ecf9a34399e644ba82d96970e98864ea",
    "models/tokenizer/tokenizer_config.json": "9dee94dd3f82b377ff6070f6df93aac4a3e8251aea61b9421f5aca05674f5c1f",
    "models/tokenizer/special_tokens_map.json": "5f89dfed5b1bcb31b03a93b608b8c7fc5ac8465f2f4b839f6f6f4aa87d683407",
    "models/model_101_classifier/best_model/model.safetensors": CHECKPOINT_SHA256,
}
PREVIEW_LIMIT = 1000
MODEL_ALPHABET = frozenset("ACGTN")


class Cancelled(Exception):
    pass


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value):
    """Replace only this runner's mutable diagnostic file, within its new job."""
    path = Path(path)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    with temp.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(value, output, ensure_ascii=False, allow_nan=False, indent=2)
        output.write("\n")
    os.replace(str(temp), str(path))


def check_cancelled(job_dir):
    if (job_dir / "cancel.request").exists():
        raise Cancelled("Cancelled by the user; partial output is retained.")


def center_window(sequence, position):
    """Original evaluator uses a zero-based C position and N padding."""
    start = position - 50
    end = position + 51
    left = max(0, -start)
    right = max(0, end - len(sequence))
    window = "N" * left + sequence[max(0, start):min(len(sequence), end)] + "N" * right
    if len(window) != 101 or window[50] != "C":
        raise ValueError("C-centered window construction failed.")
    return window, bool(left or right)


def versions():
    return {name: importlib.metadata.version(name) for name in CORE_VERSIONS}


def verify_assets(package_root):
    verified = {}
    for relative, expected in ASSET_HASHES.items():
        path = package_root / relative
        if not path.is_file():
            raise ValueError("Required model asset is missing: " + relative)
        actual = sha256_file(path)
        if actual != expected:
            raise ValueError("Required model asset checksum mismatch: " + relative)
        verified[relative] = {"sha256": actual, "bytes": path.stat().st_size}
    return verified


def build_model(package_root):
    """Use only pinned local code/assets and the evaluator's inherited config."""
    runtime_versions = versions()
    differences = {
        name: value for name, value in runtime_versions.items()
        if value != CORE_VERSIONS[name] and not (name == "torch" and value == "2.0.1+cpu")
    }
    if differences:
        raise ValueError("Core inference versions differ from the pinned environment: " + json.dumps(differences))
    for name, value in {
        "OMP_NUM_THREADS": "2", "MKL_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2",
        "TOKENIZERS_PARALLELISM": "false", "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
        "XDG_CACHE_HOME": str(package_root / ".runtime/cache"),
        "HF_HOME": str(package_root / ".runtime/cache/huggingface"),
        "TRANSFORMERS_CACHE": str(package_root / ".runtime/cache/transformers"),
        "TORCH_HOME": str(package_root / ".runtime/cache/torch"),
    }.items():
        os.environ[name] = value
    import torch
    from torch import nn
    from safetensors.torch import load_file
    from transformers import AutoConfig, AutoTokenizer

    torch.set_num_threads(2)
    # PyTorch 2.0.1 can abort the process on macOS if this setter is called
    # twice, even with the same value. ESM-2 and LaMAR share one worker.
    if torch.get_num_interop_threads() != 1:
        torch.set_num_interop_threads(1)
    sys.path.insert(0, str(package_root / "runtime/vendor"))
    from LAMAR.sequence_classification_patch import EsmForSequenceClassification

    class CenterTokenScoreHead(nn.Module):
        def __init__(self, config):
            super().__init__()
            self.center_index = 51
            self.dropout = nn.Dropout(config.hidden_dropout_prob)
            self.dense = nn.Linear(config.hidden_size, config.hidden_size)
            self.out_proj = nn.Linear(config.hidden_size, 1)

        def forward(self, hidden_states):
            x = self.dropout(hidden_states[:, self.center_index, :])
            x = torch.tanh(self.dense(x))
            return self.out_proj(self.dropout(x)).squeeze(-1)

    tokenizer = AutoTokenizer.from_pretrained(
        str(package_root / "models/tokenizer"), model_max_length=103,
        local_files_only=True, trust_remote_code=False,
    )
    config = AutoConfig.from_pretrained(
        str(package_root / "models/config_150M.json"), vocab_size=len(tokenizer),
        pad_token_id=tokenizer.pad_token_id, num_labels=1, problem_type="regression",
        hidden_size=768, intermediate_size=3072, num_attention_heads=12,
        num_hidden_layers=12, positional_embedding_type="rotary",
        local_files_only=True, trust_remote_code=False,
    )
    # Preserve the original evaluator, including this inherited mask ID. The
    # inherited 32 differs from tokenizer.mask_token_id=4; correcting it would
    # change the model, so this package records it without substituting it.
    if config.position_embedding_type != "rotary" or config.token_dropout is not True or config.mask_token_id != 32:
        raise ValueError("Inference configuration differs from the original 101-nt evaluator.")
    expected_tokens = {"<cls>": 0, "<pad>": 1, "<eos>": 2, "<unk>": 3, "<mask>": 4, "A": 5, "T": 6, "C": 7, "G": 8, "N": 9}
    if tokenizer.get_vocab() != expected_tokens:
        raise ValueError("Tokenizer vocabulary differs from the audited evaluator.")
    model = EsmForSequenceClassification(config, "Linear", False, [2, 3, 5], 32)
    model.classifier = CenterTokenScoreHead(config)
    weights = load_file(str(package_root / "models/model_101_classifier/best_model/model.safetensors"), device="cpu")
    loaded = model.load_state_dict(weights, strict=True)
    del weights
    if loaded.missing_keys or loaded.unexpected_keys:
        raise ValueError("Strict checkpoint loading did not preserve all parameters.")
    model.eval()
    return model, tokenizer, runtime_versions


def score_window(model, tokenizer, window):
    import torch
    if len(window) != 101 or window[50] != "C" or set(window) - MODEL_ALPHABET:
        raise ValueError("The model requires one ACGTN 101-nt C-centered context.")
    encoded = tokenizer([window], padding=True, truncation=True, max_length=103, return_tensors="pt")
    if tuple(encoded["input_ids"].shape) != (1, 103) or encoded["input_ids"][0, 51].item() != 7:
        raise ValueError("Tokenized context lost its expected center or length.")
    with torch.inference_mode():
        outputs = model(**encoded, output_hidden_states=True)
        scores = model.classifier(outputs.hidden_states[-1])
    if tuple(scores.shape) != (1,) or not torch.isfinite(scores).all().item():
        raise ValueError("The model returned an invalid scalar.")
    if not torch.equal(scores, outputs.logits):
        raise ValueError("Center-head output differs from the classifier forward output.")
    return float(scores.item())


def self_check(package_root):
    """Bounded, synthetic CPU check; does not establish biological validity."""
    package_root = Path(package_root).resolve()
    started = time.monotonic()
    assets = verify_assets(package_root)
    model, tokenizer, runtime_versions = build_model(package_root)
    sequence = ("ACGT" * 13)[:50] + "C" + ("TGCA" * 13)[:50]
    score = score_window(model, tokenizer, sequence)
    # Software-portability tolerance on the archived synthetic fixture only.
    # This is not an editing threshold, score cutoff, or calibration method.
    if not math.isclose(score, EXPECTED_FIXTURE_SCORE, rel_tol=0.0, abs_tol=1e-4):
        raise ValueError("Synthetic fixture differs from the archived CPU result: " + repr(score))
    return {
        "status": "passed", "scope": "strict checkpoint load and one synthetic 101-nt CPU forward pass",
        "modelVersion": MODEL_VERSION, "upstreamCommit": UPSTREAM_COMMIT,
        "checkpointSha256": CHECKPOINT_SHA256, "versions": runtime_versions,
        "python": platform.python_version(), "system": platform.system(), "architecture": platform.machine(),
        "device": "cpu", "threads": 2, "batchSize": 1, "inputLengthNt": 101,
        "inputSha256": hashlib.sha256(sequence.encode("ascii")).hexdigest(),
        "rawScore": score, "expectedRawScore": EXPECTED_FIXTURE_SCORE, "fixtureTolerance": 1e-4,
        "tokenDropout": True, "maskTokenId": 32, "strictLoading": True,
        "elapsedSeconds": round(time.monotonic() - started, 3), "assets": assets,
        "biologicalValidation": False,
    }


def website_projection(row, boundary):
    """Schema 1 admits only ACGU contexts; retain true N scores in full output."""
    projected = {key: row[key] for key in ("transcript", "position", "context", "score", "status")}
    differs = False
    if row["context"] is not None and "N" in row["context"]:
        projected.update(context=None, score=None, status="insufficient_context" if boundary else "unscored")
        differs = True
    return projected, differs


def run_job(job_dir, package_root):
    # The launcher uses Python -I, which omits the script directory from imports.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from contracts import iter_fasta

    job_dir = Path(job_dir).resolve()
    package_root = Path(package_root).resolve()
    started = time.monotonic()
    counts = {"total": 0, "scored": 0, "unscored": 0, "insufficient_context": 0,
              "padded": 0, "unsupported": 0, "previewScored": 0}
    completed = 0
    request = None
    asset_report = {}
    runtime_versions = {}
    transcript_count = 0
    base_count = 0
    last_progress = 0.0

    def progress(status, message, force=False):
        nonlocal last_progress
        now = time.monotonic()
        if force or now - last_progress >= 0.5:
            atomic_json(job_dir / "progress.json", {
                "status": status, "message": message, "counts": counts.copy(),
                "completedSites": completed, "totalSites": counts["total"],
                "elapsedSeconds": round(now - started, 3),
            })
            last_progress = now

    def manifest(status, message):
        return {
            "kind": "orca-local-run-manifest", "schemaVersion": 2, "jobId": job_dir.name,
            "status": status, "completion": status, "message": message, "counts": counts.copy(),
            "completedSites": completed, "totalSites": counts["total"], "transcripts": transcript_count,
            "bases": base_count, "elapsedSeconds": round(time.monotonic() - started, 3),
            "modelVersion": MODEL_VERSION, "checkpointSha256": CHECKPOINT_SHA256,
            "upstreamCommit": UPSTREAM_COMMIT, "versions": runtime_versions,
            "python": platform.python_version(), "system": platform.system(), "architecture": platform.machine(),
            "device": "cpu", "threads": 2, "batchSize": 1, "assets": asset_report,
            "preprocessing": {"alphabet": "ACGTN", "normalization": "uppercase; U to T",
                              "windowNt": 101, "centerTokenIndex": 51, "boundaryPadding": "N",
                              "unsupportedIupac": "retained as unscored rows", "siteEnumeration": "every C",
                              "motifFilter": False, "scoreCutoff": None, "tokenDropout": True, "maskTokenId": 32},
            "scoreType": "raw_ranking_score", "scope": "uploaded-transcript-fasta",
            "input": request, "biologicalValidation": False,
        }

    # Reject reused output folders before diagnostics can alter old progress.
    for name in ("sites.jsonl", "full.json", "preview.json", "manifest.json"):
        if (job_dir / name).exists():
            raise ValueError("Job output already exists; create a new job: " + name)
    try:
        request = json.loads((job_dir / "request.json").read_text(encoding="utf-8"))
        fasta = job_dir / "input.fasta"
        progress("running", "Validating the complete FASTA and its checksum.", True)
        check_cancelled(job_dir)
        if sha256_file(fasta) != request["reference"]["sha256"]:
            raise ValueError("FASTA bytes do not match the request checksum.")
        if fasta.stat().st_size != request["reference"]["sizeBytes"]:
            raise ValueError("FASTA size does not match the request.")
        target_transcript = request["target"]["id"]
        target_position = request["target"]["position"]
        normalized_target = request["target"]["sequence"].upper().replace("U", "T")
        target_found = False
        for transcript, sequence in iter_fasta(fasta):
            check_cancelled(job_dir)
            if transcript == target_transcript:
                target_found = True
                if sequence != normalized_target:
                    raise ValueError("Target sequence does not equal the exact reference transcript record.")
                if not isinstance(target_position, int) or isinstance(target_position, bool) or not 1 <= target_position <= len(sequence) or sequence[target_position - 1] != "C":
                    raise ValueError("Target coordinate is not a 1-based C in the exact reference transcript.")
            transcript_count += 1
            base_count += len(sequence)
            counts["total"] += sequence.count("C")
        # A target may have no known reference transcript. Context-only scoring
        # still runs; no target-locus score is assigned without an exact match.
        progress("running", "Verifying the pinned model assets and loading the CPU model.", True)
        asset_report = verify_assets(package_root)
        check_cancelled(job_dir)
        model, tokenizer, runtime_versions = build_model(package_root)
        check_cancelled(job_dir)
        metadata = {
            "jobId": job_dir.name, "requestId": request["requestId"], "modelId": request["modelId"],
            "modelVersion": MODEL_VERSION, "referenceSha256": request["reference"]["sha256"],
            "species": request["reference"]["species"], "referenceKind": "transcript",
            "scope": "uploaded-transcript-fasta", "scoreType": "raw_ranking_score", "target": request["target"],
        }
        preview_rows = []
        target_row = None
        representation_differs = False
        progress("running", "Scoring every cytidine in FASTA order.", True)
        with (job_dir / "sites.jsonl").open("x", encoding="utf-8", newline="\n") as output:
            for transcript, sequence in iter_fasta(fasta):
                for position, base in enumerate(sequence):
                    if position % 10000 == 0:
                        check_cancelled(job_dir)
                    if base != "C":
                        continue
                    check_cancelled(job_dir)
                    window, boundary = center_window(sequence, position)
                    unsupported = sorted(set(window) - MODEL_ALPHABET)
                    counts["padded"] += int(boundary)
                    if unsupported:
                        row = {"transcript": transcript, "position": position + 1,
                               "context": None, "score": None, "status": "unscored",
                               "reason": "Context includes unsupported IUPAC symbols: " + "".join(unsupported),
                               "boundaryPadded": boundary}
                        counts["unscored"] += 1
                        counts["unsupported"] += 1
                    else:
                        row = {"transcript": transcript, "position": position + 1,
                               "context": window.replace("T", "U"), "score": score_window(model, tokenizer, window),
                               "status": "scored", "boundaryPadded": boundary}
                        counts["scored"] += 1
                    output.write(json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
                    output.flush()
                    projected, differs = website_projection(row, boundary)
                    representation_differs = representation_differs or differs
                    if len(preview_rows) < PREVIEW_LIMIT:
                        preview_rows.append(projected)
                    if transcript == target_transcript and position + 1 == target_position:
                        target_row = projected
                    completed += 1
                    progress("running", "Processed {0} of {1} cytidine sites.".format(completed, counts["total"]))
        check_cancelled(job_dir)
        if sha256_file(fasta) != request["reference"]["sha256"]:
            raise ValueError("The saved FASTA changed during the run; completed output is unavailable.")
        if completed != counts["total"] or counts["scored"] + counts["unscored"] != completed:
            raise ValueError("Complete result counts do not match the enumerated cytidines.")
        if target_row is not None and not any(row["transcript"] == target_transcript and row["position"] == target_position for row in preview_rows):
            if len(preview_rows) >= PREVIEW_LIMIT:
                preview_rows[-1] = target_row
            else:
                preview_rows.append(target_row)
        counts["previewScored"] = sum(row["status"] == "scored" for row in preview_rows)
        counts["previewRows"] = len(preview_rows)
        counts["previewInsufficientContext"] = sum(row["status"] == "insufficient_context" for row in preview_rows)
        preview = dict(metadata, schemaVersion=1, sites=preview_rows,
                       preview=representation_differs or counts["total"] > PREVIEW_LIMIT,
                       totalSites=counts["total"], counts=counts.copy(),
                       previewReason="First loci in FASTA order; exact target locus retained. N contexts are projected into the schema-1 alphabet; complete N-padded scores remain in the full download.")
        with (job_dir / "preview.json").open("x", encoding="utf-8", newline="\n") as output:
            json.dump(preview, output, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            output.write("\n")
        full_metadata = dict(metadata, kind="orca-local-results", schemaVersion=2,
                             completion="succeeded", counts=counts.copy(),
                             coordinateConvention="1-based transcript record coordinates",
                             contextAlphabet="ACGUN; N retains the original model's padding/token semantics")
        with (job_dir / "full.json").open("x", encoding="utf-8", newline="\n") as output:
            serialized = json.dumps(full_metadata, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            output.write(serialized[:-1] + ',"sites":[')
            first = True
            with (job_dir / "sites.jsonl").open("r", encoding="utf-8") as rows:
                for index, line in enumerate(rows):
                    if index % 256 == 0:
                        check_cancelled(job_dir)
                    if not first:
                        output.write(",")
                    output.write(line.rstrip("\n"))
                    first = False
            output.write("]}\n")
        report = manifest("succeeded", "Complete raw model results are available; preview projection is documented separately.")
        report["outputFiles"] = {}
        for name in ("sites.jsonl", "full.json", "preview.json"):
            check_cancelled(job_dir)
            path = job_dir / name
            report["outputFiles"][name] = {"sha256": sha256_file(path), "bytes": path.stat().st_size}
        report["preview"] = {"rows": len(preview_rows), "limit": PREVIEW_LIMIT,
                             "differsFromFull": preview["preview"], "targetLocusIncluded": target_row is not None,
                             "order": "first FASTA loci with the exact target locus retained"}
        report["targetReferenceRecordFound"] = target_found
        with (job_dir / "manifest.json").open("x", encoding="utf-8", newline="\n") as output:
            json.dump(report, output, ensure_ascii=False, allow_nan=False, indent=2)
            output.write("\n")
        progress("succeeded", "Completed all {0} cytidine sites. Download the full result for every raw score.".format(completed), True)
        return report
    except Exception as error:
        status = "cancelled" if isinstance(error, Cancelled) else "failed"
        message = str(error) or error.__class__.__name__
        progress(status, message, True)
        # Preserve partial JSONL and inputs. No complete download is advertised.
        if not (job_dir / "manifest.json").exists():
            with (job_dir / "manifest.json").open("x", encoding="utf-8", newline="\n") as output:
                json.dump(manifest(status, message), output, ensure_ascii=False, allow_nan=False, indent=2)
                output.write("\n")
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--job-dir", type=Path)
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args()
    if args.self_check:
        print(json.dumps(self_check(args.package_root), ensure_ascii=False, allow_nan=False, indent=2))
    elif args.job_dir is not None:
        print(json.dumps(run_job(args.job_dir, args.package_root), ensure_ascii=False, allow_nan=False, indent=2))
    else:
        parser.error("--job-dir is required unless --self-check is selected")


if __name__ == "__main__":
    main()
