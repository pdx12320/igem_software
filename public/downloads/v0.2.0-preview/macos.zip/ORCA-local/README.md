# ORCA Local · 0.2.0

Install the local models, enter the CSV exported from the ORCA website and a species FASTA path, then run ESM-2 ranking and LaMAR on your computer.

1. On the website, prepare your target and PUF candidates, then download the CSV from **Work → 03 Export**.
2. Extract the complete ZIP to a writable local folder. Double-click `Start-macOS.command` on macOS or `Start-Windows.cmd` on Windows x64.
3. First launch downloads a verified Python 3.10.19 runtime, pinned dependencies, ESM-2 weights (136 MB), and the previous ORCA release archive (324 MB) containing the supplied LaMAR weights. Files and the isolated environment stay in this folder. Internet is required for this installation.
4. Keep the console open. The browser opens `http://127.0.0.1:8765/`. Paste the full paths to the website CSV and your species FASTA, optionally enter a species label, and select **Run analysis**.
5. Download the ranking, LaMAR sites, combined CSV and manifest. Each run has a new `results/<run-id>/` folder. The original input files remain unchanged.

The download package is a model installer; it does not bundle installed dependencies or the large weights. Matching local models are verified and reused. Interrupted downloads are retained for retry; a checksum mismatch is reported without replacing the existing file. Setup logs and the ESM-2 reference cache are under `.runtime/`. Start with the supplied small `examples/` files before using your full reference. Complete FASTA analysis can take substantially longer; there is no measured species-wide runtime or minimum-memory guarantee.

## Inputs and outputs

Use the website's full scientist CSV, with its original column names and 1-based coordinates. Saved score columns are ignored for the new local run. The CSV must contain an assembled PUF protein or saved protein candidates. Use an uncompressed FASTA of nucleotide records with unique IDs; each ID is the first whitespace-delimited field after `>`. Transcript-oriented sequence is the usual input. A genome file is evaluated in its supplied record orientation; this tool does not annotate transcripts or map splicing or reverse strands.

If the CSV records a FASTA checksum, the selected FASTA must match it. If its target ID is present, that record's entire sequence must match the exported target RNA after U/T normalization. An absent target ID is recorded and receives no target-locus LaMAR score. It does not prevent scoring the reference records.

| File | Contents |
| --- | --- |
| `protein-ranking.csv` | Candidate ranks and the separate ESM-2 and frozen Ridge outputs; incompatible scaffolds remain unscored. |
| `lamar-sites.csv` | Every C in FASTA order, including unscored contexts and boundary-padding flags. |
| `combined-results.csv` | Target, candidate and reference-site rows in the shared website column layout. |
| `manifest.json` | Input/model hashes, software versions, counts, completion status and output hashes. |

ESM-2 uses pinned `facebook/esm2_t12_35M_UR50D` weights to recompute the original masked-reference log-probability features. The original 493-aa context, frozen Ridge coefficients, feature scaling and C295/C388/C871 score definition are retained. Features must pass a numerical reproduction check; a successful cache is reused. Ranking supports the fixed 492-aa scaffold or its original 493-aa terminal-G form. Other scaffolds are listed without an invented ranking.

LaMAR uses the supplied 101-nt C-centered checkpoint and original N padding. All C sites are retained; unsupported IUPAC contexts are marked unscored. Its raw score depends on the RNA context, is independent of a newly designed PUF, and is not an editing probability. The two models' outputs remain separate. A completed run is a software result, not biological validation.

## Operation

**Cancel** keeps partial results. `Ctrl+C` stops this package's server and worker. A failed or cancelled run cannot be downloaded as a completed run. Normal analysis uses local files and a loopback browser connection; setup downloads runtime/model assets.

Windows x64 and Intel Mac remain preview platforms without a real-machine acceptance test. Apple Silicon tests must be read at their recorded fixture scope; they do not establish clean-machine compatibility across macOS versions.

If startup fails, inspect `.runtime/logs/`. For an existing lock, first check whether its installer is still running; preserve logs and results. On macOS, use Finder's **Open** workflow for a trusted downloaded launcher; do not change permissions across the entire folder. Windows launchers do not change the PowerShell execution policy. An advanced user can set `ORCA_PORT` to a free port or pass `--web-only` to preview the interface without models. A first preview launch may still download Python.

See [中文说明](README-zh.md), [third-party notices](THIRD-PARTY-NOTICES.md), and `asset-manifest.json` for pinned assets and provenance.
