#!/bin/bash
# Double-click this file after extracting the complete ZIP.
PACKAGE_ROOT="$(cd "$(dirname "$0")" && pwd)"
/bin/bash "$PACKAGE_ROOT/bootstrap/start.sh" "$@"
LAUNCH_STATUS=$?
if [ "$LAUNCH_STATUS" -ne 0 ]; then
  printf '\nORCA could not start (exit %s). The error above and .runtime/logs help diagnose it.\n' "$LAUNCH_STATUS"
  printf 'Press Return to close this window... '
  read -r _
fi
exit "$LAUNCH_STATUS"
